"""
8-ЭТАПНЫЙ КОГНИТИВНЫЙ КОНВЕЙЕР
COGNITIVE BOOST v2.0

Полный жизненный цикл задачи от инициализации до обратной связи
Этапы 0-7: Init → Route → Plan → Execute → Audit → Validate → Learn → Feedback
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime

from .micro_llm_engine import MicroLLMEngine, TaskType
from .intelligent_cache import IntelligentCache
from .stateful_pipeline import StatefulCognitivePipeline, PipelineStage, PipelineState
from .priority_scheduler import PriorityTaskScheduler, TaskPriority

logger = logging.getLogger(__name__)

@dataclass
class ConveyorResult:
    """Результат работы конвейера"""
    task_id: str
    success: bool
    final_output: Any
    stages_completed: List[str]
    total_duration_ms: float
    cache_hits: int
    model_calls: int
    error: Optional[str] = None

class CognitiveConveyor:
    """
    8-этапный когнитивный конвейер
    
    Архитектура:
    STAGE 0: Инициализация - сбор данных от GENESIS/GRID/Supabase
    STAGE 1: Маршрутизация - классификация задачи, выбор моделей
    STAGE 2: Планирование - создание плана (Planner А/Б с Critic)
    STAGE 3: Исполнение - выполнение плана (Executor)
    STAGE 4: Аудит - когнитивная проверка (Critic)
    STAGE 5: Валидация - рефлексивный фильтр (антигаллюцинации)
    STAGE 6: Обучение - генерация candidate-parameters
    STAGE 7: Обратная связь - обновление датасета
    """
    
    def __init__(
        self,
        micro_llm: MicroLLMEngine,
        cache: IntelligentCache,
        pipeline: StatefulCognitivePipeline,
        scheduler: PriorityTaskScheduler,
        genesis_engine=None,
        grid_oracle=None
    ):
        self.micro_llm = micro_llm
        self.cache = cache
        self.pipeline = pipeline
        self.scheduler = scheduler
        
        # Внешние системы
        self.genesis = genesis_engine
        self.grid_oracle = grid_oracle
        
        # Регистрируем обработчики этапов
        self._register_stage_handlers()
        
        # Метрики
        self.total_conveyors = 0
        self.successful = 0
        self.failed = 0
        
        logger.info("🎯 CognitiveConveyor initialized with 8 stages")
    
    def _register_stage_handlers(self):
        """Регистрация обработчиков всех 8 этапов"""
        self.pipeline.register_stage(PipelineStage.STAGE_0_INIT, self._stage_0_init)
        self.pipeline.register_stage(PipelineStage.STAGE_1_ROUTE, self._stage_1_route)
        self.pipeline.register_stage(PipelineStage.STAGE_2_PLAN, self._stage_2_plan)
        self.pipeline.register_stage(PipelineStage.STAGE_3_EXECUTE, self._stage_3_execute)
        self.pipeline.register_stage(PipelineStage.STAGE_4_AUDIT, self._stage_4_audit)
        self.pipeline.register_stage(PipelineStage.STAGE_5_VALIDATE, self._stage_5_validate)
        self.pipeline.register_stage(PipelineStage.STAGE_6_LEARN, self._stage_6_learn)
        self.pipeline.register_stage(PipelineStage.STAGE_7_FEEDBACK, self._stage_7_feedback)
    
    async def execute(
        self,
        task_description: str,
        task_type: str = "optimization",
        priority: TaskPriority = TaskPriority.MEDIUM,
        metadata: Optional[Dict] = None
    ) -> ConveyorResult:
        """
        Выполнение полного когнитивного конвейера
        
        Args:
            task_description: Описание задачи
            task_type: Тип задачи (optimization, analysis, hypothesis и т.д.)
            priority: Приоритет выполнения
            metadata: Дополнительные данные
        
        Returns:
            ConveyorResult с результатами всех этапов
        """
        start_time = datetime.now()
        self.total_conveyors += 1
        
        task_data = {
            'description': task_description,
            'type': task_type,
            'priority': priority.name,
            'metadata': metadata or {}
        }
        
        logger.info(f"🚀 Starting cognitive conveyor: {task_type}")
        
        try:
            # Выполняем pipeline через все 8 этапов
            final_state = await self.pipeline.execute_pipeline(task_data)
            
            # Собираем результаты
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            
            if final_state.status.value == "completed":
                self.successful += 1
                
                # Извлекаем финальный output из последнего чекпоинта
                last_checkpoint = final_state.checkpoints[-1] if final_state.checkpoints else None
                final_output = last_checkpoint.output_data if last_checkpoint else None
                
                result = ConveyorResult(
                    task_id=final_state.task_id,
                    success=True,
                    final_output=final_output,
                    stages_completed=[cp.stage.name for cp in final_state.checkpoints],
                    total_duration_ms=duration_ms,
                    cache_hits=self.cache.cache_hits,
                    model_calls=self.micro_llm.total_inferences
                )
                
                logger.info(f"✅ Conveyor completed in {duration_ms:.0f}ms")
                return result
            else:
                self.failed += 1
                raise Exception(f"Pipeline failed: {final_state.status}")
                
        except Exception as e:
            self.failed += 1
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            
            logger.error(f"❌ Conveyor failed: {e}", exc_info=True)
            
            return ConveyorResult(
                task_id="failed",
                success=False,
                final_output=None,
                stages_completed=[],
                total_duration_ms=duration_ms,
                cache_hits=0,
                model_calls=0,
                error=str(e)
            )
    
    async def _stage_0_init(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 0: Инициализация и подготовка
        
        Собираем все необходимые данные:
        - GENESIS Analytics Engine (индикаторы, FSM режим)
        - GRID Oracle (текущие сетки, PnL)
        - Состояние рынка
        """
        logger.info("📊 Stage 0: Initialization")
        
        context = {
            'task': data,
            'timestamp': datetime.now().isoformat(),
            'genesis_data': None,
            'grid_data': None,
            'market_state': {}
        }
        
        # Получаем данные от GENESIS если доступен
        if self.genesis:
            try:
                genesis_snapshot = await self.genesis.get_full_snapshot('BTC/USDT')
                context['genesis_data'] = genesis_snapshot
                logger.debug(f"   GENESIS data collected: {len(genesis_snapshot.get('indicators', {}))} indicators")
            except Exception as e:
                logger.warning(f"   GENESIS unavailable: {e}")
        
        # Получаем данные от GRID Oracle если доступен
        if self.grid_oracle:
            try:
                grid_stats = self.grid_oracle.get_stats()
                context['grid_data'] = grid_stats
                logger.debug(f"   GRID data collected: {grid_stats.get('active_grids', 0)} active grids")
            except Exception as e:
                logger.warning(f"   GRID Oracle unavailable: {e}")
        
        return context
    
    async def _stage_1_route(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 1: Маршрутизация задачи
        
        Researcher (Gemini 2.5 Pro) классифицирует задачу и определяет:
        - Необходимость внешних данных (Perplexity AI)
        - Активацию условных моделей (Qwen, LLAMA Vision, и т.д.)
        - Оптимальный маршрут через конвейер
        """
        logger.info("🔀 Stage 1: Task Routing")
        
        task_desc = data['task']['description']
        
        # Используем кэш для похожих задач
        async def route_task():
            return await self.micro_llm.generate(
                task_type=TaskType.ANALYSIS,
                prompt=f"""Analyze and classify this task:

TASK: {task_desc}

Determine:
1. Task category (hypothesis_generation, code_optimization, strategy_analysis, etc.)
2. Required models (hypothesis, code, analysis, validation)
3. External data needs (web_search, charts, audio)
4. Optimal pipeline route (which stages can be skipped)

Respond in JSON format.""",
                max_tokens=300
            )
        
        routing_result = await self.cache.get_or_compute(
            task_desc,
            route_task,
            context="routing",
            model_name="phi-3-mini"
        )
        
        result_text, from_cache = routing_result
        logger.debug(f"   Routing {'[CACHED]' if from_cache else '[COMPUTED]'}: {result_text[:100]}...")
        
        return {
            **data,
            'routing': {
                'classification': result_text,
                'from_cache': from_cache
            }
        }
    
    async def _stage_2_plan(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 2: Планирование
        
        Planner A (GPT-5) создает пошаговый план
        При высокой сложности: Planner B (Mistral Large) + Critic выбирает лучший
        """
        logger.info("📋 Stage 2: Planning")
        
        task_desc = data['task']['description']
        routing = data.get('routing', {}).get('classification', '')
        
        async def create_plan():
            return await self.micro_llm.generate(
                task_type=TaskType.ANALYSIS,
                prompt=f"""Create a step-by-step plan for this task:

TASK: {task_desc}
ROUTING INFO: {routing}

Generate a detailed execution plan with:
1. Steps required
2. Dependencies between steps
3. Expected outcomes
4. Risk factors

Respond in structured format.""",
                max_tokens=500
            )
        
        plan_result = await self.cache.get_or_compute(
            f"{task_desc}_{routing}",
            create_plan,
            context="planning",
            model_name="mistral-7b"
        )
        
        plan_text, from_cache = plan_result
        logger.debug(f"   Plan {'[CACHED]' if from_cache else '[GENERATED]'}: {len(plan_text)} chars")
        
        return {
            **data,
            'plan': {
                'content': plan_text,
                'from_cache': from_cache
            }
        }
    
    async def _stage_3_execute(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 3: Исполнение
        
        Executor (Claude Opus Think) выполняет план
        Генерирует код, конфигурации или рекомендации
        """
        logger.info("⚙️  Stage 3: Execution")
        
        plan = data.get('plan', {}).get('content', '')
        
        async def execute_plan():
            return await self.micro_llm.generate(
                task_type=TaskType.CODE,
                prompt=f"""Execute this plan and generate the implementation:

PLAN:
{plan}

Generate:
1. Code implementation (if applicable)
2. Configuration changes
3. Parameter recommendations

Provide complete, executable output.""",
                max_tokens=800
            )
        
        execution_result = await self.cache.get_or_compute(
            plan,
            execute_plan,
            context="execution",
            model_name="codellama-7b"
        )
        
        output_text, from_cache = execution_result
        logger.debug(f"   Execution {'[CACHED]' if from_cache else '[GENERATED]'}: {len(output_text)} chars")
        
        return {
            **data,
            'execution': {
                'output': output_text,
                'from_cache': from_cache
            }
        }
    
    async def _stage_4_audit(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 4: Когнитивный аудит
        
        Critic (Kimi K2 Instruct) проверяет:
        - Полноту решения
        - Консистентность с планом
        - Качество реализации
        """
        logger.info("🔍 Stage 4: Cognitive Audit")
        
        execution_output = data.get('execution', {}).get('output', '')
        plan = data.get('plan', {}).get('content', '')
        
        async def audit_execution():
            return await self.micro_llm.generate(
                task_type=TaskType.VALIDATION,
                prompt=f"""Audit this execution against the plan:

PLAN:
{plan}

EXECUTION OUTPUT:
{execution_output}

Check for:
1. Completeness (all steps implemented)
2. Consistency (matches plan intent)
3. Quality (code/config correctness)
4. Risks (potential issues)

Provide audit report with PASS/FAIL verdict.""",
                max_tokens=400
            )
        
        audit_result = await self.cache.get_or_compute(
            f"{plan}_{execution_output}",
            audit_execution,
            context="audit",
            model_name="glm-4.5"
        )
        
        audit_text, from_cache = audit_result
        logger.debug(f"   Audit {'[CACHED]' if from_cache else '[PERFORMED]'}: {audit_text[:80]}...")
        
        return {
            **data,
            'audit': {
                'report': audit_text,
                'from_cache': from_cache
            }
        }
    
    async def _stage_5_validate(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 5: Рефлексивная валидация
        
        GLM-4.5 Non-Think проводит:
        - Финальную "чистку" артефактов
        - Трехуровневую проверку на галлюцинации
        - Форматирование вывода
        """
        logger.info("✓ Stage 5: Reflexive Validation")
        
        audit_report = data.get('audit', {}).get('report', '')
        execution_output = data.get('execution', {}).get('output', '')
        
        # Простая валидация (в реальности - сложная антигаллюцинационная проверка)
        validation_status = "VALIDATED" if "PASS" in audit_report else "REJECTED"
        
        logger.debug(f"   Validation: {validation_status}")
        
        return {
            **data,
            'validation': {
                'status': validation_status,
                'final_output': execution_output if validation_status == "VALIDATED" else None
            }
        }
    
    async def _stage_6_learn(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 6: Контролируемый цикл обучения
        
        Для одобренных результатов:
        - Генерация candidate-parameters
        - Автоматический запуск тестирования (через n8n)
        """
        logger.info("📚 Stage 6: Learning Cycle")
        
        if data.get('validation', {}).get('status') == "VALIDATED":
            # Генерируем candidate parameters
            candidates = {
                'generated_at': datetime.now().isoformat(),
                'source_task': data['task']['description'],
                'parameters': data.get('execution', {}).get('output', ''),
                'status': 'pending_test'
            }
            
            logger.debug("   Generated candidate parameters for testing")
            
            return {
                **data,
                'learning': {
                    'candidates': candidates,
                    'ready_for_test': True
                }
            }
        else:
            logger.debug("   Validation failed, skipping learning")
            return {
                **data,
                'learning': {
                    'candidates': None,
                    'ready_for_test': False
                }
            }
    
    async def _stage_7_feedback(self, data: Dict, state: PipelineState) -> Dict:
        """
        STAGE 7: Петля обратной связи
        
        Анализ результатов live и rejected конфигураций
        Обновление обучающего датасета для самосовершенствования
        """
        logger.info("🔄 Stage 7: Feedback Loop")
        
        # Собираем метрики всего конвейера
        feedback = {
            'success': data.get('validation', {}).get('status') == "VALIDATED",
            'stages_timing': [
                {'stage': cp.stage.name, 'duration_ms': cp.duration_ms}
                for cp in state.checkpoints
            ],
            'cache_efficiency': {
                'routing': data.get('routing', {}).get('from_cache', False),
                'planning': data.get('plan', {}).get('from_cache', False),
                'execution': data.get('execution', {}).get('from_cache', False),
                'audit': data.get('audit', {}).get('from_cache', False)
            },
            'final_output': data.get('validation', {}).get('final_output')
        }
        
        logger.info(f"   Feedback collected: {'SUCCESS' if feedback['success'] else 'FAILED'}")
        
        return {
            **data,
            'feedback': feedback
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """Статистика конвейера"""
        return {
            'total_conveyors': self.total_conveyors,
            'successful': self.successful,
            'failed': self.failed,
            'success_rate_pct': (self.successful / self.total_conveyors * 100) if self.total_conveyors > 0 else 0,
            'micro_llm_stats': self.micro_llm.get_stats(),
            'cache_stats': self.cache.get_stats(),
            'pipeline_stats': self.pipeline.get_stats(),
            'scheduler_stats': self.scheduler.get_stats()
        }
