"""
PRIORITY TASK SCHEDULER - Умный планировщик задач
COGNITIVE BOOST v2.0

Запускает когнитивные R&D-циклы ТОЛЬКО при низкой загрузке системы
Гарантирует нулевое влияние на торговые операции!
"""

import asyncio
import logging
import psutil
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import heapq

logger = logging.getLogger(__name__)

class TaskPriority(Enum):
    """Приоритеты задач"""
    CRITICAL = 0      # Торговые операции (выполняются всегда)
    HIGH = 1          # Верификация сигналов
    MEDIUM = 2        # Анализ стратегий
    LOW = 3           # R&D оптимизация
    BACKGROUND = 4    # Обучение моделей

@dataclass
class ScheduledTask:
    """Запланированная задача"""
    task_id: str
    priority: TaskPriority
    func: Callable
    args: tuple
    kwargs: dict
    created_at: datetime
    max_cpu_pct: float = 70.0
    max_ram_pct: float = 70.0
    
    def __lt__(self, other):
        """Сравнение для priority queue"""
        return self.priority.value < other.priority.value

class PriorityTaskScheduler:
    """
    Умный планировщик задач с контролем ресурсов
    
    Принципы работы:
    1. CRITICAL задачи выполняются всегда (торговые операции)
    2. LOW/BACKGROUND задачи ждут CPU < 50%, RAM < 70%
    3. Автоматическая пауза при превышении лимитов
    4. Priority queue для оптимальной последовательности
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        
        # Лимиты ресурсов
        self.cpu_threshold = 50.0    # CPU < 50% для R&D
        self.ram_threshold = 70.0    # RAM < 70% для R&D
        self.critical_cpu_limit = 90.0  # Аварийный лимит
        
        # Priority queue для задач
        self.task_queue: List[ScheduledTask] = []
        
        # Выполняющиеся задачи
        self.running_tasks: Dict[str, asyncio.Task] = {}
        
        # Метрики
        self.total_scheduled = 0
        self.completed = 0
        self.rejected = 0
        self.paused_count = 0
        
        # Флаг активности
        self.is_running = False
        self.scheduler_task: Optional[asyncio.Task] = None
        
        logger.info("⏱️ PriorityTaskScheduler initialized")
        logger.info(f"   CPU threshold: {self.cpu_threshold}%")
        logger.info(f"   RAM threshold: {self.ram_threshold}%")
    
    def schedule_task(
        self,
        func: Callable,
        priority: TaskPriority,
        task_id: Optional[str] = None,
        max_cpu_pct: Optional[float] = None,
        max_ram_pct: Optional[float] = None,
        *args,
        **kwargs
    ) -> str:
        """
        Планирование задачи с учетом приоритета
        
        Args:
            func: Асинхронная функция для выполнения
            priority: Приоритет задачи
            task_id: ID задачи (генерируется если не указан)
            max_cpu_pct: Макс. CPU для запуска (None = default по приоритету)
            max_ram_pct: Макс. RAM для запуска
        
        Returns:
            ID задачи
        """
        task_id = task_id or f"task_{self.total_scheduled}"
        
        # Определяем лимиты по приоритету
        if max_cpu_pct is None:
            if priority in [TaskPriority.CRITICAL, TaskPriority.HIGH]:
                max_cpu_pct = 100.0  # Всегда выполняем
            else:
                max_cpu_pct = self.cpu_threshold
        
        if max_ram_pct is None:
            max_ram_pct = self.ram_threshold
        
        task = ScheduledTask(
            task_id=task_id,
            priority=priority,
            func=func,
            args=args,
            kwargs=kwargs,
            created_at=datetime.now(),
            max_cpu_pct=max_cpu_pct,
            max_ram_pct=max_ram_pct
        )
        
        heapq.heappush(self.task_queue, task)
        self.total_scheduled += 1
        
        logger.debug(f"📅 Scheduled {task_id} (priority: {priority.name}, CPU limit: {max_cpu_pct}%)")
        
        return task_id
    
    async def start(self):
        """Запуск планировщика"""
        if self.is_running:
            logger.warning("⚠️ Scheduler already running")
            return
        
        self.is_running = True
        self.scheduler_task = asyncio.create_task(self._scheduler_loop())
        
        logger.info("▶️  Scheduler started")
    
    async def stop(self):
        """Остановка планировщика"""
        self.is_running = False
        
        if self.scheduler_task:
            self.scheduler_task.cancel()
            try:
                await self.scheduler_task
            except asyncio.CancelledError:
                pass
        
        # Отменяем все running задачи
        for task in self.running_tasks.values():
            task.cancel()
        
        logger.info("⏸️  Scheduler stopped")
    
    async def _scheduler_loop(self):
        """Основной цикл планировщика"""
        while self.is_running:
            try:
                # Проверяем системные ресурсы
                cpu_pct = psutil.cpu_percent(interval=0.1)
                ram_pct = psutil.virtual_memory().percent
                
                # Аварийная остановка при критической загрузке
                if cpu_pct > self.critical_cpu_limit:
                    logger.warning(f"🚨 CRITICAL CPU: {cpu_pct:.1f}% - pausing all non-critical tasks")
                    await self._pause_low_priority_tasks()
                    await asyncio.sleep(1)
                    continue
                
                # Обрабатываем очередь задач
                if self.task_queue:
                    task = heapq.heappop(self.task_queue)
                    
                    # Проверяем, можно ли запустить задачу
                    if self._can_execute(task, cpu_pct, ram_pct):
                        await self._execute_task(task)
                    else:
                        # Возвращаем задачу в очередь
                        heapq.heappush(self.task_queue, task)
                        self.paused_count += 1
                        
                        logger.debug(
                            f"⏳ Task {task.task_id} waiting: "
                            f"CPU={cpu_pct:.1f}% (max {task.max_cpu_pct}%), "
                            f"RAM={ram_pct:.1f}% (max {task.max_ram_pct}%)"
                        )
                
                # Короткая пауза перед следующей итерацией
                await asyncio.sleep(0.5)
                
            except Exception as e:
                logger.error(f"❌ Scheduler loop error: {e}", exc_info=True)
                await asyncio.sleep(1)
    
    def _can_execute(self, task: ScheduledTask, cpu_pct: float, ram_pct: float) -> bool:
        """Проверка возможности выполнения задачи"""
        # CRITICAL задачи выполняются всегда
        if task.priority == TaskPriority.CRITICAL:
            return True
        
        # Проверяем лимиты
        if cpu_pct > task.max_cpu_pct:
            return False
        
        if ram_pct > task.max_ram_pct:
            return False
        
        return True
    
    async def _execute_task(self, task: ScheduledTask):
        """Выполнение задачи"""
        logger.info(
            f"▶️  Executing {task.task_id} "
            f"(priority: {task.priority.name})"
        )
        
        try:
            # Создаем asyncio task
            async_task = asyncio.create_task(
                task.func(*task.args, **task.kwargs)
            )
            self.running_tasks[task.task_id] = async_task
            
            # Ждем завершения
            await async_task
            
            # Успешно завершено
            self.completed += 1
            logger.debug(f"✅ Task {task.task_id} completed")
            
        except asyncio.CancelledError:
            logger.info(f"⏸️  Task {task.task_id} cancelled")
        except Exception as e:
            logger.error(f"❌ Task {task.task_id} failed: {e}", exc_info=True)
            self.rejected += 1
        finally:
            # Удаляем из running
            if task.task_id in self.running_tasks:
                del self.running_tasks[task.task_id]
    
    async def _pause_low_priority_tasks(self):
        """Приостановка задач с низким приоритетом"""
        to_cancel = []
        
        for task_id, task in self.running_tasks.items():
            # Проверяем приоритет (если доступен через метаданные)
            # Здесь упрощенная логика - отменяем все кроме CRITICAL
            to_cancel.append(task_id)
        
        for task_id in to_cancel:
            task = self.running_tasks[task_id]
            task.cancel()
            logger.info(f"⏸️  Paused task {task_id} due to high system load")
    
    def get_stats(self) -> Dict[str, Any]:
        """Статистика планировщика"""
        cpu_pct = psutil.cpu_percent(interval=0.1)
        ram_pct = psutil.virtual_memory().percent
        
        return {
            'is_running': self.is_running,
            'total_scheduled': self.total_scheduled,
            'completed': self.completed,
            'rejected': self.rejected,
            'paused_count': self.paused_count,
            'queue_size': len(self.task_queue),
            'running_tasks': len(self.running_tasks),
            'current_cpu_pct': cpu_pct,
            'current_ram_pct': ram_pct,
            'cpu_threshold': self.cpu_threshold,
            'ram_threshold': self.ram_threshold
        }
