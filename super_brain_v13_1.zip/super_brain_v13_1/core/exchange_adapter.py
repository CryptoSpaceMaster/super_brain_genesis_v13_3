#!/usr/bin/env python3
"""
Exchange Adapter - Реальная интеграция с биржей БЕЗ заглушек
Поддержка: Binance, Bybit, OKX
"""
import ccxt
import logging
import time
from typing import Dict, Optional, List
from datetime import datetime, timedelta
import os

logger = logging.getLogger(__name__)

class ExchangeAdapter:
    """
    Адаптер для работы с биржами через CCXT
    НЕТ ЗАГЛУШЕК - только реальные данные
    """
    
    def __init__(self, exchange_name: str = 'binance', testnet: bool = True, simulation_mode: bool = False):
        """
        Args:
            exchange_name: Название биржи (binance, bybit, okx)
            testnet: Использовать testnet (True) или mainnet (False)
            simulation_mode: Режим симуляции для backtesting (True) или real trading (False)
        """
        self.exchange_name = exchange_name.lower()
        self.testnet = testnet
        self.simulation_mode = simulation_mode
        self.exchange = None
        self.cache = {}
        self.cache_ttl = {}
        
        if not simulation_mode:
            self._initialize_exchange()
        else:
            logger.info(f"✅ Exchange adapter in SIMULATION mode (backtesting)")
        
    def _initialize_exchange(self):
        """Инициализация подключения к бирже"""
        try:
            api_key = os.getenv(f'{self.exchange_name.upper()}_API_KEY')
            api_secret = os.getenv(f'{self.exchange_name.upper()}_API_SECRET')
            
            if api_key and api_secret:
                if self.exchange_name == 'binance':
                    config = {
                        'apiKey': api_key,
                        'secret': api_secret,
                        'enableRateLimit': True,
                        'options': {'defaultType': 'future'}
                    }
                    self.exchange = ccxt.binance(config)  # type: ignore
                    if self.testnet:
                        self.exchange.set_sandbox_mode(True)
                        
                elif self.exchange_name == 'bybit':
                    config = {
                        'apiKey': api_key,
                        'secret': api_secret,
                        'enableRateLimit': True,
                    }
                    self.exchange = ccxt.bybit(config)  # type: ignore
                    if self.testnet:
                        self.exchange.set_sandbox_mode(True)
                        
                elif self.exchange_name == 'okx':
                    passphrase = os.getenv('OKX_PASSPHRASE', '')
                    config = {
                        'apiKey': api_key,
                        'secret': api_secret,
                        'password': passphrase,
                        'enableRateLimit': True,
                    }
                    self.exchange = ccxt.okx(config)  # type: ignore
                    if self.testnet:
                        self.exchange.set_sandbox_mode(True)
            
            if api_key and api_secret:
                logger.info(f"✅ Exchange adapter initialized: {self.exchange_name} ({'testnet' if self.testnet else 'mainnet'})")
            else:
                error_msg = (
                    f"CRITICAL: Real trading mode requested for {self.exchange_name} but API keys not found. "
                    f"Set {self.exchange_name.upper()}_API_KEY and {self.exchange_name.upper()}_API_SECRET environment variables, "
                    f"or use simulation_mode=True for backtesting."
                )
                logger.error(f"❌ {error_msg}")
                raise ValueError(error_msg)
                
        except ValueError:
            raise
        except Exception as e:
            logger.error(f"❌ Failed to initialize exchange: {e}")
            raise
    
    def fetch_balance(self, cache_ttl: int = 2) -> Dict:
        """
        Получить баланс с биржи с кэшированием
        
        Args:
            cache_ttl: TTL кэша в секундах (по умолчанию 2 сек)
            
        Returns:
            Dict с балансом {'free': float, 'used': float, 'total': float, 'assets': dict}
        """
        cache_key = 'balance'
        now = time.time()
        
        if cache_key in self.cache and cache_key in self.cache_ttl:
            if now - self.cache_ttl[cache_key] < cache_ttl:
                logger.debug(f"📦 Using cached balance (age: {now - self.cache_ttl[cache_key]:.1f}s)")
                return self.cache[cache_key]
        
        if self.simulation_mode:
            logger.debug("📊 Simulation mode: returning mock balance")
            return {
                'free': 10000.0,
                'used': 0.0,
                'total': 10000.0,
                'assets': {'USDT': {'free': 10000.0, 'used': 0.0, 'total': 10000.0}},
                'simulation': True
            }
        
        if not self.exchange:
            raise RuntimeError("Exchange not initialized. This should not happen in real trading mode.")
        
        try:
            balance = self.exchange.fetch_balance()
            
            total_free = balance.get('free', {}).get('USDT', 0.0)
            total_used = balance.get('used', {}).get('USDT', 0.0)
            total_total = balance.get('total', {}).get('USDT', 0.0)
            
            assets = {}
            for asset, amount_dict in balance.get('total', {}).items():
                if isinstance(amount_dict, (int, float)) and amount_dict > 0:
                    assets[asset] = {
                        'free': balance.get('free', {}).get(asset, 0.0),
                        'used': balance.get('used', {}).get(asset, 0.0),
                        'total': amount_dict
                    }
            
            result = {
                'free': total_free,
                'used': total_used,
                'total': total_total,
                'assets': assets,
                'simulation': False,
                'timestamp': now
            }
            
            self.cache[cache_key] = result
            self.cache_ttl[cache_key] = now
            
            logger.debug(f"💰 Balance fetched: Free=${total_free:.2f}, Used=${total_used:.2f}")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Failed to fetch balance: {e}")
            return {
                'free': 0.0,
                'used': 0.0,
                'total': 0.0,
                'assets': {},
                'error': str(e)
            }
    
    def fetch_positions(self) -> List[Dict]:
        """Получить открытые позиции"""
        if self.simulation_mode:
            logger.debug("📊 Simulation mode: returning empty positions")
            return []
        
        if not self.exchange:
            raise RuntimeError("Exchange not initialized. This should not happen in real trading mode.")
        
        try:
            positions = self.exchange.fetch_positions()
            active_positions = []
            for p in positions:
                contracts = p.get('contracts', 0)
                if contracts and float(contracts) > 0:
                    active_positions.append(dict(p))
            
            logger.debug(f"📊 Active positions: {len(active_positions)}")
            return active_positions
            
        except Exception as e:
            logger.error(f"❌ Failed to fetch positions: {e}")
            return []
    
    def get_portfolio_value_usd(self, price_service=None) -> Dict:
        """
        Рассчитать стоимость портфеля в USD
        
        Args:
            price_service: Сервис для получения цен (опционально)
            
        Returns:
            Dict с общей стоимостью и детализацией по активам
        """
        balance = self.fetch_balance(cache_ttl=2)
        
        if balance.get('simulation'):
            return {
                'total_usd': balance['total'],
                'assets': balance['assets'],
                'simulation': True
            }
        
        total_usd = 0.0
        assets_usd = {}
        
        for asset, amounts in balance.get('assets', {}).items():
            if asset == 'USDT' or asset == 'USD':
                asset_value = amounts['total']
            else:
                if price_service:
                    try:
                        price = price_service.get_usdt_price(f"{asset}USDT")
                        asset_value = amounts['total'] * price
                    except:
                        logger.warning(f"⚠️ Cannot get price for {asset}, skipping")
                        continue
                else:
                    logger.warning(f"⚠️ No price service, skipping {asset}")
                    continue
            
            total_usd += asset_value
            assets_usd[asset] = {
                'amount': amounts['total'],
                'value_usd': asset_value
            }
        
        return {
            'total_usd': total_usd,
            'assets': assets_usd,
            'simulation': False,
            'timestamp': time.time()
        }
    
    def get_available_margin_usd(self) -> float:
        """
        Получить доступную маржу в USD (тактический лимит)
        С кэшированием 2 секунды
        """
        balance = self.fetch_balance(cache_ttl=2)
        return balance.get('free', 0.0)
    
    def is_connected(self) -> bool:
        """Проверка подключения к бирже"""
        return self.exchange is not None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    adapter = ExchangeAdapter('binance', testnet=True, simulation_mode=True)
    
    print("\n" + "="*80)
    print("EXCHANGE ADAPTER - TEST")
    print("="*80)
    
    print(f"\nConnected: {adapter.is_connected()}")
    
    balance = adapter.fetch_balance()
    print(f"\nBalance:")
    print(f"  Free: ${balance['free']:,.2f}")
    print(f"  Used: ${balance['used']:,.2f}")
    print(f"  Total: ${balance['total']:,.2f}")
    print(f"  Simulation: {balance.get('simulation', False)}")
    
    available = adapter.get_available_margin_usd()
    print(f"\nAvailable Margin: ${available:,.2f}")
