"""
INTELLIGENT CACHE - Семантическое кэширование для LLM
COGNITIVE BOOST v2.0

Экономит до 90% вычислений через повторное использование результатов
для семантически схожих запросов!
"""

import hashlib
import json
import logging
from typing import Dict, Optional, Any, Callable, List
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
import asyncio

logger = logging.getLogger(__name__)

@dataclass
class CacheEntry:
    """Запись в кэше"""
    query_hash: str
    result: str
    timestamp: datetime
    hit_count: int
    keywords: List[str]
    model_used: str
    tokens_saved: int = 0

class IntelligentCache:
    """
    Семантическое кэширование результатов LLM
    
    Принципы работы:
    1. Создаем семантический хэш на основе ключевых слов
    2. Схожие запросы получают одинаковый хэш
    3. Кэшируем результаты в памяти (или Redis для production)
    4. TTL: 24 часа для свежести данных
    """
    
    def __init__(self, use_redis: bool = False, redis_client=None):
        self.use_redis = use_redis
        self.redis = redis_client
        
        # In-memory кэш (для быстрого доступа)
        self.memory_cache: Dict[str, CacheEntry] = {}
        
        # Метрики
        self.total_queries = 0
        self.cache_hits = 0
        self.cache_misses = 0
        self.tokens_saved_total = 0
        
        # Конфигурация
        self.ttl_hours = 24
        self.max_memory_entries = 1000
        
        logger.info("💾 IntelligentCache initialized")
        logger.info(f"   Backend: {'Redis' if use_redis else 'Memory'}")
        logger.info(f"   TTL: {self.ttl_hours} hours")
    
    def _semantic_hash(self, text: str, context: Optional[str] = None) -> str:
        """
        Создание семантического хэша для похожих запросов
        
        Алгоритм:
        1. Нормализация текста (lowercase, strip)
        2. Извлечение ключевых слов (первые 20 значимых слов)
        3. Сортировка для стабильности
        4. MD5 хэш от объединения
        """
        # Нормализация
        normalized = text.lower().strip()
        
        # Извлечение ключевых слов (простая реализация)
        words = normalized.split()
        
        # Фильтрация стоп-слов
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for'}
        keywords = [w for w in words if w not in stop_words and len(w) > 2][:20]
        
        # Сортировка для одинакового хэша похожих запросов
        keywords_sorted = sorted(set(keywords))
        
        # Добавляем контекст если есть
        if context:
            keywords_sorted.append(f"ctx:{context}")
        
        # Создаем стабильный хэш
        hash_input = ' '.join(keywords_sorted)
        return hashlib.md5(hash_input.encode()).hexdigest()[:16]
    
    async def get_or_compute(
        self,
        prompt: str,
        compute_func: Callable,
        context: Optional[str] = None,
        model_name: str = "unknown"
    ) -> tuple[str, bool]:
        """
        Получение из кэша или вычисление нового результата
        
        Args:
            prompt: Промпт для LLM
            compute_func: Асинхронная функция для вычисления результата
            context: Дополнительный контекст (например, task_type)
            model_name: Название модели для метрик
        
        Returns:
            (result, from_cache): Результат и флаг кэша
        """
        self.total_queries += 1
        
        # Генерируем семантический хэш
        cache_key = self._semantic_hash(prompt, context)
        
        # Проверяем memory кэш
        if cache_key in self.memory_cache:
            entry = self.memory_cache[cache_key]
            
            # Проверяем TTL
            age_hours = (datetime.now() - entry.timestamp).total_seconds() / 3600
            if age_hours < self.ttl_hours:
                # Cache HIT!
                entry.hit_count += 1
                self.cache_hits += 1
                self.tokens_saved_total += entry.tokens_saved
                
                logger.debug(f"✅ Cache HIT: {cache_key[:8]}... (hits: {entry.hit_count})")
                return entry.result, True
            else:
                # Expired - удаляем
                del self.memory_cache[cache_key]
        
        # Проверяем Redis если включен
        if self.use_redis and self.redis:
            redis_key = f"llm_cache:{cache_key}"
            cached_data = await self._get_from_redis(redis_key)
            if cached_data:
                self.cache_hits += 1
                logger.debug(f"✅ Cache HIT (Redis): {cache_key[:8]}...")
                
                # Сохраняем в memory для быстрого доступа
                entry = CacheEntry(**cached_data)
                self.memory_cache[cache_key] = entry
                
                return entry.result, True
        
        # Cache MISS - вычисляем
        self.cache_misses += 1
        logger.debug(f"❌ Cache MISS: {cache_key[:8]}... - computing...")
        
        # Вызываем функцию вычисления
        result = await compute_func()
        
        # Сохраняем в кэш
        keywords = self._extract_keywords(prompt)
        tokens_estimate = len(result.split())
        
        entry = CacheEntry(
            query_hash=cache_key,
            result=result,
            timestamp=datetime.now(),
            hit_count=0,
            keywords=keywords,
            model_used=model_name,
            tokens_saved=tokens_estimate
        )
        
        # Сохраняем в memory
        await self._save_to_memory(cache_key, entry)
        
        # Сохраняем в Redis если включен
        if self.use_redis and self.redis:
            await self._save_to_redis(f"llm_cache:{cache_key}", entry)
        
        return result, False
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Извлечение ключевых слов для индексации"""
        words = text.lower().split()
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for'}
        return [w for w in words if w not in stop_words and len(w) > 2][:10]
    
    async def _save_to_memory(self, key: str, entry: CacheEntry):
        """Сохранение в memory кэш с управлением размером"""
        self.memory_cache[key] = entry
        
        # Проверка лимита размера
        if len(self.memory_cache) > self.max_memory_entries:
            # Удаляем самые старые записи
            sorted_entries = sorted(
                self.memory_cache.items(),
                key=lambda x: x[1].timestamp
            )
            # Удаляем 10% самых старых
            for old_key, _ in sorted_entries[:int(self.max_memory_entries * 0.1)]:
                del self.memory_cache[old_key]
            
            logger.debug(f"🧹 Cache cleanup: removed old entries, size: {len(self.memory_cache)}")
    
    async def _save_to_redis(self, key: str, entry: CacheEntry):
        """Сохранение в Redis с TTL"""
        if not self.redis:
            return
        
        try:
            # Сериализуем entry
            data = asdict(entry)
            data['timestamp'] = entry.timestamp.isoformat()
            
            # Сохраняем в Redis с TTL
            ttl_seconds = self.ttl_hours * 3600
            await asyncio.to_thread(
                self.redis.setex,
                key,
                ttl_seconds,
                json.dumps(data)
            )
        except Exception as e:
            logger.warning(f"⚠️ Redis save failed: {e}")
    
    async def _get_from_redis(self, key: str) -> Optional[Dict]:
        """Получение из Redis"""
        if not self.redis:
            return None
        
        try:
            data = await asyncio.to_thread(self.redis.get, key)
            if data:
                parsed = json.loads(data)
                # Восстанавливаем datetime
                parsed['timestamp'] = datetime.fromisoformat(parsed['timestamp'])
                return parsed
        except Exception as e:
            logger.warning(f"⚠️ Redis get failed: {e}")
        
        return None
    
    def clear_cache(self, older_than_hours: Optional[int] = None):
        """Очистка кэша"""
        if older_than_hours:
            cutoff = datetime.now() - timedelta(hours=older_than_hours)
            before_count = len(self.memory_cache)
            
            self.memory_cache = {
                k: v for k, v in self.memory_cache.items()
                if v.timestamp >= cutoff
            }
            
            removed = before_count - len(self.memory_cache)
            logger.info(f"🧹 Cleared {removed} old cache entries (older than {older_than_hours}h)")
        else:
            self.memory_cache.clear()
            logger.info("🧹 Cache completely cleared")
    
    def get_stats(self) -> Dict[str, Any]:
        """Статистика кэша"""
        hit_rate = (self.cache_hits / self.total_queries * 100) if self.total_queries > 0 else 0
        
        return {
            'total_queries': self.total_queries,
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'hit_rate_pct': hit_rate,
            'tokens_saved': self.tokens_saved_total,
            'memory_entries': len(self.memory_cache),
            'estimated_savings_pct': min(hit_rate, 90),  # До 90% экономии
            'backend': 'Redis' if self.use_redis else 'Memory'
        }
