#!/usr/bin/env python3
"""
FSM - Finite State Machine для определения рыночного режима
ТОЧНО ПО ЭНЦИКЛОПЕДИИ
"""
import logging
from typing import Dict
from enum import Enum

logger = logging.getLogger(__name__)

class MarketRegime(Enum):
    """Рыночные режимы"""
    TREND = "TREND"
    FLAT = "FLAT"
    CHAOS = "CHAOS"

class FSM:
    """
    Finite State Machine - Определение глобального рыночного режима
    + UMSI (Unified Market State Index) - ПО СПЕЦИФИКАЦИИ
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.current_regime = MarketRegime.FLAT
        self.cooldown_counter = 0
        self.cooldown_period = 10
        
        self.adx_thresholds = {
            'trend_enter': 22,
            'trend_exit': 20
        }
        self.chop_thresholds = {
            'flat_high': 61.8,
            'flat_low': 38.2
        }
        
        # UMSI: Матрица динамического взвешивания - ТОЧНО ПО СПЕЦИФИКАЦИИ
        self.umsi_weights = {
            'TREND': {'Wtrend': 0.60, 'Wreversion': 0.20, 'Wchaos': 0.20},
            'FLAT': {'Wtrend': 0.25, 'Wreversion': 0.50, 'Wchaos': 0.25},
            'CHAOS': {'Wtrend': 0.15, 'Wreversion': 0.25, 'Wchaos': 0.60}
        }
        
        # OPUS 4.1: Поддержка разворотных зон
        self.reversal_detection_enabled = self.config.get('reversal_detection', True)
        self.reversal_threshold = self.config.get('reversal_threshold', 0.85)
        self.confidence_multiplier = 1.0
        
        logger.info("FSM initialized with UMSI and reversal detection")
    
    def update_regime(self, adx_d: float, chop_d: float, lpi_total: float = None) -> Dict:
        """
        Обновление рыночного режима
        
        Args:
            adx_d: Значение ADX-D
            chop_d: Значение CHOP-D
            lpi_total: LPI v2.0 Total (опционально, для триггера CHAOS)
        """
        
        previous_regime = self.current_regime
        
        # Cooldown после смены режима
        if self.cooldown_counter > 0:
            self.cooldown_counter -= 1
            return {
                'regime': self.current_regime.value,
                'changed': False,
                'cooldown': self.cooldown_counter,
                'lpi_chaos_trigger': False
            }
        
        # ПРИОРИТЕТ 1: LPI > 0.8 → CHAOS (по спецификации)
        # Экстремально высокое значение LPI является основным триггером CHAOS
        lpi_chaos_trigger = False
        if lpi_total is not None and lpi_total > 0.8:
            self.current_regime = MarketRegime.CHAOS
            lpi_chaos_trigger = True
            logger.warning(f"⚠️ LPI CHAOS TRIGGER: LPI={lpi_total:.3f} > 0.8 → CHAOS режим")
        
        # Логика переходов с гистерезисом (если LPI триггер не сработал)
        elif adx_d > self.adx_thresholds['trend_enter']:
            self.current_regime = MarketRegime.TREND
            
        elif chop_d > self.chop_thresholds['flat_high']:
            self.current_regime = MarketRegime.FLAT
            
        elif adx_d < self.adx_thresholds['trend_exit'] and chop_d < self.chop_thresholds['flat_low']:
            self.current_regime = MarketRegime.CHAOS
        
        # Проверка смены режима
        regime_changed = previous_regime != self.current_regime
        
        if regime_changed:
            self.cooldown_counter = self.cooldown_period
            logger.info(f"🔄 Regime changed: {previous_regime.value} -> {self.current_regime.value}")
        
        return {
            'regime': self.current_regime.value,
            'changed': regime_changed,
            'previous': previous_regime.value if regime_changed else None,
            'adx_d': adx_d,
            'chop_d': chop_d,
            'lpi_total': lpi_total,
            'lpi_chaos_trigger': lpi_chaos_trigger
        }
    
    def calculate_umsi(self, adx_d_data: Dict, chop_d_data: Dict, 
                      lpi_total: float, truth_context: str = 'Consolidation_Range') -> float:
        """
        UMSI (Unified Market State Index) - ТОЧНО ПО СПЕЦИФИКАЦИИ
        
        Формула: UMSI = (Wtrend × TrendScore) + (Wreversion × ReversionScore) + (Wchaos × ChaosScore)
        
        Args:
            adx_d_data: Данные ADX-D (dict с 'value', 'context')
            chop_d_data: Данные CHOP-D (dict с 'value')
            lpi_total: LPI.total
            truth_context: Контекст от TRUTH ENGINE
        
        Returns:
            float: UMSI индекс от 0.0 до 1.0
        """
        
        # Получение весов для текущего режима
        regime = self.current_regime.value
        weights = self.umsi_weights.get(regime, self.umsi_weights['FLAT'])
        
        # 1. TrendScore: нормализованное значение ADX-D
        adx_value = adx_d_data.get('value', 25.0)
        adx_context = adx_d_data.get('context', 'Consolidation_Range')
        
        # Нормализация ADX-D (0-100) -> (0-1)
        trend_score = min(1.0, adx_value / 50.0)
        
        # Усиление при Trend_Impulse
        if adx_context == 'Trend_Impulse':
            trend_score = min(1.0, trend_score * 1.2)
        
        # 2. ReversionScore: обратно пропорциональный CHOP-D
        chop_value = chop_d_data.get('value', 50.0)
        
        # Обратная нормализация CHOP (высокий CHOP = низкий ReversionScore)
        reversion_score = max(0.0, 1.0 - (chop_value / 100.0))
        
        # Усиление от PBS (Probabilistic Breakout Score)
        pbs_score = chop_d_data.get('pbs_score', 0.0)
        reversion_score = min(1.0, reversion_score + pbs_score * 0.3)
        
        # 3. ChaosScore: на основе LPI
        chaos_score = min(1.0, lpi_total)
        
        # Усиление при Manipulation_Squeeze
        if truth_context == 'Manipulation_Squeeze':
            chaos_score = min(1.0, chaos_score * 1.3)
        
        # Расчет финального UMSI
        umsi = (
            weights['Wtrend'] * trend_score +
            weights['Wreversion'] * reversion_score +
            weights['Wchaos'] * chaos_score
        )
        
        # Ограничение диапазона [0.0, 1.0]
        umsi = max(0.0, min(1.0, umsi))
        
        logger.debug(f"UMSI calculated: {umsi:.3f} (regime={regime}, "
                    f"trend={trend_score:.2f}, rev={reversion_score:.2f}, chaos={chaos_score:.2f})")
        
        return umsi
    
    def update_regime_with_reversal(self, adx_d: float, chop_d: float, reversal_probability: float = 0.0) -> Dict:
        """
        OPUS 4.1: Обновление режима с учетом разворотных зон
        
        Args:
            adx_d: Значение ADX-D
            chop_d: Значение CHOP-D
            reversal_probability: Вероятность разворота от GENESIS
        """
        base_result = self.update_regime(adx_d, chop_d)
        
        if self.reversal_detection_enabled and reversal_probability > self.reversal_threshold:
            if self.current_regime == MarketRegime.TREND and reversal_probability > 0.9:
                logger.info(f"🔄 High reversal probability ({reversal_probability:.2f}), switching TREND -> FLAT")
                self.current_regime = MarketRegime.FLAT
                self.cooldown_counter = self.cooldown_period
                base_result['regime'] = 'FLAT'
                base_result['reversal_override'] = True
                
            elif self.current_regime == MarketRegime.FLAT:
                self.confidence_multiplier = 1.5
                base_result['confidence_multiplier'] = self.confidence_multiplier
        
        return base_result
    
    def get_grid_regime_params(self, regime: str = None) -> Dict:
        """
        OPUS 4.1: Параметры сетки для каждого режима
        
        Returns:
            Dict с параметрами сетки (grid_width_mult, step_mult, levels_mult, etc.)
        """
        if regime is None:
            regime = self.current_regime.value
        
        params = {
            'TREND': {
                'grid_width_mult': 1.3,
                'step_mult': 1.2,
                'levels_mult': 0.8,
                'progressive_enabled': True,
                'dual_grid': False,
                'progressive_mult': 1.0
            },
            'FLAT': {
                'grid_width_mult': 0.8,
                'step_mult': 0.7,
                'levels_mult': 1.3,
                'progressive_enabled': True,
                'dual_grid': True,
                'progressive_mult': 1.2
            },
            'CHAOS': {
                'grid_width_mult': 1.5,
                'step_mult': 1.4,
                'levels_mult': 0.6,
                'progressive_enabled': False,
                'dual_grid': False,
                'progressive_mult': 0.8
            }
        }
        
        return params.get(regime, params['FLAT'])

if __name__ == "__main__":
    print("✅ FSM создан с UMSI и разворотными зонами")
