#!/usr/bin/env python3
"""
SMC State Engine - Smart Money Concepts
ТОЧНО ПО ЭНЦИКЛОПЕДИИ
"""
import logging
from typing import Dict, List, Optional
import pandas as pd

logger = logging.getLogger(__name__)

class SMCStateEngine:
    """
    SMC State Engine - Отслеживание Smart Money Concepts
    
    Функции:
    - Определение Order Blocks
    - Обнаружение Fair Value Gaps (FVG)
    - Поиск Break of Structure (BOS)
    - Change of Character (CHoCH)
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        
        # Минимальный размер FVG
        self.min_fvg_size = 0.002  # 0.2%
        
        logger.info("SMC State Engine initialized")
    
    def detect_order_blocks(self, klines: pd.DataFrame) -> List[Dict]:
        """
        Обнаружение Order Blocks
        
        Args:
            klines: Данные свечей
        """
        
        try:
            order_blocks = []
            
            if len(klines) < 5:
                return order_blocks
            
            # Упрощенное обнаружение Order Blocks
            for i in range(2, len(klines) - 2):
                current = klines.iloc[i]
                prev = klines.iloc[i - 1]
                next_candle = klines.iloc[i + 1]
                
                # Bullish Order Block
                if (prev['close'] < prev['open'] and  # Предыдущая свеча медвежья
                    current['close'] > current['open'] and  # Текущая бычья
                    current['close'] > prev['high']):  # Пробой вверх
                    
                    order_blocks.append({
                        'type': 'BULLISH_OB',
                        'price_high': current['high'],
                        'price_low': current['low'],
                        'timestamp': current.get('timestamp', i),
                        'strength': 0.7
                    })
                
                # Bearish Order Block
                elif (prev['close'] > prev['open'] and  # Предыдущая бычья
                      current['close'] < current['open'] and  # Текущая медвежья
                      current['close'] < prev['low']):  # Пробой вниз
                    
                    order_blocks.append({
                        'type': 'BEARISH_OB',
                        'price_high': current['high'],
                        'price_low': current['low'],
                        'timestamp': current.get('timestamp', i),
                        'strength': 0.7
                    })
            
            logger.debug(f"Detected {len(order_blocks)} Order Blocks")
            
            return order_blocks
            
        except Exception as e:
            logger.error(f"❌ Error detecting Order Blocks: {e}")
            return []
    
    def detect_fair_value_gaps(self, klines: pd.DataFrame) -> List[Dict]:
        """
        Обнаружение Fair Value Gaps (FVG)
        
        Args:
            klines: Данные свечей
        """
        
        try:
            fvgs = []
            
            if len(klines) < 3:
                return fvgs
            
            for i in range(1, len(klines) - 1):
                prev = klines.iloc[i - 1]
                current = klines.iloc[i]
                next_candle = klines.iloc[i + 1]
                
                # Bullish FVG: gap между предыдущей high и следующей low
                if next_candle['low'] > prev['high']:
                    gap_size = (next_candle['low'] - prev['high']) / prev['high']
                    
                    if gap_size >= self.min_fvg_size:
                        fvgs.append({
                            'type': 'BULLISH_FVG',
                            'upper': next_candle['low'],
                            'lower': prev['high'],
                            'gap_size': gap_size,
                            'timestamp': current.get('timestamp', i)
                        })
                
                # Bearish FVG: gap между предыдущей low и следующей high
                elif next_candle['high'] < prev['low']:
                    gap_size = (prev['low'] - next_candle['high']) / next_candle['high']
                    
                    if gap_size >= self.min_fvg_size:
                        fvgs.append({
                            'type': 'BEARISH_FVG',
                            'upper': prev['low'],
                            'lower': next_candle['high'],
                            'gap_size': gap_size,
                            'timestamp': current.get('timestamp', i)
                        })
            
            logger.debug(f"Detected {len(fvgs)} Fair Value Gaps")
            
            return fvgs
            
        except Exception as e:
            logger.error(f"❌ Error detecting FVGs: {e}")
            return []
    
    def detect_structure_break(self, klines: pd.DataFrame) -> Optional[Dict]:
        """
        Обнаружение Break of Structure (BOS)
        
        Args:
            klines: Данные свечей
        """
        
        try:
            if len(klines) < 10:
                return None
            
            # Находим последний значимый максимум и минимум
            recent_high = klines['high'].tail(10).max()
            recent_low = klines['low'].tail(10).min()
            
            current_price = klines['close'].iloc[-1]
            
            # Bullish BOS - пробой последнего максимума
            if current_price > recent_high:
                return {
                    'type': 'BULLISH_BOS',
                    'break_level': recent_high,
                    'current_price': current_price,
                    'strength': (current_price - recent_high) / recent_high
                }
            
            # Bearish BOS - пробой последнего минимума
            elif current_price < recent_low:
                return {
                    'type': 'BEARISH_BOS',
                    'break_level': recent_low,
                    'current_price': current_price,
                    'strength': (recent_low - current_price) / recent_low
                }
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Error detecting BOS: {e}")
            return None
    
    def analyze_market_structure(self, klines: pd.DataFrame) -> Dict:
        """
        Полный анализ рыночной структуры
        
        Args:
            klines: Данные свечей
        """
        
        order_blocks = self.detect_order_blocks(klines)
        fvgs = self.detect_fair_value_gaps(klines)
        structure_break = self.detect_structure_break(klines)
        
        return {
            'order_blocks': order_blocks,
            'fair_value_gaps': fvgs,
            'structure_break': structure_break,
            'ob_count': len(order_blocks),
            'fvg_count': len(fvgs),
            'has_structure_break': structure_break is not None
        }

if __name__ == "__main__":
    print("✅ SMC State Engine создан")
