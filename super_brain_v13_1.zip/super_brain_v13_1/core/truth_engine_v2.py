"""
TRUTH ENGINE v2.0 - ДЕТЕРМИНИРОВАННАЯ АДАПТИВНАЯ ВЕРСИЯ
Полная реализация БЕЗ ML, БЕЗ усложнений, с контролируемой адаптацией

АРХИТЕКТУРНЫЕ ГАРАНТИИ:
✓ Детерминированная логика (3 простых правила)
✓ Адаптивные пороги (решение проблемы concept drift БЕЗ ML)
✓ Минимальная нагрузка (< 2 мс на анализ, < 1 МБ памяти)
✓ Монолитная архитектура Python Core API
✓ Dynamic Aggression Factor (DAF) для Guardian Martingale
"""

import numpy as np
from typing import Dict, Optional, Tuple, List
from dataclasses import dataclass
from enum import Enum
import logging
import time
from collections import deque

logger = logging.getLogger(__name__)

class MarketClassification(Enum):
    """Классификация рыночных движений"""
    TREND_IMPULSE = "Trend_Impulse"
    MANIPULATION_SQUEEZE = "Manipulation_Squeeze"
    CONSOLIDATION_RANGE = "Consolidation_Range"

@dataclass
class TruthOutput:
    """Структура выхода TRUTH ENGINE"""
    classification: str
    confidence: float
    daf: float
    timestamp: float
    
    def to_dict(self) -> Dict:
        return {
            'classification': self.classification,
            'confidence': self.confidence,
            'daf': self.daf,
            'timestamp': self.timestamp
        }

class AdaptiveThresholds:
    """
    Самокалибрующиеся пороги на основе скользящей статистики
    Решает проблему 'concept drift' БЕЗ использования ML
    
    Как это работает:
    - Вместо жестко заданных констант используем квантили
    - Автоматическая перекалибровка каждые 100 свечей
    - Адаптация к меняющейся волатильности и характеру рынка
    """
    
    def __init__(self, window_size: int = 1000):
        """
        Args:
            window_size: Размер окна для расчета статистики (свечей)
        """
        self.window_size = window_size
        self.history = {
            'adx': deque(maxlen=window_size),
            'rsi': deque(maxlen=window_size),
            'lpi': deque(maxlen=window_size),
            'volume_ratio': deque(maxlen=window_size),
            'atr': deque(maxlen=window_size)
        }
        
        self.base_thresholds = {
            'trend_adx': 25,
            'flat_adx': 20,
            'squeeze_lpi': 0.75,
            'volume_spike': 2.0,
            'rsi_oversold': 30,
            'rsi_overbought': 70
        }
        
        self.adaptive_thresholds = self.base_thresholds.copy()
        self.updates_count = 0
        
    def update(self, market_data: Dict):
        """Обновление истории и пересчет порогов"""
        
        for key in self.history:
            value = market_data.get(key)
            if value is not None:
                self.history[key].append(value)
        
        self.updates_count += 1
        if self.updates_count % 100 == 0:
            self._recalibrate_thresholds()
    
    def _recalibrate_thresholds(self):
        """
        Автоматическая калибровка порогов на основе статистики
        Ключевое решение для адаптации БЕЗ ML
        """
        
        if len(self.history['adx']) < 100:
            return
        
        adx_values = list(self.history['adx'])
        if len(adx_values) > 0:
            self.adaptive_thresholds['trend_adx'] = np.percentile(adx_values, 70)
            self.adaptive_thresholds['flat_adx'] = np.percentile(adx_values, 30)
        
        lpi_values = list(self.history['lpi'])
        if len(lpi_values) > 0:
            self.adaptive_thresholds['squeeze_lpi'] = np.percentile(lpi_values, 85)
        
        vol_values = list(self.history['volume_ratio'])
        if len(vol_values) > 0:
            mean_vol = np.mean(vol_values)
            std_vol = np.std(vol_values)
            self.adaptive_thresholds['volume_spike'] = mean_vol + 2 * std_vol
        
        rsi_values = list(self.history['rsi'])
        if len(rsi_values) > 0:
            self.adaptive_thresholds['rsi_oversold'] = np.percentile(rsi_values, 15)
            self.adaptive_thresholds['rsi_overbought'] = np.percentile(rsi_values, 85)
        
        logger.debug(f"Thresholds recalibrated: {self.adaptive_thresholds}")
    
    def get_threshold(self, name: str) -> float:
        """Получить текущий адаптивный порог"""
        return self.adaptive_thresholds.get(name, self.base_thresholds.get(name))


class TruthEngineV2:
    """
    TRUTH ENGINE v2.0 - Минимальная детерминированная версия
    
    АРХИТЕКТУРА:
    - Детерминированная логика (3 простых правила)
    - Адаптивные пороги (авто-калибровка)
    - Минимальная нагрузка (< 2 мс на анализ)
    - Dynamic Aggression Factor для Guardian Martingale
    
    ИНТЕГРАЦИЯ:
    - FSM: Стратегический фон (TREND/FLAT/CHAOS)
    - TRUTH ENGINE: Тактический вердикт (IMPULSE/SQUEEZE/RANGE)
    - Guardian Martingale: DAF управляет агрессией усреднения
    """
    
    def __init__(self, config: Optional[Dict] = None, enabled: bool = True):
        """
        Args:
            config: Конфигурация модуля
            enabled: Флаг включения/выключения
        """
        self.config = config if config is not None else {}
        self.enabled = enabled
        self.adaptive_thresholds = AdaptiveThresholds(
            window_size=self.config.get('window_size', 1000)
        )
        
        self.total_analyses = 0
        self.execution_times = deque(maxlen=100)
        
        logger.info("TRUTH ENGINE v2.0 initialized (deterministic)")
        logger.info(f"   Enabled: {self.enabled}")
        logger.info(f"   Window size: {self.adaptive_thresholds.window_size}")
    
    def analyze(self, market_data: Dict) -> Dict:
        """
        ГЛАВНЫЙ МЕТОД - Анализ рынка и выдача вердикта
        
        Args:
            market_data: Словарь с метриками из GENESIS Engine
            
        Returns:
            Dict с verdict, confidence, daf, timestamp
        """
        start_time = time.perf_counter()
        
        if not self.enabled:
            return {
                'verdict': MarketClassification.CONSOLIDATION_RANGE.value,
                'classification': MarketClassification.CONSOLIDATION_RANGE.value,
                'confidence': 0.5,
                'daf': 0.5,
                'timestamp': time.time()
            }
        
        self.adaptive_thresholds.update(market_data)
        
        lpi_data = market_data.get('lpi', 0.5)
        lpi = lpi_data.get('total', 0.5) if isinstance(lpi_data, dict) else lpi_data
        adx = market_data.get('adx', 20)
        rsi = market_data.get('rsi', 50)
        volume_ratio = market_data.get('volume_ratio', 1.0)
        cvd_divergence = market_data.get('cvd_divergence', 0)
        liquidity_sweep = market_data.get('liquidity_sweep', False)
        
        classification, confidence, daf = self._classify_market(
            lpi, adx, rsi, volume_ratio, cvd_divergence, liquidity_sweep
        )
        
        execution_time = (time.perf_counter() - start_time) * 1000
        self.execution_times.append(execution_time)
        self.total_analyses += 1
        
        return {
            'verdict': classification,
            'classification': classification,
            'confidence': confidence,
            'daf': daf,
            'timestamp': time.time(),
            'execution_time_ms': execution_time
        }
    
    def analyze_as_object(self, market_data: Dict) -> TruthOutput:
        """
        Альтернативный метод возвращающий TruthOutput объект
        Для новых интеграций, требующих типизацию
        """
        result = self.analyze(market_data)
        return TruthOutput(
            classification=result['classification'],
            confidence=result['confidence'],
            daf=result['daf'],
            timestamp=result['timestamp']
        )
    
    def _classify_market(self, lpi: float, adx: float, rsi: float,
                        volume_ratio: float, cvd_divergence: float,
                        liquidity_sweep: bool) -> Tuple[str, float, float]:
        """
        Детерминированная классификация на основе адаптивных порогов
        
        ПРАВИЛО 1: Детекция манипуляции/сквиза (приоритет)
        ПРАВИЛО 2: Детекция сильного тренда
        ПРАВИЛО 3: Консолидация (по умолчанию)
        """
        
        trend_adx = self.adaptive_thresholds.get_threshold('trend_adx')
        flat_adx = self.adaptive_thresholds.get_threshold('flat_adx')
        squeeze_lpi = self.adaptive_thresholds.get_threshold('squeeze_lpi')
        volume_spike = self.adaptive_thresholds.get_threshold('volume_spike')
        
        squeeze_score = 0
        if lpi > squeeze_lpi:
            squeeze_score += 0.4
        if liquidity_sweep:
            squeeze_score += 0.3
        if abs(cvd_divergence) > 0.3:
            squeeze_score += 0.2
        if volume_ratio > volume_spike:
            squeeze_score += 0.1
            
        if squeeze_score > 0.5:
            confidence = min(squeeze_score, 0.95)
            daf = 0.7 + (confidence * 0.25)
            return MarketClassification.MANIPULATION_SQUEEZE.value, confidence, daf
        
        if adx > trend_adx:
            confidence = min((adx - trend_adx) / 10 + 0.6, 0.9)
            daf = 0.3 - (confidence * 0.2)
            return MarketClassification.TREND_IMPULSE.value, confidence, daf
        
        if adx < flat_adx:
            confidence = min((flat_adx - adx) / 10 + 0.5, 0.8)
            daf = 0.4 + (confidence * 0.2)
            return MarketClassification.CONSOLIDATION_RANGE.value, confidence, daf
        
        return MarketClassification.CONSOLIDATION_RANGE.value, 0.5, 0.5
    
    def get_performance_stats(self) -> Dict:
        """Статистика производительности"""
        if not self.execution_times:
            return {'enabled': self.enabled, 'total_analyses': 0}
        
        return {
            'enabled': self.enabled,
            'total_analyses': self.total_analyses,
            'avg_execution_time_ms': float(np.mean(self.execution_times)),
            'max_execution_time_ms': float(np.max(self.execution_times)),
            'current_thresholds': self.adaptive_thresholds.adaptive_thresholds.copy()
        }
    
    def get_current_thresholds(self) -> Dict:
        """Получить текущие адаптивные пороги"""
        return self.adaptive_thresholds.adaptive_thresholds.copy()
    
    def reset_thresholds(self):
        """Сброс порогов к базовым значениям"""
        self.adaptive_thresholds.adaptive_thresholds = self.adaptive_thresholds.base_thresholds.copy()
        self.adaptive_thresholds.updates_count = 0
        logger.info("Thresholds reset to base values")


if __name__ == "__main__":
    print("✅ TRUTH ENGINE v2.0 - Full Deterministic Adaptive Version")
