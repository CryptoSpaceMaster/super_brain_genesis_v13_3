"""
STATEFUL COGNITIVE PIPELINE - Отказоустойчивый конвейер
COGNITIVE BOOST v2.0

Обеспечивает возобновление работы после сбоев без потери прогресса
через систему чекпоинтов в Redis/Memory
"""

import asyncio
import json
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
import uuid

logger = logging.getLogger(__name__)

class PipelineStage(Enum):
    """8 этапов когнитивного конвейера"""
    STAGE_0_INIT = 0          # Инициализация и подготовка
    STAGE_1_ROUTE = 1         # Маршрутизация задачи
    STAGE_2_PLAN = 2          # Планирование
    STAGE_3_EXECUTE = 3       # Исполнение
    STAGE_4_AUDIT = 4         # Когнитивный аудит
    STAGE_5_VALIDATE = 5      # Рефлексивная валидация
    STAGE_6_LEARN = 6         # Контролируемый цикл обучения
    STAGE_7_FEEDBACK = 7      # Петля обратной связи

class PipelineStatus(Enum):
    """Статусы выполнения"""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    RECOVERED = "recovered"

@dataclass
class StageCheckpoint:
    """Чекпоинт этапа конвейера"""
    stage: PipelineStage
    status: PipelineStatus
    input_data: Dict[str, Any]
    output_data: Optional[Dict[str, Any]]
    timestamp: datetime
    duration_ms: float
    error: Optional[str] = None

@dataclass
class PipelineState:
    """Состояние конвейера"""
    task_id: str
    current_stage: PipelineStage
    status: PipelineStatus
    checkpoints: List[StageCheckpoint]
    metadata: Dict[str, Any]
    created_at: datetime
    updated_at: datetime

class StatefulCognitivePipeline:
    """
    Отказоустойчивый когнитивный конвейер
    
    Архитектурные гарантии:
    1. Каждый этап сохраняет чекпоинт перед и после выполнения
    2. При сбое конвейер восстанавливается с последнего успешного чекпоинта
    3. Все данные хранятся в Redis (или memory для dev)
    4. Полная трассировка выполнения для дебага
    """
    
    def __init__(self, use_redis: bool = False, redis_client=None):
        self.use_redis = use_redis
        self.redis = redis_client
        
        # In-memory хранилище состояний
        self.states: Dict[str, PipelineState] = {}
        
        # Регистрация обработчиков этапов
        self.stage_handlers: Dict[PipelineStage, Callable] = {}
        
        # Метрики
        self.total_tasks = 0
        self.completed_tasks = 0
        self.failed_tasks = 0
        self.recovered_tasks = 0
        
        logger.info("🔄 StatefulCognitivePipeline initialized")
        logger.info(f"   Backend: {'Redis' if use_redis else 'Memory'}")
        logger.info(f"   Stages: {len(PipelineStage)} (0-7)")
    
    def register_stage(self, stage: PipelineStage, handler: Callable):
        """Регистрация обработчика этапа"""
        self.stage_handlers[stage] = handler
        logger.debug(f"📝 Registered handler for {stage.name}")
    
    async def execute_pipeline(
        self,
        task_data: Dict[str, Any],
        task_id: Optional[str] = None,
        resume_from: Optional[PipelineStage] = None
    ) -> PipelineState:
        """
        Выполнение полного конвейера с чекпоинтами
        
        Args:
            task_data: Входные данные задачи
            task_id: ID задачи (генерируется если не указан)
            resume_from: Этап для возобновления (None = начало)
        
        Returns:
            Финальное состояние конвейера
        """
        # Создаем или восстанавливаем состояние
        if task_id and resume_from:
            state = await self._load_state(task_id)
            if state:
                logger.info(f"🔄 Resuming task {task_id} from {resume_from.name}")
                self.recovered_tasks += 1
            else:
                state = self._create_new_state(task_id or str(uuid.uuid4()), task_data)
        else:
            state = self._create_new_state(task_id or str(uuid.uuid4()), task_data)
        
        self.total_tasks += 1
        
        # Определяем начальный этап
        start_stage = resume_from or PipelineStage.STAGE_0_INIT
        stages = [s for s in PipelineStage if s.value >= start_stage.value]
        
        # Выполняем этапы последовательно
        state.status = PipelineStatus.RUNNING
        current_data = task_data
        
        for stage in stages:
            try:
                # Чекпоинт ПЕРЕД этапом
                await self._save_checkpoint(state, stage, current_data, None, PipelineStatus.RUNNING)
                
                # Выполнение этапа
                if stage not in self.stage_handlers:
                    logger.warning(f"⚠️ No handler for {stage.name}, skipping")
                    continue
                
                logger.info(f"▶️  Executing {stage.name}")
                start_time = datetime.now()
                
                handler = self.stage_handlers[stage]
                output_data = await handler(current_data, state)
                
                duration_ms = (datetime.now() - start_time).total_seconds() * 1000
                
                # Чекпоинт ПОСЛЕ этапа
                await self._save_checkpoint(
                    state, stage, current_data, output_data, 
                    PipelineStatus.COMPLETED, duration_ms
                )
                
                # Передаем данные следующему этапу
                current_data = output_data if output_data else current_data
                state.current_stage = stage
                
            except Exception as e:
                logger.error(f"❌ Stage {stage.name} failed: {e}", exc_info=True)
                
                # Сохраняем ошибку в чекпоинт
                await self._save_checkpoint(
                    state, stage, current_data, None, 
                    PipelineStatus.FAILED, error=str(e)
                )
                
                state.status = PipelineStatus.FAILED
                self.failed_tasks += 1
                
                return state
        
        # Конвейер завершен успешно
        state.status = PipelineStatus.COMPLETED
        self.completed_tasks += 1
        
        logger.info(f"✅ Pipeline {state.task_id} completed successfully")
        
        return state
    
    def _create_new_state(self, task_id: str, task_data: Dict[str, Any]) -> PipelineState:
        """Создание нового состояния конвейера"""
        state = PipelineState(
            task_id=task_id,
            current_stage=PipelineStage.STAGE_0_INIT,
            status=PipelineStatus.PENDING,
            checkpoints=[],
            metadata=task_data.get('metadata', {}),
            created_at=datetime.now(),
            updated_at=datetime.now()
        )
        
        self.states[task_id] = state
        return state
    
    async def _save_checkpoint(
        self,
        state: PipelineState,
        stage: PipelineStage,
        input_data: Dict[str, Any],
        output_data: Optional[Dict[str, Any]],
        status: PipelineStatus,
        duration_ms: float = 0,
        error: Optional[str] = None
    ):
        """Сохранение чекпоинта этапа"""
        checkpoint = StageCheckpoint(
            stage=stage,
            status=status,
            input_data=input_data,
            output_data=output_data,
            timestamp=datetime.now(),
            duration_ms=duration_ms,
            error=error
        )
        
        state.checkpoints.append(checkpoint)
        state.updated_at = datetime.now()
        
        # Сохраняем состояние в Redis/Memory
        await self._persist_state(state)
        
        logger.debug(f"💾 Checkpoint saved: {stage.name} -> {status.value}")
    
    async def _persist_state(self, state: PipelineState):
        """Сохранение состояния в хранилище"""
        # Memory
        self.states[state.task_id] = state
        
        # Redis (если включен)
        if self.use_redis and self.redis:
            try:
                # Сериализуем состояние
                data = self._serialize_state(state)
                key = f"pipeline:{state.task_id}"
                
                await asyncio.to_thread(
                    self.redis.setex,
                    key,
                    86400,  # TTL 24 часа
                    json.dumps(data)
                )
            except Exception as e:
                logger.warning(f"⚠️ Redis persist failed: {e}")
    
    async def _load_state(self, task_id: str) -> Optional[PipelineState]:
        """Загрузка состояния из хранилища"""
        # Проверяем memory
        if task_id in self.states:
            return self.states[task_id]
        
        # Проверяем Redis
        if self.use_redis and self.redis:
            try:
                key = f"pipeline:{task_id}"
                data = await asyncio.to_thread(self.redis.get, key)
                
                if data:
                    return self._deserialize_state(json.loads(data))
            except Exception as e:
                logger.warning(f"⚠️ Redis load failed: {e}")
        
        return None
    
    def _serialize_state(self, state: PipelineState) -> Dict:
        """Сериализация состояния для хранения"""
        return {
            'task_id': state.task_id,
            'current_stage': state.current_stage.value,
            'status': state.status.value,
            'checkpoints': [
                {
                    'stage': cp.stage.value,
                    'status': cp.status.value,
                    'input_data': cp.input_data,
                    'output_data': cp.output_data,
                    'timestamp': cp.timestamp.isoformat(),
                    'duration_ms': cp.duration_ms,
                    'error': cp.error
                }
                for cp in state.checkpoints
            ],
            'metadata': state.metadata,
            'created_at': state.created_at.isoformat(),
            'updated_at': state.updated_at.isoformat()
        }
    
    def _deserialize_state(self, data: Dict) -> PipelineState:
        """Десериализация состояния из хранилища"""
        checkpoints = [
            StageCheckpoint(
                stage=PipelineStage(cp['stage']),
                status=PipelineStatus(cp['status']),
                input_data=cp['input_data'],
                output_data=cp['output_data'],
                timestamp=datetime.fromisoformat(cp['timestamp']),
                duration_ms=cp['duration_ms'],
                error=cp.get('error')
            )
            for cp in data['checkpoints']
        ]
        
        return PipelineState(
            task_id=data['task_id'],
            current_stage=PipelineStage(data['current_stage']),
            status=PipelineStatus(data['status']),
            checkpoints=checkpoints,
            metadata=data['metadata'],
            created_at=datetime.fromisoformat(data['created_at']),
            updated_at=datetime.fromisoformat(data['updated_at'])
        )
    
    def get_stats(self) -> Dict[str, Any]:
        """Статистика конвейера"""
        success_rate = (self.completed_tasks / self.total_tasks * 100) if self.total_tasks > 0 else 0
        
        return {
            'total_tasks': self.total_tasks,
            'completed': self.completed_tasks,
            'failed': self.failed_tasks,
            'recovered': self.recovered_tasks,
            'success_rate_pct': success_rate,
            'active_states': len(self.states),
            'backend': 'Redis' if self.use_redis else 'Memory'
        }
