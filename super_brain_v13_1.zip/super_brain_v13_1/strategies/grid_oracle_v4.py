#!/usr/bin/env python3
"""
GRID-ОРАКУЛ v4.0 ULTIMATE - Флагманская Сеточная Стратегия
ПОЛНАЯ РЕАЛИЗАЦИЯ ПО СПЕЦИФИКАЦИИ

4 Архитектурных Столпа:
1. Progressive Position Management - Прогрессивное усреднение
2. Smart Selective Closing - Гранулярное закрытие прибыльных ордеров
3. Dynamic Grid Adaptation - Адаптация на основе FSM/TRUTH ENGINE
4. Intelligent Drawdown Management - Превращение просадки в прибыль
"""
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from collections import deque
import time

logger = logging.getLogger(__name__)

@dataclass
class GridOrder:
    """Ордер в сетке с полной историей"""
    order_id: str
    symbol: str
    side: str  # 'BUY' or 'SELL'
    entry_price: float
    size: float
    remaining_size: float
    level: int
    timestamp: datetime = field(default_factory=datetime.now)
    realized_pnl: float = 0.0
    partial_closes: List[Dict] = field(default_factory=list)
    
    def get_current_pnl(self, current_price: float) -> float:
        """Текущий PnL по ордеру"""
        if self.remaining_size == 0:
            return self.realized_pnl
        
        if self.side == 'BUY':
            unrealized = (current_price - self.entry_price) * self.remaining_size
        else:
            unrealized = (self.entry_price - current_price) * self.remaining_size
        
        return self.realized_pnl + unrealized
    
    def is_profitable(self, current_price: float, min_profit_pct: float = 0.002) -> bool:
        """Проверка, прибылен ли ордер (мин 0.2%)"""
        if self.side == 'BUY':
            return current_price >= self.entry_price * (1 + min_profit_pct)
        else:
            return current_price <= self.entry_price * (1 - min_profit_pct)

@dataclass
class GridState:
    """Состояние сетки"""
    symbol: str
    regime: str  # 'TREND', 'FLAT', 'CHAOS'
    direction: str  # 'LONG', 'SHORT', 'DUAL'
    long_orders: List[GridOrder] = field(default_factory=list)
    short_orders: List[GridOrder] = field(default_factory=list)
    realized_pnl: float = 0.0
    total_margin_used: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    last_update: datetime = field(default_factory=datetime.now)
    
    def get_total_unrealized_pnl(self, current_price: float) -> float:
        """Общий нереализованный PnL"""
        total = 0.0
        for order in self.long_orders + self.short_orders:
            total += order.get_current_pnl(current_price)
        return total - self.realized_pnl  # Вычитаем уже зафиксированное


class GridOracleV4Ultimate:
    """
    GRID-ОРАКУЛ v4.0 ULTIMATE
    
    Флагманская сеточная стратегия с полной реализацией всех механизмов:
    - Progressive Position Management (linear/fibonacci/exponential)
    - Smart Selective Closing (гранулярное закрытие)
    - Dynamic Grid Adaptation (FSM/TRUTH ENGINE)
    - Intelligent Drawdown Management (антихрупкость)
    - Dual Grid (LONG+SHORT в FLAT)
    - Multi-level Verification (FSM + Breakout + TRUTH ENGINE)
    """
    
    def __init__(self, config: Optional[Dict] = None, genesis_engine=None, fsm=None, 
                 truth_engine=None, risk_manager=None, drawdown_manager=None, 
                 asset_config=None):
        self.config = config if config is not None else {}
        self.genesis = genesis_engine
        self.fsm = fsm
        self.truth_engine = truth_engine
        self.risk_manager = risk_manager
        self.drawdown_manager = drawdown_manager  # ✅ SmartDrawdownManager для multipliers
        self.asset_config = asset_config  # ✅ AssetConfigWrapper для параметров активов
        
        # Активные сетки по символам
        self.active_grids: Dict[str, GridState] = {}
        
        # OPUS 4.1: Position Memory Tracking
        self.position_memory: Dict[str, Dict] = {}
        
        # Progressive Position Management
        self.progression_type = self.config.get('progression_type', 'fibonacci')  # linear/fibonacci/exponential
        self.progression_params = {
            'linear_increment': 0.3,  # +30% на каждом уровне
            'exponential_growth': 1.5,  # x1.5 на каждом уровне
            'fibonacci_sequence': [1, 1, 2, 3, 5, 8, 13, 21]  # Fibonacci
        }
        
        # Smart Selective Closing
        self.min_profit_for_close = 0.002  # 0.2% минимум для частичного закрытия
        self.partial_close_size = 0.25  # Закрываем 25% от прибыльного ордера
        
        # Dynamic Grid Adaptation (FSM множители)
        self.regime_multipliers = {
            'TREND': {'range_mult': 1.5, 'step_mult': 1.2, 'levels': 5, 'dual_grid': False},
            'FLAT': {'range_mult': 0.8, 'step_mult': 0.6, 'levels': 9, 'dual_grid': True},
            'CHAOS': {'range_mult': 1.0, 'step_mult': 1.0, 'levels': 7, 'dual_grid': False}
        }
        
        # Drawdown Management
        self.accumulate_on_manipulation = True  # Набираем позицию при MANIPULATION_SQUEEZE
        self.manipulation_grid_density_mult = 1.8  # x1.8 плотность при манипуляции
        
        # Breakout Detection
        self.atr_breakout_threshold = 1.5  # 1.5 ATR для подтверждения пробоя
        self.adx_trend_threshold = 22  # ADX > 22 для подтверждения тренда
        
        # Порог корреляции для мульти-активной торговли
        self.correlation_threshold = 0.3
        
        # История для обучения
        self.trade_history = deque(maxlen=1000)
        
        logger.info("GRID-ОРАКУЛ v4.0 ULTIMATE initialized")
        logger.info(f"  Progression: {self.progression_type}")
        logger.info(f"  Regime multipliers: {self.regime_multipliers}")
    
    # ============================================================================
    # OPUS 4.1: POSITION MEMORY & SELECTIVE CLOSING
    # ============================================================================
    
    def update_position_memory(self, symbol: str, order: GridOrder, action: str = 'open'):
        """
        OPUS 4.1: Обновление памяти позиций
        
        Args:
            symbol: Символ актива
            order: GridOrder объект
            action: 'open', 'partial_close', 'full_close'
        """
        if symbol not in self.position_memory:
            self.position_memory[symbol] = {
                'total_entries': 0,
                'total_exits': 0,
                'avg_entry_price': 0.0,
                'current_exposure': 0.0,
                'realized_pnl': 0.0,
                'best_level_hit': 0,
                'orders_history': []
            }
        
        mem = self.position_memory[symbol]
        
        if action == 'open':
            mem['total_entries'] += 1
            mem['current_exposure'] += order.size * order.entry_price
            mem['best_level_hit'] = max(mem['best_level_hit'], order.level)
            mem['orders_history'].append({
                'order_id': order.order_id,
                'entry_price': order.entry_price,
                'size': order.size,
                'level': order.level,
                'timestamp': order.timestamp
            })
            
            total_size = sum(o['size'] for o in mem['orders_history'])
            weighted_price = sum(o['entry_price'] * o['size'] for o in mem['orders_history'])
            mem['avg_entry_price'] = weighted_price / total_size if total_size > 0 else 0
            
        elif action == 'partial_close':
            mem['total_exits'] += 1
            if order.partial_closes:
                closed_value = order.partial_closes[-1]['size'] * order.partial_closes[-1]['price']
                mem['current_exposure'] -= closed_value
                mem['realized_pnl'] += order.partial_closes[-1]['pnl']
            
        elif action == 'full_close':
            mem['total_exits'] += 1
            mem['current_exposure'] -= order.remaining_size * order.entry_price
            mem['realized_pnl'] += order.realized_pnl
    
    def selective_close_positions(self, symbol: str, current_price: float, 
                                   market_data: Dict) -> List[Dict]:
        """
        OPUS 4.1: Селективное закрытие прибыльных позиций
        
        Returns:
            List[Dict]: Список ордеров на частичное закрытие
        """
        close_orders = []
        grid_state = self.active_grids.get(symbol)
        
        if not grid_state:
            return close_orders
        
        reversal_prob = 0.0
        if self.genesis:
            reversal_data = self.genesis.calculate_reversal_probability(symbol, market_data)
            reversal_prob = reversal_data.get('probability', 0.0)
        
        all_orders = grid_state.long_orders + grid_state.short_orders
        
        for order in all_orders:
            if order.remaining_size == 0:
                continue
            
            if not order.is_profitable(current_price, self.min_profit_for_close):
                continue
            
            close_portion = self.calculate_close_portion(
                order, current_price, reversal_prob, market_data
            )
            
            if close_portion > 0:
                close_size = order.remaining_size * close_portion
                
                if order.side == 'BUY':
                    pnl = (current_price - order.entry_price) * close_size
                else:
                    pnl = (order.entry_price - current_price) * close_size
                
                order.partial_closes.append({
                    'size': close_size,
                    'price': current_price,
                    'pnl': pnl,
                    'timestamp': datetime.now()
                })
                
                order.remaining_size -= close_size
                order.realized_pnl += pnl
                
                self.update_position_memory(symbol, order, 'partial_close')
                
                close_orders.append({
                    'order_id': order.order_id,
                    'symbol': symbol,
                    'side': 'SELL' if order.side == 'BUY' else 'BUY',
                    'size': close_size,
                    'price': current_price,
                    'reason': 'selective_profit_taking',
                    'reversal_prob': reversal_prob
                })
                
                logger.info(f"📤 Selective close: {symbol} {order.side} {close_size:.4f} @ {current_price} "
                           f"(profit: {pnl:.2f}, reversal_prob: {reversal_prob:.2f})")
        
        return close_orders
    
    def calculate_close_portion(self, order: GridOrder, current_price: float, 
                                reversal_prob: float, market_data: Dict) -> float:
        """
        OPUS 4.1: Расчет доли закрытия позиции
        
        Returns:
            float: Доля от 0.0 до 1.0
        """
        if order.side == 'BUY':
            profit_pct = (current_price - order.entry_price) / order.entry_price
        else:
            profit_pct = (order.entry_price - current_price) / order.entry_price
        
        base_portion = self.partial_close_size
        
        if reversal_prob > 0.75:
            base_portion = min(0.5, base_portion * 1.5)
        elif reversal_prob > 0.85:
            base_portion = 1.0
        
        if profit_pct > 0.01:
            base_portion = min(0.75, base_portion * 1.3)
        
        volume_spike = market_data.get('volume_ratio', 1.0) > 2.0
        if volume_spike and profit_pct > 0.005:
            base_portion = min(1.0, base_portion * 1.2)
        
        return min(base_portion, 1.0)
    
    # ============================================================================
    # PROGRESSIVE POSITION MANAGEMENT
    # ============================================================================
    
    def calculate_progressive_size(self, base_size: float, level: int) -> float:
        """
        Progressive Position Management: расчет размера ордера
        
        Args:
            base_size: Базовый размер позиции
            level: Уровень сетки (0, 1, 2, ...)
        """
        if self.progression_type == 'linear':
            increment = self.progression_params['linear_increment']
            return base_size * (1 + level * increment)
        
        elif self.progression_type == 'fibonacci':
            fib_seq = self.progression_params['fibonacci_sequence']
            fib_index = min(level, len(fib_seq) - 1)
            return base_size * fib_seq[fib_index]
        
        elif self.progression_type == 'exponential':
            growth = self.progression_params['exponential_growth']
            return base_size * (growth ** level)
        
        return base_size
    
    def calculate_dynamic_grid_geometry(self, symbol: str, current_price: float, 
                                        atr: float, fsm_regime: str, 
                                        truth_verdict: str, confidence: float = 0.5,
                                        current_dd: float = 0.0) -> Dict:
        """
        Dynamic Grid Adaptation: расчет геометрии сетки на основе FSM, TRUTH ENGINE и SmartDrawdownManager
        
        Интеграция:
        - FSM: базовые multipliers для режима
        - TRUTH ENGINE: адаптация к манипуляциям
        - SmartDrawdownManager: multipliers для grid_density и position_size
        
        Returns:
            {
                'buy_levels': [...],
                'sell_levels': [...],
                'dual_grid': bool,
                'regime': str,
                'density_mult': float,
                'position_size_mult': float
            }
        """
        # Базовые множители от FSM
        regime_params = self.regime_multipliers.get(fsm_regime, self.regime_multipliers['TREND'])
        
        range_mult = regime_params['range_mult']
        step_mult = regime_params['step_mult']
        num_levels = regime_params['levels']
        dual_grid = regime_params['dual_grid']
        
        # ✅ ИНТЕГРАЦИЯ: SmartDrawdownManager multipliers
        position_size_mult = 1.0
        if self.drawdown_manager:
            try:
                # Получаем accumulated_profit из position_memory если доступен
                accumulated_profit = 0.0
                if symbol in self.position_memory:
                    accumulated_profit = self.position_memory[symbol].get('accumulated_profit', 0.0)
                
                dd_analysis = self.drawdown_manager.analyze_drawdown(
                    current_dd=current_dd,
                    truth_verdict=truth_verdict,
                    confidence=confidence,
                    asset=symbol,
                    accumulated_profit=accumulated_profit
                )
                
                # Применяем multipliers из SmartDrawdownManager
                density_from_sdm = dd_analysis.get('grid_density_mult', 1.0)
                position_size_mult = dd_analysis.get('position_size_mult', 1.0)
                
                logger.info(f"✅ SDM multipliers applied: density={density_from_sdm:.2f}x, position={position_size_mult:.2f}x")
                logger.info(f"   Mode: {dd_analysis.get('mode')}, Action: {dd_analysis.get('action')}")
                
                # Применяем density multiplier
                step_mult *= (2.0 - density_from_sdm)  # Инвертируем: density 1.5 -> step 0.5
                num_levels = int(num_levels * density_from_sdm)
                
            except Exception as e:
                logger.warning(f"Failed to get SDM multipliers: {e}")
        
        # Адаптация к TRUTH ENGINE вердикту (дополнительная)
        density_mult = 1.0
        if truth_verdict == "Manipulation_Squeeze" and self.accumulate_on_manipulation:
            # При манипуляции увеличиваем плотность сетки (если SDM не сделал это)
            if not self.drawdown_manager:
                density_mult = self.manipulation_grid_density_mult
                step_mult *= 0.7  # Сужаем шаг
                num_levels = int(num_levels * 1.3)  # Больше уровней
                logger.info(f"🎯 MANIPULATION detected: increasing grid density to {density_mult}x")
        
        # Расчет базового шага
        base_step = (atr / current_price) * step_mult * density_mult
        
        # Генерация уровней
        buy_levels = []
        sell_levels = []
        
        for i in range(num_levels):
            level = i + 1
            
            # Buy levels (ниже текущей цены)
            buy_distance = base_step * level
            buy_price = current_price * (1 - buy_distance)
            buy_size = self.calculate_progressive_size(1.0, i)  # Нормализованный размер
            
            buy_levels.append({
                'level': level,
                'price': buy_price,
                'distance_pct': buy_distance * 100,
                'size_mult': buy_size
            })
            
            # Sell levels (выше текущей цены)
            sell_distance = base_step * level
            sell_price = current_price * (1 + sell_distance)
            sell_size = self.calculate_progressive_size(1.0, i)
            
            sell_levels.append({
                'level': level,
                'price': sell_price,
                'distance_pct': sell_distance * 100,
                'size_mult': sell_size
            })
        
        return {
            'buy_levels': buy_levels,
            'sell_levels': sell_levels,
            'dual_grid': dual_grid,
            'regime': fsm_regime,
            'density_mult': density_mult,
            'position_size_mult': position_size_mult,  # ✅ Добавлено из SDM
            'base_step_pct': base_step * 100,
            'num_levels': num_levels
        }
    
    def smart_selective_closing(self, grid_state: GridState, current_price: float) -> Dict:
        """
        Smart Selective Closing: гранулярное закрытие прибыльных ордеров
        
        Ключевая инновация: закрываем только прибыльные ордера частями,
        постоянно снижая риск и фиксируя прибыль
        """
        closed_orders = []
        total_closed_pnl = 0.0
        
        # Обрабатываем LONG ордера
        for order in grid_state.long_orders:
            if order.remaining_size > 0 and order.is_profitable(current_price, self.min_profit_for_close):
                # Ордер прибылен! Закрываем часть
                close_size = order.remaining_size * self.partial_close_size
                close_pnl = (current_price - order.entry_price) * close_size
                
                order.remaining_size -= close_size
                order.realized_pnl += close_pnl
                order.partial_closes.append({
                    'timestamp': datetime.now(),
                    'price': current_price,
                    'size': close_size,
                    'pnl': close_pnl
                })
                
                closed_orders.append({
                    'order_id': order.order_id,
                    'side': 'LONG',
                    'close_price': current_price,
                    'close_size': close_size,
                    'pnl': close_pnl
                })
                
                total_closed_pnl += close_pnl
                
                logger.info(f"✂️ Partial close LONG: {order.order_id} @ ${current_price:.2f}, "
                           f"size: {close_size:.4f}, PnL: ${close_pnl:.2f}")
        
        # Обрабатываем SHORT ордера
        for order in grid_state.short_orders:
            if order.remaining_size > 0 and order.is_profitable(current_price, self.min_profit_for_close):
                close_size = order.remaining_size * self.partial_close_size
                close_pnl = (order.entry_price - current_price) * close_size
                
                order.remaining_size -= close_size
                order.realized_pnl += close_pnl
                order.partial_closes.append({
                    'timestamp': datetime.now(),
                    'price': current_price,
                    'size': close_size,
                    'pnl': close_pnl
                })
                
                closed_orders.append({
                    'order_id': order.order_id,
                    'side': 'SHORT',
                    'close_price': current_price,
                    'close_size': close_size,
                    'pnl': close_pnl
                })
                
                total_closed_pnl += close_pnl
                
                logger.info(f"✂️ Partial close SHORT: {order.order_id} @ ${current_price:.2f}, "
                           f"size: {close_size:.4f}, PnL: ${close_pnl:.2f}")
        
        # Обновляем реализованный PnL
        grid_state.realized_pnl += total_closed_pnl
        
        return {
            'closed_orders': closed_orders,
            'total_pnl': total_closed_pnl,
            'count': len(closed_orders)
        }
    
    def verify_breakout(self, current_price: float, prev_range: Tuple[float, float], 
                        atr: float, adx: float) -> bool:
        """
        Многоуровневая верификация пробоя для закрытия контр-сетки
        
        Проверяет:
        1. Пробой диапазона более чем на 1.5 ATR
        2. ADX > 22 (подтверждение тренда)
        """
        range_low, range_high = prev_range
        
        # Проверка пробоя
        if current_price > range_high:
            breakout_distance = current_price - range_high
        elif current_price < range_low:
            breakout_distance = range_low - current_price
        else:
            return False  # Цена внутри диапазона
        
        # Проверка порогов
        atr_confirmed = breakout_distance >= (atr * self.atr_breakout_threshold)
        adx_confirmed = adx >= self.adx_trend_threshold
        
        return atr_confirmed and adx_confirmed
    
    def execute_grid_flip(self, symbol: str, new_regime: str, current_price: float,
                          truth_verdict: str) -> Dict:
        """
        Эшелонированный механизм переворота сетки
        
        Этапы:
        1. TREND -> FLAT: Активация контр-сетки (dual grid)
        2. FLAT -> TREND: Верификация через FSM + Breakout + TRUTH ENGINE
        3. Полное закрытие старой сетки при подтвержденном тренде
        """
        grid_state = self.active_grids.get(symbol)
        if not grid_state:
            return {'error': 'No active grid'}
        
        old_regime = grid_state.regime
        result = {'action': 'none', 'details': {}}
        
        # Этап 1: TREND -> FLAT (Буферная зона)
        if old_regime == 'TREND' and new_regime == 'FLAT':
            logger.info(f"🔄 Grid flip: TREND -> FLAT for {symbol}")
            logger.info(f"   Activating DUAL GRID (buffer zone)")
            
            grid_state.regime = new_regime
            grid_state.direction = 'DUAL'
            
            result = {
                'action': 'activate_dual_grid',
                'details': {
                    'old_regime': old_regime,
                    'new_regime': new_regime,
                    'long_orders': len(grid_state.long_orders),
                    'short_orders_activated': True
                }
            }
        
        # Этап 2: FLAT -> TREND (Финальная верификация и переворот)
        elif old_regime == 'FLAT' and new_regime == 'TREND':
            # Требуется TRUTH ENGINE подтверждение
            if truth_verdict != 'Trend_Impulse':
                logger.info(f"⚠️ Breakout not confirmed by TRUTH ENGINE: {truth_verdict}")
                logger.info(f"   Keeping DUAL GRID active (false breakout protection)")
                return {
                    'action': 'keep_dual_grid',
                    'details': {
                        'reason': 'TRUTH ENGINE did not confirm Trend_Impulse',
                        'verdict': truth_verdict
                    }
                }
            
            logger.info(f"🔄 Grid flip: FLAT -> TREND for {symbol}")
            logger.info(f"   TRUTH ENGINE confirmed: {truth_verdict}")
            logger.info(f"   Closing old grid and flipping")
            
            # Определяем направление нового тренда
            if current_price > grid_state.long_orders[0].entry_price if grid_state.long_orders else 0:
                # Цена выше - восходящий тренд
                new_direction = 'LONG'
                # Закрываем SHORT позиции
                for order in grid_state.short_orders:
                    logger.info(f"   Closing SHORT order: {order.order_id}")
                grid_state.short_orders = []
            else:
                # Нисходящий тренд
                new_direction = 'SHORT'
                # Закрываем LONG позиции
                for order in grid_state.long_orders:
                    logger.info(f"   Closing LONG order: {order.order_id}")
                grid_state.long_orders = []
            
            grid_state.regime = new_regime
            grid_state.direction = new_direction
            
            result = {
                'action': 'complete_flip',
                'details': {
                    'old_regime': old_regime,
                    'new_regime': new_regime,
                    'new_direction': new_direction,
                    'truth_verdict': truth_verdict
                }
            }
        
        return result
    
    def handle_regime_change(self, symbol: str, old_regime: str, new_regime: str, 
                            current_price: float, truth_verdict: str = 'Consolidation_Range',
                            market_data: Optional[Dict] = None) -> Dict:
        """
        OPUS 4.1: Явная обработка смены рыночного режима
        
        Унифицированный интерфейс для обработки FSM transitions.
        Использует execute_grid_flip() для реализации логики.
        
        Args:
            symbol: Торговый символ
            old_regime: Предыдущий режим (TREND/FLAT/CHAOS)
            new_regime: Новый режим
            current_price: Текущая цена
            truth_verdict: Вердикт TRUTH ENGINE
            market_data: Дополнительные рыночные данные (ADX, ATR, etc.)
        
        Returns:
            Dict с результатом обработки и рекомендациями
        """
        try:
            logger.info(f"🔄 handle_regime_change triggered: {symbol} {old_regime} -> {new_regime}")
            
            grid_state = self.active_grids.get(symbol)
            if not grid_state:
                return {
                    'action': 'no_grid',
                    'message': f'No active grid for {symbol}',
                    'recommendation': 'create_new_grid'
                }
            
            result = self.execute_grid_flip(
                symbol=symbol,
                new_regime=new_regime,
                current_price=current_price,
                truth_verdict=truth_verdict
            )
            
            if self.fsm and market_data:
                regime_params = self.fsm.get_grid_regime_params(new_regime)
                result['regime_params'] = regime_params
            
            adx = market_data.get('adx', 25) if market_data else 25
            if new_regime == 'TREND' and adx > 30:
                result['confidence_level'] = 'HIGH'
                result['recommendation'] = 'increase_position_size'
            elif new_regime == 'FLAT':
                result['confidence_level'] = 'MEDIUM'
                result['recommendation'] = 'enable_dual_grid'
            elif new_regime == 'CHAOS':
                result['confidence_level'] = 'LOW'
                result['recommendation'] = 'reduce_exposure'
            
            logger.info(f"✅ Regime change handled: {result.get('action', 'unknown')}")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Error handling regime change: {e}")
            return {
                'error': str(e),
                'action': 'error',
                'recommendation': 'monitor_and_retry'
            }
    
    def create_grid(self, symbol: str, current_price: float, atr: float, 
                    fsm_regime: str, truth_verdict: str, capital: float,
                    confidence: float = 0.7, current_dd: float = 0.0) -> GridState:
        """
        Создание новой сетки с ПОЛНОЙ интеграцией всех механизмов
        
        Интеграция:
        - AssetConfigWrapper: динамический capital если доступен
        - SmartDrawdownManager: multipliers через geometry
        """
        # ✅ ИНТЕГРАЦИЯ: Получаем capital из AssetConfigWrapper если доступен
        if self.asset_config:
            asset_capital = self.asset_config.get_grid_capital(symbol)
            logger.info(f"✅ Using AssetConfigWrapper: ${asset_capital:.2f} (override provided ${capital:.2f})")
            capital = asset_capital
        
        # ✅ ИНТЕГРАЦИЯ: Расчет геометрии сетки с SDM multipliers
        geometry = self.calculate_dynamic_grid_geometry(
            symbol, current_price, atr, fsm_regime, truth_verdict,
            confidence, current_dd
        )
        
        # Определение направления
        if geometry['dual_grid']:
            direction = 'DUAL'
        else:
            # В тренде определяем по FSM или другим индикаторам
            direction = 'LONG'  # Упрощенно, в реальности смотрим на направление тренда
        
        # Создаем состояние сетки
        grid_state = GridState(
            symbol=symbol,
            regime=fsm_regime,
            direction=direction
        )
        
        # Добавляем в активные
        self.active_grids[symbol] = grid_state
        
        logger.info(f"✅ Grid created for {symbol}")
        logger.info(f"   Regime: {fsm_regime}, Direction: {direction}")
        logger.info(f"   Levels: {geometry['num_levels']}, Dual: {geometry['dual_grid']}")
        logger.info(f"   Base step: {geometry['base_step_pct']:.2f}%")
        
        return grid_state
    
    def calculate_optimal_levels(self, current_price: float, atr: float, regime: str, fib_levels: Optional[List] = None) -> Dict:
        """
        Расчет оптимальных уровней сетки (упрощенная версия для совместимости)
        
        Args:
            current_price: Текущая цена
            atr: ATR для расчета расстояний
            regime: Рыночный режим (TREND/FLAT/CHAOS)
            fib_levels: Уровни Фибоначчи (опционально)
        """
        # Используем геометрию сетки
        geometry = self.calculate_dynamic_grid_geometry(
            symbol='BTC',  # Упрощенно
            current_price=current_price,
            atr=atr,
            fsm_regime=regime,
            truth_verdict='Consolidation_Range'  # Дефолтный
        )
        
        return {
            'buy_levels': geometry['buy_levels'],
            'sell_levels': geometry['sell_levels'],
            'dual_grid': geometry['dual_grid'],
            'num_levels': geometry['num_levels'],
            'base_step_pct': geometry['base_step_pct'],
            'level_distance_pct': geometry['base_step_pct']  # Для совместимости
        }
    
    def get_stats(self) -> Dict:
        """Статистика по всем активным сеткам"""
        stats = {
            'active_grids': len(self.active_grids),
            'total_realized_pnl': sum(g.realized_pnl for g in self.active_grids.values()),
            'grids': {}
        }
        
        for symbol, grid in self.active_grids.items():
            stats['grids'][symbol] = {
                'regime': grid.regime,
                'direction': grid.direction,
                'long_orders': len(grid.long_orders),
                'short_orders': len(grid.short_orders),
                'realized_pnl': grid.realized_pnl
            }
        
        return stats


# Алиас для обратной совместимости
GridOracleV4 = GridOracleV4Ultimate


if __name__ == "__main__":
    print("✅ GRID-ОРАКУЛ v4.0 ULTIMATE создан")
