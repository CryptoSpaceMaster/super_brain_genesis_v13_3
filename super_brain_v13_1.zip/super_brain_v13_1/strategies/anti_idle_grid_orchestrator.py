#!/usr/bin/env python3
"""
Anti-Idle Grid Orchestrator v4 - 100% Opus 4.1 Specification
Интеллектуальный портфельный менеджер с GUARANTEED ASSETS и корреляционным анализом
"""
import logging
import asyncio
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)

class GridMode(Enum):
    """Режимы работы сетки"""
    ACCUMULATION = "ACCUMULATION"
    DISTRIBUTION = "DISTRIBUTION"
    NEUTRAL = "NEUTRAL"

@dataclass
class AssetSelectionResult:
    """Результат отбора активов для торговли"""
    guaranteed: List[str] = field(default_factory=list)      # Гарантированные активы (BTC, ETH)
    optimized: List[str] = field(default_factory=list)       # Оптимизированные активы
    total: List[str] = field(default_factory=list)           # Полный список
    allocations: Dict[str, float] = field(default_factory=dict)  # Распределение капитала
    scores: Dict[str, float] = field(default_factory=dict)   # Оценки активов
    regime: str = "FLAT"                                     # Текущий режим рынка
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class AssetScore:
    """Оценка актива по 4 параметрам"""
    symbol: str
    trend_strength: float    # 30% веса - сила тренда
    volatility_score: float  # 25% веса - оптимальность волатильности
    volume_score: float      # 25% веса - ликвидность
    correlation_penalty: float  # 20% веса - штраф за корреляцию
    total_score: float       # Итоговая оценка

class AntiIdleGridOrchestrator:
    """
    Anti-Idle Grid Orchestrator v4 - Интеллектуальный портфельный менеджер
    
    Ключевые функции:
    1. GUARANTEED ASSETS - приоритетные активы всегда в портфеле
    2. 4-шаговый процесс отбора (VIP → Кастинг → Скоринг → Аллокация)
    3. Корреляционный анализ с мягким штрафом
    4. Умное распределение капитала
    5. Адаптация к FSM режимам
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        
        # GUARANTEED ASSETS - всегда в портфеле
        self.guaranteed_assets = self.config.get('guaranteed_assets', ['BTCUSDT', 'ETHUSDT'])
        
        # Лимиты по режимам FSM
        self.max_concurrent = {
            'TREND': 15,
            'FLAT': 20,
            'CHAOS': 12
        }
        self.min_concurrent = {
            'TREND': 8,
            'FLAT': 10,
            'CHAOS': 6
        }
        
        # Весовые коэффициенты для скоринга (сумма = 1.0)
        self.scoring_weights = {
            'trend_strength': 0.30,      # 30% - сила тренда
            'volatility_score': 0.25,    # 25% - оптимальная волатильность для сетки
            'volume_score': 0.25,        # 25% - ликвидность
            'correlation_penalty': 0.20  # 20% - штраф за корреляцию
        }
        
        # Управление капиталом
        self.total_capital = self.config.get('total_capital', 5000)
        self.guaranteed_asset_min_allocation = 0.30  # 30% капитала минимум для VIP
        self.max_asset_allocation = 0.15  # Максимум 15% на один актив
        
        # Корреляция
        self.max_correlation_threshold = 0.75  # Жесткая блокировка если > 0.75
        self.correlation_penalty_factor = 0.5  # Мягкий штраф для 0.5-0.75
        self.enable_soft_correlation_penalty = True
        
        # Кэш корреляций
        self._correlation_matrix = None
        self._correlation_cache_time = None
        self._cache_ttl_minutes = 15
        
        # Активные сетки
        self.active_grids = {}
        self.grid_mode = GridMode.NEUTRAL
        
        # Параметры сетки
        self.min_grid_levels = 3
        self.max_grid_levels = 10
        self.base_grid_spacing = 0.005  # 0.5%
        
        # История отборов
        self.selection_history = []
        
        logger.info("Anti-Idle Grid Orchestrator v4 initialized - 100% Opus 4.1")
        logger.info(f"  GUARANTEED ASSETS: {self.guaranteed_assets}")
    
    async def select_assets(self, available_symbols: List[str], 
                           current_regime: str = "FLAT",
                           market_data: Optional[Dict] = None) -> AssetSelectionResult:
        """
        ГЛАВНЫЙ МЕТОД - 4-шаговый процесс отбора активов
        
        Шаг 1: VIP-список (GUARANTEED ASSETS)
        Шаг 2: Кастинг (определение свободных мест)
        Шаг 3: Скоринг (оценка кандидатов)
        Шаг 4: Аллокация (распределение капитала)
        
        Args:
            available_symbols: Доступные для торговли символы
            current_regime: Режим FSM (TREND/FLAT/CHAOS)
            market_data: Рыночные данные для анализа
        """
        
        logger.info(f"🎯 Asset Selection Started - Regime: {current_regime}")
        logger.info(f"   Available: {len(available_symbols)} symbols")
        
        # ============ ШАГ 1: VIP-СПИСОК (GUARANTEED ASSETS) ============
        guaranteed_selected = []
        for asset in self.guaranteed_assets:
            if asset in available_symbols:
                guaranteed_selected.append(asset)
                logger.info(f"   ✅ VIP: {asset} (guaranteed)")
        
        # Убираем VIP из пула для оптимизации
        remaining_symbols = [s for s in available_symbols if s not in guaranteed_selected]
        
        # ============ ШАГ 2: КАСТИНГ (определение свободных мест) ============
        target_count = self._get_target_count(current_regime)
        remaining_slots = max(0, target_count - len(guaranteed_selected))
        
        logger.info(f"   📋 Target: {target_count} assets, VIP: {len(guaranteed_selected)}, Free slots: {remaining_slots}")
        
        # ============ ШАГ 3: СКОРИНГ КАНДИДАТОВ ============
        optimized_selected = []
        asset_scores = {}
        
        if remaining_slots > 0 and remaining_symbols:
            # Рассчитываем корреляции
            await self._update_correlation_matrix(guaranteed_selected + remaining_symbols, market_data or {})
            
            # Оцениваем каждый кандидат
            scores = []
            for symbol in remaining_symbols:
                score = await self._calculate_asset_score(
                    symbol, 
                    guaranteed_selected,
                    market_data or {},
                    current_regime
                )
                scores.append(score)
                asset_scores[symbol] = score.total_score
            
            # Сортируем по итоговой оценке
            scores.sort(key=lambda x: x.total_score, reverse=True)
            
            # Отбираем топ-N по скорингу
            optimized_selected = [score.symbol for score in scores[:remaining_slots]]
            
            logger.info(f"   🏆 Top optimized assets:")
            for i, score in enumerate(scores[:min(5, len(scores))], 1):
                logger.info(f"      {i}. {score.symbol}: {score.total_score:.2f} "
                          f"(trend={score.trend_strength:.2f}, vol={score.volatility_score:.2f}, "
                          f"liq={score.volume_score:.2f}, corr_penalty={score.correlation_penalty:.2f})")
        
        # ============ ШАГ 4: АЛЛОКАЦИЯ КАПИТАЛА ============
        all_selected = guaranteed_selected + optimized_selected
        allocations = await self._calculate_allocations(
            all_selected,
            guaranteed_selected,
            asset_scores,
            current_regime
        )
        
        # Формируем результат
        result = AssetSelectionResult(
            guaranteed=guaranteed_selected,
            optimized=optimized_selected,
            total=all_selected,
            allocations=allocations,
            scores=asset_scores,
            regime=current_regime,
            timestamp=datetime.now()
        )
        
        # Сохраняем в историю
        self.selection_history.append(result)
        
        logger.info(f"✅ Selection Complete: {len(all_selected)} assets selected")
        logger.info(f"   Guaranteed: {len(guaranteed_selected)}, Optimized: {len(optimized_selected)}")
        logger.info(f"   Total allocation: ${sum(allocations.values()):.2f}")
        
        return result
    
    def _get_target_count(self, regime: str) -> int:
        """Определяет целевое количество активов по режиму FSM"""
        max_count = self.max_concurrent.get(regime, 15)
        min_count = self.min_concurrent.get(regime, 8)
        
        # Берем среднее (можно адаптировать по волатильности)
        return (max_count + min_count) // 2
    
    async def _calculate_asset_score(self, symbol: str, already_selected: List[str],
                                     market_data: Optional[Dict] = None, regime: str = "FLAT") -> AssetScore:
        """
        СКОРИНГ АКТИВА по 4 параметрам:
        1. Сила тренда (30%)
        2. Волатильность (25%)
        3. Объем/ликвидность (25%)
        4. Корреляция (20% штраф)
        """
        
        # Получаем данные актива
        asset_data = market_data.get(symbol, {}) if market_data else {}
        
        # 1. СИЛА ТРЕНДА (30%)
        trend_strength = self._calculate_trend_strength(symbol, asset_data, regime)
        
        # 2. ВОЛАТИЛЬНОСТЬ (25%)
        volatility_score = self._calculate_volatility_score(symbol, asset_data, regime)
        
        # 3. ОБЪЕМ/ЛИКВИДНОСТЬ (25%)
        volume_score = self._calculate_volume_score(symbol, asset_data)
        
        # 4. КОРРЕЛЯЦИЯ (20% штраф)
        correlation_penalty = await self._calculate_correlation_penalty(symbol, already_selected)
        
        # Итоговая оценка (взвешенная сумма)
        total_score = (
            trend_strength * self.scoring_weights['trend_strength'] +
            volatility_score * self.scoring_weights['volatility_score'] +
            volume_score * self.scoring_weights['volume_score'] -
            correlation_penalty * self.scoring_weights['correlation_penalty']  # ШТРАФ
        )
        
        return AssetScore(
            symbol=symbol,
            trend_strength=trend_strength,
            volatility_score=volatility_score,
            volume_score=volume_score,
            correlation_penalty=correlation_penalty,
            total_score=max(0, total_score)  # Не может быть отрицательной
        )
    
    def _calculate_trend_strength(self, symbol: str, asset_data: Dict, regime: str) -> float:
        """
        Сила тренда (0-1)
        В TREND режиме - важнее, во FLAT - менее важно
        """
        
        # Используем ADX или упрощенный расчет
        adx = asset_data.get('ADX', 25)
        
        # Нормализуем ADX: 0-100 -> 0-1
        trend_score = min(adx / 100, 1.0)
        
        # Адаптация к режиму
        if regime == 'TREND':
            trend_score *= 1.2  # Усиливаем важность
        elif regime == 'FLAT':
            trend_score *= 0.8  # Снижаем важность
        
        return min(trend_score, 1.0)
    
    def _calculate_volatility_score(self, symbol: str, asset_data: Dict, regime: str) -> float:
        """
        Оптимальность волатильности для сеточной торговли (0-1)
        Идеал: средняя волатильность (не слишком низкая, не слишком высокая)
        """
        
        atr = asset_data.get('ATR', 100)
        price = asset_data.get('price', 65000)
        
        # ATR в процентах от цены
        atr_pct = (atr / price) * 100 if price > 0 else 0
        
        # Оптимальный диапазон: 2-5% для сеток
        if 2.0 <= atr_pct <= 5.0:
            score = 1.0
        elif atr_pct < 2.0:
            # Слишком низкая волатильность
            score = atr_pct / 2.0
        else:
            # Слишком высокая волатильность
            score = max(0, 1.0 - (atr_pct - 5.0) / 5.0)
        
        return max(0, min(score, 1.0))
    
    def _calculate_volume_score(self, symbol: str, asset_data: Dict) -> float:
        """
        Оценка ликвидности по объему (0-1)
        Высокий объем = высокая оценка
        """
        
        volume_24h = asset_data.get('volume_24h', 0)
        
        # Нормализуем (для BTC ~30B, для альтов меньше)
        if 'BTC' in symbol:
            threshold = 20_000_000_000  # 20B
        elif 'ETH' in symbol:
            threshold = 10_000_000_000  # 10B
        else:
            threshold = 100_000_000     # 100M
        
        score = min(volume_24h / threshold, 1.0)
        
        return score
    
    async def _calculate_correlation_penalty(self, symbol: str, already_selected: List[str]) -> float:
        """
        Штраф за корреляцию с уже выбранными активами
        
        Логика:
        - Корреляция > 0.75: жесткая блокировка (штраф 1.0)
        - Корреляция 0.5-0.75: мягкий штраф (пропорциональный)
        - Корреляция < 0.5: нет штрафа
        """
        
        if not already_selected or not self._correlation_matrix:
            return 0.0
        
        penalties = []
        
        for selected_symbol in already_selected:
            corr = self._get_correlation(symbol, selected_symbol)
            
            if corr > self.max_correlation_threshold:
                # Жесткая блокировка
                penalties.append(1.0)
            elif corr > 0.5 and self.enable_soft_correlation_penalty:
                # Мягкий штраф пропорционально корреляции
                penalty = (corr - 0.5) / (self.max_correlation_threshold - 0.5)
                penalties.append(penalty * self.correlation_penalty_factor)
            else:
                penalties.append(0.0)
        
        # Средний штраф
        return float(np.mean(penalties)) if penalties else 0.0
    
    async def _update_correlation_matrix(self, symbols: List[str], market_data: Optional[Dict] = None):
        """Обновление корреляционной матрицы"""
        
        # Проверяем кэш
        if self._correlation_matrix and self._correlation_cache_time:
            age_minutes = (datetime.now() - self._correlation_cache_time).total_seconds() / 60
            if age_minutes < self._cache_ttl_minutes:
                return  # Кэш актуален
        
        # Упрощенная корреляционная матрица (в реальности нужны исторические цены)
        # Для демонстрации используем эвристику на основе категорий
        
        self._correlation_matrix = {}
        
        for sym1 in symbols:
            for sym2 in symbols:
                if sym1 == sym2:
                    self._correlation_matrix[(sym1, sym2)] = 1.0
                else:
                    # Эвристика: BTC-ETH высокая корреляция, альты между собой средняя
                    if 'BTC' in sym1 and 'ETH' in sym2 or 'ETH' in sym1 and 'BTC' in sym2:
                        corr = 0.85
                    elif 'BTC' in sym1 or 'BTC' in sym2:
                        corr = 0.60
                    elif 'ETH' in sym1 or 'ETH' in sym2:
                        corr = 0.55
                    else:
                        corr = 0.45  # Альткоины между собой
                    
                    self._correlation_matrix[(sym1, sym2)] = corr
        
        self._correlation_cache_time = datetime.now()
        logger.debug(f"Correlation matrix updated: {len(symbols)} symbols")
    
    def _get_correlation(self, symbol1: str, symbol2: str) -> float:
        """Получить корреляцию между двумя активами"""
        if not self._correlation_matrix:
            return 0.0
        
        return self._correlation_matrix.get((symbol1, symbol2), 0.0)
    
    async def _calculate_allocations(self, all_selected: List[str], 
                                     guaranteed: List[str],
                                     asset_scores: Dict[str, float],
                                     regime: str) -> Dict[str, float]:
        """
        УМНАЯ АЛЛОКАЦИЯ КАПИТАЛА
        
        Правила:
        1. Гарантированные активы получают минимум 30% капитала
        2. Остальной капитал распределяется пропорционально скорингу
        3. Максимум 15% на один актив
        """
        
        allocations = {}
        remaining_capital = self.total_capital
        
        # 1. Минимальная аллокация для GUARANTEED ASSETS
        if guaranteed:
            guaranteed_pool = self.total_capital * self.guaranteed_asset_min_allocation
            per_guaranteed = guaranteed_pool / len(guaranteed)
            
            for symbol in guaranteed:
                allocations[symbol] = min(per_guaranteed, self.total_capital * self.max_asset_allocation)
                remaining_capital -= allocations[symbol]
        
        # 2. Пропорциональное распределение остатка по скорингу
        optimized = [s for s in all_selected if s not in guaranteed]
        
        if optimized and remaining_capital > 0:
            # Сумма всех оценок оптимизированных активов
            total_score = sum(asset_scores.get(s, 0.5) for s in optimized)
            
            if total_score > 0:
                for symbol in optimized:
                    score = asset_scores.get(symbol, 0.5)
                    allocation = (score / total_score) * remaining_capital
                    
                    # Ограничение максимум 15% на актив
                    allocation = min(allocation, self.total_capital * self.max_asset_allocation)
                    
                    allocations[symbol] = allocation
        
        # 3. Нормализация если превысили лимит
        total_allocated = sum(allocations.values())
        if total_allocated > self.total_capital:
            factor = self.total_capital / total_allocated
            allocations = {k: v * factor for k, v in allocations.items()}
        
        return allocations
    
    def create_grid(self, symbol: str, capital: float, current_price: float, 
                   fsm_regime: str, truth_verdict: str, fib_data: Dict) -> Dict:
        """
        Создание адаптивной сетки ордеров (старый метод, сохранен для совместимости)
        """
        
        try:
            # Определение режима сетки
            if truth_verdict == "Manipulation_Squeeze":
                self.grid_mode = GridMode.ACCUMULATION
                grid_levels = 8
                spacing_mult = 1.2
            elif fsm_regime == "TREND":
                self.grid_mode = GridMode.DISTRIBUTION
                grid_levels = 5
                spacing_mult = 0.8
            else:
                self.grid_mode = GridMode.NEUTRAL
                grid_levels = 6
                spacing_mult = 1.0
            
            # Адаптация по Fibonacci
            confluence_score = fib_data.get('confluence_score', 0.5)
            if confluence_score > 0.7:
                spacing_mult *= 0.9
            
            # Расчет уровней сетки
            grid_spacing = self.base_grid_spacing * spacing_mult
            grid_orders = []
            
            position_size = capital / grid_levels
            
            for i in range(grid_levels):
                # Buy orders
                buy_price = current_price * (1 - grid_spacing * (i + 1))
                grid_orders.append({
                    'type': 'BUY',
                    'price': buy_price,
                    'size': position_size,
                    'level': i + 1
                })
                
                # Sell orders
                sell_price = current_price * (1 + grid_spacing * (i + 1))
                grid_orders.append({
                    'type': 'SELL',
                    'price': sell_price,
                    'size': position_size,
                    'level': i + 1
                })
            
            grid_id = f"{symbol}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            grid = {
                'grid_id': grid_id,
                'symbol': symbol,
                'mode': self.grid_mode.value,
                'levels': grid_levels,
                'spacing': grid_spacing,
                'orders': grid_orders,
                'capital_allocated': capital,
                'created_at': datetime.now().isoformat()
            }
            
            self.active_grids[grid_id] = grid
            
            logger.info(f"✅ Created grid {grid_id}: {grid_levels} levels, mode={self.grid_mode.value}")
            
            return grid
            
        except Exception as e:
            logger.error(f"❌ Error creating grid: {e}")
            return {'error': str(e)}
    
    def get_selection_history(self) -> List[AssetSelectionResult]:
        """Получить историю отборов активов"""
        return self.selection_history
    
    def get_active_grids(self) -> Dict:
        """Получить активные сетки"""
        return self.active_grids

if __name__ == "__main__":
    print("✅ Anti-Idle Grid Orchestrator v4 - 100% Opus 4.1 реализация")
