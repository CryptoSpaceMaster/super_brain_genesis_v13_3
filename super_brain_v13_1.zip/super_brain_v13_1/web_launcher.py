#!/usr/bin/env python3
"""
Web Server Launcher для СУПЕР МОЗГ GENESIS v13.1
Запускает HTTP сервер на порту 5000 для обслуживания визуального симулятора
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import logging
from web.server import run_server

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    print("="*80)
    print("🌐 СУПЕР МОЗГ GENESIS v13.1 - Web Server")
    print("="*80)
    print()
    
    run_server(client_manager=None, api_handler=None, port=5000)
