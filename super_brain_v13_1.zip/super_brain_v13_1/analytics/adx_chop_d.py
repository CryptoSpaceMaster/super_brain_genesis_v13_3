#!/usr/bin/env python3
"""
ADX-D и CHOP-D - Модернизированные индикаторы
ТОЧНО ПО ГЛАВЕ 5 ЭНЦИКЛОПЕДИИ
"""
from typing import Dict
import logging
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

class ADXDandCHOPD:
    """
    ADX-D и CHOP-D - ТОЧНО ПО ЭНЦИКЛОПЕДИИ
    
    Ключевые улучшения:
    - ADX-D: Адаптивная периодичность + SCF фактор
    - CHOP-D: Нормализация волатильности + SBV фактор
    """
    
    def __init__(self):
        self.adx_d_enabled = True
        self.chop_d_enabled = True
        
        self.volatility_regimes = ['LOW', 'NORMAL', 'HIGH', 'EXTREME']
        
        logger.info("ADX-D и CHOP-D initialized по энциклопедии")
    
    def calculate_adx_d(self, klines: pd.DataFrame, fsm_regime: str = 'FLAT', 
                       volatility_regime: str = 'NORMAL', confluence_score: float = 0.5) -> Dict:
        """
        Расчет ADX-D с контекстуальной интерпретацией
        ТОЧНО ПО ЭНЦИКЛОПЕДИИ
        """
        
        try:
            periods = {
                'TREND': {'LOW': 10, 'NORMAL': 14, 'HIGH': 18, 'EXTREME': 22},
                'FLAT': {'LOW': 12, 'NORMAL': 16, 'HIGH': 20, 'EXTREME': 24},
                'CHAOS': {'LOW': 8, 'NORMAL': 12, 'HIGH': 16, 'EXTREME': 20}
            }
            
            period = periods.get(fsm_regime, {}).get(volatility_regime, 14)
            
            if len(klines) >= period + 1:
                adx_value = self._calculate_adx_base(klines, period)
            else:
                price_change = abs(klines['close'].pct_change().iloc[-1]) * 100
                adx_value = min(50, price_change * 10)
            
            scf_factor = 0.5 + confluence_score
            modified_adx = adx_value * scf_factor
            
            if modified_adx > 30:
                context = 'Trend_Impulse'
            elif modified_adx > 20:
                context = 'Moderate_Trend'
            else:
                context = 'Consolidation_Range'
            
            return {
                'value': modified_adx,
                'context': context,
                'scf_factor': scf_factor,
                'base_adx': adx_value,
                'period_used': period,
                'regime': fsm_regime,
                'volatility': volatility_regime
            }
            
        except Exception as e:
            logger.error(f"❌ ADX-D calculation error: {e}")
            return {
                'value': 25.0,
                'context': 'ERROR',
                'error': str(e)
            }
    
    def calculate_chop_d(self, klines: pd.DataFrame, fib_atr_value: float = 0, 
                        is_in_golden_zone: bool = False, volatility_regime: str = 'NORMAL') -> Dict:
        """
        Расчет CHOP-D с нормализацией волатильности
        ТОЧНО ПО ЭНЦИКЛОПЕДИИ
        """
        
        try:
            period = 14
            
            if len(klines) >= period:
                tr_sum = self._calculate_true_range_sum(klines, period)
                
                high_low_range = (klines['high'].rolling(period).max() - 
                                 klines['low'].rolling(period).min()).iloc[-1]
                
                if high_low_range > 0:
                    raw_chop = 100 * np.log10(tr_sum / high_low_range) / np.log10(period)
                else:
                    raw_chop = 50.0
            else:
                price_volatility = klines['close'].pct_change().std() * 100
                raw_chop = min(100, max(0, 100 - price_volatility * 20))
            
            volatility_factors = {
                'LOW': 0.8,
                'NORMAL': 1.0,
                'HIGH': 1.2,
                'EXTREME': 1.5
            }
            
            vnf_factor = volatility_factors.get(volatility_regime, 1.0)
            normalized_chop = raw_chop * vnf_factor
            
            sbv_factor = 1.2 if is_in_golden_zone else 1.0
            final_chop = normalized_chop * sbv_factor
            
            final_chop = max(0, min(100, final_chop))
            
            if final_chop > 61.8:
                state = "Стабильная Консолидация"
                pbs_score = 0.2
            elif 38.2 <= final_chop <= 61.8:
                state = "Напряжение перед Пробоем"
                pbs_score = 0.7
            else:
                state = "Направленный Шум"
                pbs_score = 0.4
            
            return {
                'value': final_chop,
                'state': state,
                'pbs_score': pbs_score,
                'raw_chop': raw_chop,
                'vnf_factor': vnf_factor,
                'sbv_factor': sbv_factor,
                'volatility_regime': volatility_regime,
                'in_golden_zone': is_in_golden_zone
            }
            
        except Exception as e:
            logger.error(f"❌ CHOP-D calculation error: {e}")
            return {
                'value': 50.0,
                'state': 'ERROR',
                'error': str(e)
            }
    
    def _calculate_adx_base(self, klines: pd.DataFrame, period: int) -> float:
        """Базовый расчет ADX"""
        
        try:
            tr = self._calculate_true_range(klines)
            
            high_diff = klines['high'].diff()
            low_diff = -klines['low'].diff()
            
            plus_dm = np.where((high_diff > low_diff) & (high_diff > 0), high_diff, 0)
            minus_dm = np.where((low_diff > high_diff) & (low_diff > 0), low_diff, 0)
            
            plus_di = 100 * pd.Series(plus_dm).rolling(period).mean() / tr.rolling(period).mean()
            minus_di = 100 * pd.Series(minus_dm).rolling(period).mean() / tr.rolling(period).mean()
            
            dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
            adx = dx.rolling(period).mean().iloc[-1]
            
            return float(adx) if not pd.isna(adx) else 25.0
            
        except Exception as e:
            logger.debug(f"ADX base calculation error: {e}")
            return 25.0
    
    def _calculate_true_range(self, klines: pd.DataFrame) -> pd.Series:
        """Расчет True Range"""
        
        tr1 = klines['high'] - klines['low']
        tr2 = abs(klines['high'] - klines['close'].shift())
        tr3 = abs(klines['low'] - klines['close'].shift())
        
        return pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    def _calculate_true_range_sum(self, klines: pd.DataFrame, period: int) -> float:
        """Сумма True Range за период"""
        
        tr = self._calculate_true_range(klines)
        tr_sum = tr.rolling(period).sum().iloc[-1]
        
        return float(tr_sum) if not pd.isna(tr_sum) else 100.0

if __name__ == "__main__":
    print("✅ ADX-D и CHOP-D созданы с полной логикой по энциклопедии")
