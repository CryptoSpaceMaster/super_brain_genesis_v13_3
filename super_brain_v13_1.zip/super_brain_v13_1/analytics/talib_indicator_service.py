#!/usr/bin/env python3
"""
TA-Lib Indicator Service
Центральный сервис для расчета технических индикаторов через TA-Lib
"""
import talib
import numpy as np
import pandas as pd
from typing import Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

class TalibIndicatorService:
    """
    Wrapper для TA-Lib с сохранением контракта выходных данных
    Заменяет ручные расчеты индикаторов на проверенные имплементации TA-Lib
    """
    
    def __init__(self):
        self.version = talib.__version__
        self.available_functions = talib.get_functions()
        logger.info(f"✅ TA-Lib Service initialized (v{self.version}, {len(self.available_functions)} functions)")
    
    def validate_klines(self, klines: pd.DataFrame) -> bool:
        """Валидация klines dataframe"""
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        
        if not isinstance(klines, pd.DataFrame):
            return False
        
        for col in required_columns:
            if col not in klines.columns:
                logger.error(f"Missing required column: {col}")
                return False
        
        if len(klines) < 20:
            logger.warning(f"Insufficient data: {len(klines)} bars (minimum 20)")
            return False
        
        return True
    
    def prepare_arrays(self, klines: pd.DataFrame) -> Dict[str, np.ndarray]:
        """Подготовка массивов для TA-Lib (удаление NaN, конвертация типов)"""
        return {
            'open': klines['open'].ffill().to_numpy(dtype=np.float64),
            'high': klines['high'].ffill().to_numpy(dtype=np.float64),
            'low': klines['low'].ffill().to_numpy(dtype=np.float64),
            'close': klines['close'].ffill().to_numpy(dtype=np.float64),
            'volume': klines['volume'].fillna(0).to_numpy(dtype=np.float64)
        }
    
    def calculate_rsi(self, close: np.ndarray, period: int = 14) -> float:
        """
        RSI (Relative Strength Index) через TA-Lib
        Returns: float (0-100)
        """
        try:
            rsi = talib.RSI(close, timeperiod=period)
            value = rsi[-1]
            return float(value) if not np.isnan(value) else 50.0
        except Exception as e:
            logger.error(f"RSI calculation error: {e}")
            return 50.0
    
    def calculate_atr(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> float:
        """
        ATR (Average True Range) через TA-Lib
        Returns: float
        """
        try:
            atr = talib.ATR(high, low, close, timeperiod=period)
            value = atr[-1]
            return float(value) if not np.isnan(value) else 100.0
        except Exception as e:
            logger.error(f"ATR calculation error: {e}")
            return 100.0
    
    def calculate_adx(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> float:
        """
        ADX (Average Directional Index) через TA-Lib
        Returns: float (0-100)
        """
        try:
            adx = talib.ADX(high, low, close, timeperiod=period)
            value = adx[-1]
            return float(value) if not np.isnan(value) else 25.0
        except Exception as e:
            logger.error(f"ADX calculation error: {e}")
            return 25.0
    
    def calculate_bollinger_bands(self, close: np.ndarray, period: int = 20, nbdevup: float = 2.0, nbdevdn: float = 2.0) -> Dict[str, float]:
        """
        Bollinger Bands через TA-Lib
        Returns: {'upper': float, 'middle': float, 'lower': float}
        """
        try:
            upper, middle, lower = talib.BBANDS(close, timeperiod=period, nbdevup=nbdevup, nbdevdn=nbdevdn)
            
            return {
                'upper': float(upper[-1]) if not np.isnan(upper[-1]) else 0.0,
                'middle': float(middle[-1]) if not np.isnan(middle[-1]) else 0.0,
                'lower': float(lower[-1]) if not np.isnan(lower[-1]) else 0.0
            }
        except Exception as e:
            logger.error(f"Bollinger Bands calculation error: {e}")
            return {'upper': 0.0, 'middle': 0.0, 'lower': 0.0}
    
    def calculate_macd(self, close: np.ndarray, fastperiod: int = 12, slowperiod: int = 26, signalperiod: int = 9) -> Dict[str, float]:
        """
        MACD (Moving Average Convergence Divergence) через TA-Lib
        Returns: {'macd': float, 'signal': float, 'hist': float}
        """
        try:
            macd, signal, hist = talib.MACD(close, fastperiod=fastperiod, slowperiod=slowperiod, signalperiod=signalperiod)
            
            return {
                'macd': float(macd[-1]) if not np.isnan(macd[-1]) else 0.0,
                'signal': float(signal[-1]) if not np.isnan(signal[-1]) else 0.0,
                'hist': float(hist[-1]) if not np.isnan(hist[-1]) else 0.0
            }
        except Exception as e:
            logger.error(f"MACD calculation error: {e}")
            return {'macd': 0.0, 'signal': 0.0, 'hist': 0.0}
    
    def calculate_stoch(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, 
                       fastk_period: int = 14, slowk_period: int = 3, slowd_period: int = 3) -> Dict[str, float]:
        """
        Stochastic Oscillator через TA-Lib
        Returns: {'slowk': float, 'slowd': float}
        """
        try:
            slowk, slowd = talib.STOCH(high, low, close, fastk_period=fastk_period, 
                                      slowk_period=slowk_period, slowd_period=slowd_period)
            
            return {
                'slowk': float(slowk[-1]) if not np.isnan(slowk[-1]) else 50.0,
                'slowd': float(slowd[-1]) if not np.isnan(slowd[-1]) else 50.0
            }
        except Exception as e:
            logger.error(f"Stochastic calculation error: {e}")
            return {'slowk': 50.0, 'slowd': 50.0}
    
    def calculate_cmo(self, close: np.ndarray, period: int = 14) -> float:
        """
        CMO (Chande Momentum Oscillator) через TA-Lib
        Returns: float (-100 to +100)
        """
        try:
            cmo = talib.CMO(close, timeperiod=period)
            value = cmo[-1]
            return float(value) if not np.isnan(value) else 0.0
        except Exception as e:
            logger.error(f"CMO calculation error: {e}")
            return 0.0
    
    def calculate_aroon(self, high: np.ndarray, low: np.ndarray, period: int = 14) -> Dict[str, float]:
        """
        Aroon Indicator через TA-Lib
        Returns: {'aroon_up': float, 'aroon_down': float}
        """
        try:
            aroon_up, aroon_down = talib.AROON(high, low, timeperiod=period)
            
            return {
                'aroon_up': float(aroon_up[-1]) if not np.isnan(aroon_up[-1]) else 50.0,
                'aroon_down': float(aroon_down[-1]) if not np.isnan(aroon_down[-1]) else 50.0
            }
        except Exception as e:
            logger.error(f"Aroon calculation error: {e}")
            return {'aroon_up': 50.0, 'aroon_down': 50.0}
    
    def calculate_mfi(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, volume: np.ndarray, period: int = 14) -> float:
        """
        MFI (Money Flow Index) через TA-Lib
        Returns: float (0-100)
        """
        try:
            mfi = talib.MFI(high, low, close, volume, timeperiod=period)
            value = mfi[-1]
            return float(value) if not np.isnan(value) else 50.0
        except Exception as e:
            logger.error(f"MFI calculation error: {e}")
            return 50.0
    
    def calculate_cci(self, high: np.ndarray, low: np.ndarray, close: np.ndarray, period: int = 14) -> float:
        """
        CCI (Commodity Channel Index) через TA-Lib
        Returns: float
        """
        try:
            cci = talib.CCI(high, low, close, timeperiod=period)
            value = cci[-1]
            return float(value) if not np.isnan(value) else 0.0
        except Exception as e:
            logger.error(f"CCI calculation error: {e}")
            return 0.0
    
    def calculate_obv(self, close: np.ndarray, volume: np.ndarray) -> float:
        """
        OBV (On Balance Volume) через TA-Lib
        Returns: float
        """
        try:
            obv = talib.OBV(close, volume)
            value = obv[-1]
            return float(value) if not np.isnan(value) else 0.0
        except Exception as e:
            logger.error(f"OBV calculation error: {e}")
            return 0.0
    
    def calculate_all_basic_indicators(self, klines: pd.DataFrame) -> Dict:
        """
        Расчет всех основных индикаторов через TA-Lib
        Returns: Dict со всеми индикаторами
        """
        if not self.validate_klines(klines):
            return {}
        
        arrays = self.prepare_arrays(klines)
        
        try:
            return {
                'rsi_14': self.calculate_rsi(arrays['close'], 14),
                'atr_14': self.calculate_atr(arrays['high'], arrays['low'], arrays['close'], 14),
                'adx_14': self.calculate_adx(arrays['high'], arrays['low'], arrays['close'], 14),
                'bbands_20_2': self.calculate_bollinger_bands(arrays['close'], 20, 2.0, 2.0),
                'macd': self.calculate_macd(arrays['close'], 12, 26, 9),
                'stoch': self.calculate_stoch(arrays['high'], arrays['low'], arrays['close'], 14, 3, 3),
                'cmo_14': self.calculate_cmo(arrays['close'], 14),
                'aroon_14': self.calculate_aroon(arrays['high'], arrays['low'], 14),
                'mfi_14': self.calculate_mfi(arrays['high'], arrays['low'], arrays['close'], arrays['volume'], 14),
                'cci_14': self.calculate_cci(arrays['high'], arrays['low'], arrays['close'], 14),
                'obv': self.calculate_obv(arrays['close'], arrays['volume'])
            }
        except Exception as e:
            logger.error(f"Batch indicators calculation error: {e}")
            return {}
