#!/usr/bin/env python3
"""
Executor Layer - Исполнительный уровень
ТОЧНО ПО ЭНЦИКЛОПЕДИИ
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)

class OrderStatus(Enum):
    """Статусы ордеров"""
    PENDING = "PENDING"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"

class OrderType(Enum):
    """Типы ордеров"""
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP_LOSS = "STOP_LOSS"
    TAKE_PROFIT = "TAKE_PROFIT"

class ExecutorLayer:
    """
    Executor Layer - Исполнительный уровень
    
    Функции:
    - Управление ордерами
    - Валидация сделок
    - Контроль рисков перед исполнением
    - Симуляция исполнения (для тестирования)
    """
    
    def __init__(self, config: Optional[Dict] = None, order_execution_provider=None):
        self.config = config or {}
        self.orders = []
        self.positions = []
        self.order_id_counter = 1
        
        self.order_execution_provider = order_execution_provider
        self.simulation_mode = order_execution_provider is None
        
        mode = "SIMULATION" if self.simulation_mode else "REAL EXECUTION"
        logger.info(f"Executor Layer initialized ({mode})")
    
    async def create_order(self, symbol: str, side: str, order_type: str, 
                          quantity: float, price: Optional[float] = None,
                          stop_loss: Optional[float] = None,
                          take_profit: Optional[float] = None) -> Dict:
        """
        Создание ордера (async для поддержки реального исполнения)
        
        Args:
            symbol: Торговый символ
            side: BUY или SELL
            order_type: Тип ордера (MARKET, LIMIT)
            quantity: Количество
            price: Цена (для LIMIT)
            stop_loss: Уровень Stop Loss
            take_profit: Уровень Take Profit
        """
        
        try:
            # Валидация параметров
            if quantity <= 0:
                return {'error': 'Invalid quantity'}
            
            if order_type == 'LIMIT' and price is None:
                return {'error': 'Price required for LIMIT order'}
            
            if self.simulation_mode:
                order_id = f"ORD_{self.order_id_counter}"
                self.order_id_counter += 1
                
                order = {
                    'order_id': order_id,
                    'symbol': symbol,
                    'side': side,
                    'type': order_type,
                    'quantity': quantity,
                    'price': price,
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'status': OrderStatus.PENDING.value,
                    'created_at': datetime.now().isoformat(),
                    'filled_at': None,
                    'filled_price': None
                }
                
                self.orders.append(order)
                self._simulate_fill(order)
                
                logger.info(f"✅ Order created (SIMULATED): {order_id} {side} {quantity} {symbol}")
                return order
            
            else:
                from providers import OrderSide, OrderType
                
                ccxt_side = OrderSide.BUY if side.upper() == 'BUY' else OrderSide.SELL
                ccxt_type = OrderType.MARKET if order_type.upper() == 'MARKET' else OrderType.LIMIT
                
                params = {}
                if stop_loss:
                    params['stopLoss'] = {'triggerPrice': stop_loss}
                if take_profit:
                    params['takeProfit'] = {'triggerPrice': take_profit}
                
                real_order = await self.order_execution_provider.create_order(
                    symbol=symbol,
                    side=ccxt_side,
                    order_type=ccxt_type,
                    amount=quantity,
                    price=price,
                    params=params
                )
                
                order = {
                    'order_id': real_order['order_id'],
                    'symbol': symbol,
                    'side': side,
                    'type': order_type,
                    'quantity': quantity,
                    'price': real_order['price'],
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'status': real_order['status'],
                    'created_at': real_order['timestamp'].isoformat(),
                    'filled_at': real_order['timestamp'].isoformat() if real_order['status'] == 'filled' else None,
                    'filled_price': real_order['price'],
                    'filled': real_order['filled'],
                    'remaining': real_order['remaining']
                }
                
                self.orders.append(order)
                
                if real_order['filled'] > 0:
                    position = {
                        'position_id': f"POS_{len(self.positions) + 1}",
                        'order_id': order['order_id'],
                        'symbol': symbol,
                        'side': side,
                        'quantity': real_order['filled'],
                        'entry_price': real_order['price'],
                        'stop_loss': stop_loss,
                        'take_profit': take_profit,
                        'opened_at': order['created_at'],
                        'closed_at': None,
                        'pnl': 0
                    }
                    self.positions.append(position)
                
                logger.info(f"✅ Order created (REAL): {order['order_id']} {side} {quantity} {symbol}")
                return order
            
        except Exception as e:
            logger.error(f"❌ Error creating order: {e}")
            return {'error': str(e)}
    
    def _simulate_fill(self, order: Dict):
        """Симуляция исполнения ордера"""
        
        order['status'] = OrderStatus.FILLED.value
        order['filled_at'] = datetime.now().isoformat()
        
        # Для MARKET используем текущую цену (или заданную)
        if order['type'] == 'MARKET':
            order['filled_price'] = order.get('price', 60000)  # Дефолтная цена
        else:
            order['filled_price'] = order['price']
        
        # Создаем позицию
        position = {
            'position_id': f"POS_{len(self.positions) + 1}",
            'order_id': order['order_id'],
            'symbol': order['symbol'],
            'side': order['side'],
            'quantity': order['quantity'],
            'entry_price': order['filled_price'],
            'stop_loss': order.get('stop_loss'),
            'take_profit': order.get('take_profit'),
            'opened_at': order['filled_at'],
            'closed_at': None,
            'pnl': 0
        }
        
        self.positions.append(position)
        
        logger.debug(f"Simulated fill: {order['order_id']} at {order['filled_price']}")
    
    async def close_position(self, position_id: str, close_price: Optional[float] = None) -> Dict:
        """
        Закрытие позиции (async для реального исполнения)
        
        Args:
            position_id: ID позиции
            close_price: Цена закрытия (для симуляции)
        """
        
        position = next((p for p in self.positions if p['position_id'] == position_id), None)
        
        if not position:
            return {'error': 'Position not found'}
        
        if position['closed_at']:
            return {'error': 'Position already closed'}
        
        try:
            if self.simulation_mode:
                if close_price is None:
                    return {'error': 'close_price required in simulation mode'}
                
                if position['side'] == 'BUY':
                    pnl = (close_price - position['entry_price']) * position['quantity']
                else:
                    pnl = (position['entry_price'] - close_price) * position['quantity']
                
                position['closed_at'] = datetime.now().isoformat()
                position['close_price'] = close_price
                position['pnl'] = pnl
                
                logger.info(f"✅ Position closed (SIMULATED): {position_id}, PnL: ${pnl:.2f}")
                return position
            
            else:
                side_str = 'long' if position['side'] == 'BUY' else 'short'
                result = await self.order_execution_provider.close_position(
                    symbol=position['symbol'],
                    side=side_str
                )
                
                actual_close_price = result.get('price', position['entry_price'])
                
                if position['side'] == 'BUY':
                    pnl = (actual_close_price - position['entry_price']) * position['quantity']
                else:
                    pnl = (position['entry_price'] - actual_close_price) * position['quantity']
                
                position['closed_at'] = datetime.now().isoformat()
                position['close_price'] = actual_close_price
                position['pnl'] = pnl
                
                logger.info(f"✅ Position closed (REAL): {position_id}, PnL: ${pnl:.2f}")
                return position
        
        except Exception as e:
            logger.error(f"❌ Error closing position: {e}")
            return {'error': str(e)}
    
    def get_open_positions(self) -> List[Dict]:
        """Получение открытых позиций"""
        return [p for p in self.positions if p['closed_at'] is None]
    
    def get_order_history(self) -> List[Dict]:
        """История ордеров"""
        return self.orders
    
    def execute_progressive_order(self, symbol: str, side: str, base_size: float, 
                                  level: int, price: float, progression_type: str = 'fibonacci',
                                  metadata: Optional[Dict] = None) -> Dict:
        """
        OPUS 4.1: Исполнение прогрессивного ордера с метаданными
        
        Args:
            symbol: Символ актива
            side: BUY или SELL
            base_size: Базовый размер позиции
            level: Уровень сетки (0, 1, 2, ...)
            price: Цена исполнения
            progression_type: Тип прогрессии (linear/fibonacci/exponential)
            metadata: Дополнительные метаданные (reversal_prob, grid_id, etc.)
        
        Returns:
            Dict с результатом исполнения
        """
        try:
            progressive_params = {
                'linear_increment': 0.3,
                'exponential_growth': 1.5,
                'fibonacci_sequence': [1, 1, 2, 3, 5, 8, 13, 21]
            }
            
            if progression_type == 'linear':
                increment = progressive_params['linear_increment']
                actual_size = base_size * (1 + level * increment)
            elif progression_type == 'fibonacci':
                fib_seq = progressive_params['fibonacci_sequence']
                fib_index = min(level, len(fib_seq) - 1)
                actual_size = base_size * fib_seq[fib_index]
            elif progression_type == 'exponential':
                growth = progressive_params['exponential_growth']
                actual_size = base_size * (growth ** level)
            else:
                actual_size = base_size
            
            order_id = f"ORD_{self.order_id_counter}"
            self.order_id_counter += 1
            
            order = {
                'order_id': order_id,
                'symbol': symbol,
                'side': side,
                'type': 'LIMIT',
                'quantity': actual_size,
                'price': price,
                'status': OrderStatus.PENDING.value,
                'created_at': datetime.now().isoformat(),
                'filled_at': None,
                'filled_price': None,
                'progressive_level': level,
                'progression_type': progression_type,
                'base_size': base_size,
                'metadata': metadata or {}
            }
            
            self.orders.append(order)
            
            if self.simulation_mode:
                self._simulate_progressive_fill(order)
            
            logger.info(f"✅ Progressive order created: {order_id} {side} {actual_size:.4f} "
                       f"@ {price} (level {level}, {progression_type})")
            
            return order
            
        except Exception as e:
            logger.error(f"❌ Error creating progressive order: {e}")
            return {'error': str(e)}
    
    def _simulate_progressive_fill(self, order: Dict):
        """Симуляция исполнения прогрессивного ордера"""
        
        order['status'] = OrderStatus.FILLED.value
        order['filled_at'] = datetime.now().isoformat()
        order['filled_price'] = order['price']
        
        position = {
            'position_id': f"POS_{len(self.positions) + 1}",
            'order_id': order['order_id'],
            'symbol': order['symbol'],
            'side': order['side'],
            'quantity': order['quantity'],
            'entry_price': order['filled_price'],
            'progressive_level': order.get('progressive_level', 0),
            'progression_type': order.get('progression_type', 'linear'),
            'metadata': order.get('metadata', {}),
            'opened_at': order['filled_at'],
            'closed_at': None,
            'pnl': 0,
            'partial_closes': []
        }
        
        self.positions.append(position)
        
        logger.debug(f"Simulated progressive fill: {order['order_id']} "
                    f"level {order.get('progressive_level', 0)} at {order['filled_price']}")
    
    def execute_partial_close(self, position_id: str, close_size: float, close_price: float,
                              metadata: Optional[Dict] = None) -> Dict:
        """
        OPUS 4.1: Частичное закрытие позиции с метаданными
        
        Args:
            position_id: ID позиции
            close_size: Размер закрытия (часть от общей позиции)
            close_price: Цена закрытия
            metadata: Дополнительные метаданные (reason, grid_level, etc.)
        
        Returns:
            Dict с результатом частичного закрытия
        """
        try:
            position = next((p for p in self.positions if p['position_id'] == position_id), None)
            
            if not position:
                return {'error': 'Position not found'}
            
            if position.get('closed_at'):
                return {'error': 'Position already fully closed'}
            
            current_quantity = position['quantity']
            if close_size > current_quantity:
                return {'error': f'Close size {close_size} exceeds position quantity {current_quantity}'}
            
            if close_size <= 0:
                return {'error': 'Close size must be positive'}
            
            if position['side'] == 'BUY':
                pnl = (close_price - position['entry_price']) * close_size
            else:
                pnl = (position['entry_price'] - close_price) * close_size
            
            partial_close_record = {
                'timestamp': datetime.now().isoformat(),
                'close_price': close_price,
                'close_size': close_size,
                'pnl': pnl,
                'metadata': metadata or {}
            }
            
            if 'partial_closes' not in position:
                position['partial_closes'] = []
            position['partial_closes'].append(partial_close_record)
            
            position['quantity'] -= close_size
            
            if 'total_realized_pnl' not in position:
                position['total_realized_pnl'] = 0.0
            position['total_realized_pnl'] += pnl
            
            if position['quantity'] <= 0.0001:
                position['closed_at'] = datetime.now().isoformat()
                position['close_price'] = close_price
                position['pnl'] = position.get('total_realized_pnl', pnl)
                logger.info(f"✅ Position fully closed via partial closes: {position_id}")
            else:
                logger.info(f"✂️ Partial close: {position_id}, size: {close_size:.4f}, "
                           f"remaining: {position['quantity']:.4f}, PnL: ${pnl:.2f}")
            
            return {
                'position_id': position_id,
                'close_size': close_size,
                'close_price': close_price,
                'pnl': pnl,
                'remaining_quantity': position['quantity'],
                'total_realized_pnl': position.get('total_realized_pnl', pnl),
                'fully_closed': position['quantity'] <= 0.0001,
                'timestamp': partial_close_record['timestamp']
            }
            
        except Exception as e:
            logger.error(f"❌ Error executing partial close: {e}")
            return {'error': str(e)}
    
    def get_stats(self) -> Dict:
        """Статистика"""
        open_positions = self.get_open_positions()
        closed_positions = [p for p in self.positions if p['closed_at'] is not None]
        
        total_pnl = sum(p['pnl'] for p in closed_positions)
        
        return {
            'total_orders': len(self.orders),
            'open_positions': len(open_positions),
            'closed_positions': len(closed_positions),
            'total_pnl': total_pnl,
            'simulation_mode': self.simulation_mode
        }

if __name__ == "__main__":
    print("✅ Executor Layer создан")
