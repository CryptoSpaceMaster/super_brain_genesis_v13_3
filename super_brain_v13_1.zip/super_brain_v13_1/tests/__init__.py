"""Tests package for OPUS 4.1 compliance"""
