#!/usr/bin/env python3
"""
Regression Tests for TA-Lib Integration
Проверка numerical parity между TA-Lib и ручными расчетами
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TalibRegressionTests:
    """
    Regression tests для проверки совпадения результатов
    TA-Lib vs manual calculations
    """
    
    def __init__(self):
        self.test_data = self._generate_test_data()
        self.rsi_tolerance = 20
        self.percentage_tolerance = 5
        self.results = []
        
        try:
            from analytics.talib_indicator_service import TalibIndicatorService
            self.talib_service = TalibIndicatorService()
            logger.info("✅ TalibIndicatorService loaded")
        except Exception as e:
            logger.error(f"❌ Failed to load TalibIndicatorService: {e}")
            self.talib_service = None
        
        try:
            from analytics.indicators_complete import IndicatorsEngineComplete
            self.indicators_engine = IndicatorsEngineComplete()
            logger.info("✅ IndicatorsEngineComplete loaded")
        except Exception as e:
            logger.error(f"❌ Failed to load IndicatorsEngineComplete: {e}")
            self.indicators_engine = None
    
    def _generate_test_data(self, bars: int = 100) -> pd.DataFrame:
        """Генерация синтетических данных для тестов"""
        dates = pd.date_range(end=datetime.now(), periods=bars, freq='1h')
        
        base_price = 60000
        volatility = 500
        
        close_prices = []
        current_price = base_price
        
        for i in range(bars):
            change = np.random.randn() * volatility
            current_price += change
            close_prices.append(current_price)
        
        close_prices = np.array(close_prices)
        
        df = pd.DataFrame({
            'timestamp': dates,
            'open': close_prices + np.random.uniform(-100, 100, bars),
            'high': close_prices + np.random.uniform(100, 300, bars),
            'low': close_prices - np.random.uniform(100, 300, bars),
            'close': close_prices,
            'volume': np.random.uniform(1000000, 5000000, bars)
        })
        
        df['high'] = df[['open', 'close', 'high']].max(axis=1)
        df['low'] = df[['open', 'close', 'low']].min(axis=1)
        
        return df
    
    def test_rsi_parity(self):
        """Test RSI: TA-Lib vs Manual (different smoothing algorithms)"""
        if not self.talib_service:
            return {'test': 'RSI', 'status': 'SKIP', 'reason': 'TalibService not available'}
        
        try:
            period = 14
            close = self.test_data['close'].to_numpy(dtype=np.float64)
            
            talib_rsi = self.talib_service.calculate_rsi(close, period)
            
            manual_rsi = self._manual_rsi(self.test_data['close'], period)
            
            diff = abs(talib_rsi - manual_rsi)
            
            sanity_check = 0 <= talib_rsi <= 100
            tolerance_check = diff < self.rsi_tolerance
            passed = sanity_check and tolerance_check
            
            result = {
                'test': 'RSI',
                'status': 'PASS' if passed else 'FAIL',
                'talib': round(talib_rsi, 4),
                'manual': round(manual_rsi, 4),
                'diff': round(diff, 4),
                'threshold': self.rsi_tolerance,
                'sanity_check': 'OK' if sanity_check else 'FAIL',
                'note': 'TA-Lib uses Wilder EMA, manual uses SMA (both valid)'
            }
            
            self.results.append(result)
            return result
            
        except Exception as e:
            result = {'test': 'RSI', 'status': 'ERROR', 'error': str(e)}
            self.results.append(result)
            return result
    
    def test_atr_parity(self):
        """Test ATR: TA-Lib vs Manual"""
        if not self.talib_service:
            return {'test': 'ATR', 'status': 'SKIP', 'reason': 'TalibService not available'}
        
        try:
            period = 14
            
            talib_atr = self.talib_service.calculate_atr(
                self.test_data['high'].to_numpy(dtype=np.float64),
                self.test_data['low'].to_numpy(dtype=np.float64),
                self.test_data['close'].to_numpy(dtype=np.float64),
                period
            )
            
            manual_atr = self._manual_atr(self.test_data, period)
            
            diff_pct = abs(talib_atr - manual_atr) / manual_atr * 100
            passed = diff_pct < self.percentage_tolerance
            
            result = {
                'test': 'ATR',
                'status': 'PASS' if passed else 'FAIL',
                'talib': round(talib_atr, 2),
                'manual': round(manual_atr, 2),
                'diff_pct': round(diff_pct, 2),
                'threshold': '5%'
            }
            
            self.results.append(result)
            return result
            
        except Exception as e:
            result = {'test': 'ATR', 'status': 'ERROR', 'error': str(e)}
            self.results.append(result)
            return result
    
    def test_bollinger_bands_parity(self):
        """Test Bollinger Bands: TA-Lib vs Manual"""
        if not self.talib_service:
            return {'test': 'BBANDS', 'status': 'SKIP', 'reason': 'TalibService not available'}
        
        try:
            period = 20
            std_dev = 2.0
            
            talib_bb = self.talib_service.calculate_bollinger_bands(
                self.test_data['close'].to_numpy(dtype=np.float64),
                period, std_dev, std_dev
            )
            
            manual_bb = self._manual_bollinger_bands(self.test_data['close'], period, std_dev)
            
            upper_diff_pct = abs(talib_bb['upper'] - manual_bb['upper']) / manual_bb['upper'] * 100
            middle_diff_pct = abs(talib_bb['middle'] - manual_bb['middle']) / manual_bb['middle'] * 100
            lower_diff_pct = abs(talib_bb['lower'] - manual_bb['lower']) / manual_bb['lower'] * 100
            
            max_diff = max(upper_diff_pct, middle_diff_pct, lower_diff_pct)
            passed = max_diff < 1
            
            result = {
                'test': 'BBANDS',
                'status': 'PASS' if passed else 'FAIL',
                'talib_upper': round(talib_bb['upper'], 2),
                'manual_upper': round(manual_bb['upper'], 2),
                'max_diff_pct': round(max_diff, 2),
                'threshold': '1%'
            }
            
            self.results.append(result)
            return result
            
        except Exception as e:
            result = {'test': 'BBANDS', 'status': 'ERROR', 'error': str(e)}
            self.results.append(result)
            return result
    
    def _manual_rsi(self, prices: pd.Series, period: int) -> float:
        """Manual RSI calculation"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return float(rsi.iloc[-1])
    
    def _manual_atr(self, klines: pd.DataFrame, period: int) -> float:
        """Manual ATR calculation"""
        high = klines['high']
        low = klines['low']
        close = klines['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(period).mean()
        
        return float(atr.iloc[-1])
    
    def _manual_bollinger_bands(self, prices: pd.Series, period: int, std_dev: float) -> dict:
        """Manual Bollinger Bands calculation"""
        middle = prices.rolling(period).mean()
        std = prices.rolling(period).std()
        
        upper = middle + (std * std_dev)
        lower = middle - (std * std_dev)
        
        return {
            'upper': float(upper.iloc[-1]),
            'middle': float(middle.iloc[-1]),
            'lower': float(lower.iloc[-1])
        }
    
    def run_all_tests(self):
        """Запустить все тесты"""
        logger.info("="*80)
        logger.info("🧪 REGRESSION TESTS: TA-Lib vs Manual Calculations")
        logger.info("="*80)
        
        tests = [
            self.test_rsi_parity,
            self.test_atr_parity,
            self.test_bollinger_bands_parity
        ]
        
        for test_func in tests:
            result = test_func()
            self._print_result(result)
        
        self._print_summary()
    
    def _print_result(self, result: dict):
        """Печать результата теста"""
        status_symbol = {
            'PASS': '✅',
            'FAIL': '❌',
            'ERROR': '⚠️',
            'SKIP': '⏭️'
        }
        
        symbol = status_symbol.get(result['status'], '?')
        logger.info(f"\n{symbol} {result['test']}: {result['status']}")
        
        for key, value in result.items():
            if key not in ['test', 'status']:
                logger.info(f"   {key}: {value}")
    
    def _print_summary(self):
        """Печать итогов"""
        logger.info("\n" + "="*80)
        logger.info("📊 SUMMARY")
        logger.info("="*80)
        
        total = len(self.results)
        passed = sum(1 for r in self.results if r['status'] == 'PASS')
        failed = sum(1 for r in self.results if r['status'] == 'FAIL')
        errors = sum(1 for r in self.results if r['status'] == 'ERROR')
        skipped = sum(1 for r in self.results if r['status'] == 'SKIP')
        
        logger.info(f"Total Tests: {total}")
        logger.info(f"✅ Passed: {passed}")
        logger.info(f"❌ Failed: {failed}")
        logger.info(f"⚠️ Errors: {errors}")
        logger.info(f"⏭️ Skipped: {skipped}")
        
        if failed == 0 and errors == 0:
            logger.info("\n🎉 ALL TESTS PASSED! TA-Lib integration is correct!")
        else:
            logger.warning("\n⚠️ Some tests failed. Review the differences.")
        
        logger.info("="*80)

if __name__ == '__main__':
    tests = TalibRegressionTests()
    tests.run_all_tests()
