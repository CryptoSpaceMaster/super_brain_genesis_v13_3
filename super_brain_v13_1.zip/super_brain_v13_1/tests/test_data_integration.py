#!/usr/bin/env python3
"""
Интеграционный тест для проверки работы с реальными данными из PostgreSQL/CryptoQuant
"""
import asyncio
import json
import logging
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from providers.postgresql_data_provider import PostgreSQLDataProvider
from providers.cryptoquant_data_provider import CryptoQuantDataProvider
from providers.market_data_collector import MarketDataCollector
from analytics.lpi_v2 import LPIv2

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def test_postgresql_connection():
    """Тест подключения к PostgreSQL"""
    logger.info("=" * 80)
    logger.info("ТЕСТ 1: Подключение к PostgreSQL")
    logger.info("=" * 80)
    
    try:
        config_path = Path(__file__).parent.parent / "config" / "config.json"
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        db_config = config.get('database', {})
        provider = PostgreSQLDataProvider(db_config)
        
        logger.info(f"✅ PostgreSQLDataProvider инициализирован")
        logger.info(f"   Config: host={db_config.get('host')}, database={db_config.get('database')}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка подключения к PostgreSQL: {e}")
        return False

async def test_market_data_collection():
    """Тест сбора рыночных данных"""
    logger.info("\n" + "=" * 80)
    logger.info("ТЕСТ 2: Сбор рыночных данных через MarketDataCollector")
    logger.info("=" * 80)
    
    try:
        config_path = Path(__file__).parent.parent / "config" / "config.json"
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        collector = MarketDataCollector(config)
        
        symbol = "BTC/USDT"
        timeframe = "1h"
        
        logger.info(f"Загрузка данных для {symbol} ({timeframe})...")
        
        market_snapshot = collector.get_market_snapshot(symbol, timeframe)
        
        logger.info(f"\n📊 Результаты:")
        logger.info(f"   Источники данных:")
        logger.info(f"   - OHLCV: {'✅' if market_snapshot.get('ohlcv') is not None else '❌'}")
        logger.info(f"   - Ticker: {'✅' if market_snapshot.get('ticker') else '❌'}")
        logger.info(f"   - Orderbook: {'✅' if market_snapshot.get('orderbook') else '❌'}")
        logger.info(f"   - Trades: {'✅' if market_snapshot.get('trades') else '❌'}")
        logger.info(f"   - Funding: {'✅' if market_snapshot.get('funding') else '❌'}")
        logger.info(f"   - CryptoQuant: {'✅' if market_snapshot.get('cryptoquant') else '❌'}")
        
        if market_snapshot.get('ohlcv') is not None:
            logger.info(f"\n   OHLCV data shape: {market_snapshot['ohlcv'].shape}")
            logger.info(f"   Latest close: ${market_snapshot['ohlcv']['close'].iloc[-1]:.2f}")
        
        if market_snapshot.get('ticker'):
            ticker = market_snapshot['ticker']
            logger.info(f"\n   Ticker data:")
            logger.info(f"   - Last price: ${ticker.get('last_price', 0):.2f}")
            logger.info(f"   - 24h change: {ticker.get('percentage_change_24h', 0):.2f}%")
            logger.info(f"   - Volume: {ticker.get('volume_24h', 0):.2f}")
        
        if market_snapshot.get('trades'):
            trades = market_snapshot['trades']
            logger.info(f"\n   Trade data:")
            logger.info(f"   - CVD 5min: {trades.get('cvd_5min', 0):.2f}")
        
        if market_snapshot.get('orderbook'):
            orderbook = market_snapshot['orderbook']
            logger.info(f"\n   Orderbook data:")
            logger.info(f"   - OBI L5: {orderbook.get('obi_l5', 0):.4f}")
        
        if market_snapshot.get('funding'):
            funding = market_snapshot['funding']
            logger.info(f"\n   Funding data:")
            logger.info(f"   - Funding rate: {funding.get('funding_rate', 0):.6f}%")
            logger.info(f"   - Open interest: {funding.get('open_interest', 0):.0f}")
        
        if market_snapshot.get('cryptoquant'):
            cq = market_snapshot['cryptoquant']
            logger.info(f"\n   CryptoQuant data:")
            logger.info(f"   - Exchange netflow: {cq.get('exchange_netflow', 0):.2f}")
            logger.info(f"   - Whale ratio: {cq.get('whale_ratio', 0):.4f}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка сбора данных: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_lpi_with_real_data():
    """Тест LPI v2.0 с реальными данными"""
    logger.info("\n" + "=" * 80)
    logger.info("ТЕСТ 3: LPI v2.0 с реальными данными из PostgreSQL")
    logger.info("=" * 80)
    
    try:
        config_path = Path(__file__).parent.parent / "config" / "config.json"
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        collector = MarketDataCollector(config)
        lpi = LPIv2(config.get('lpi', {}))
        
        symbol = "BTC/USDT"
        timeframe = "1h"
        
        market_snapshot = collector.get_market_snapshot(symbol, timeframe)
        
        if market_snapshot.get('ohlcv') is not None:
            current_price = market_snapshot['ohlcv']['close'].iloc[-1]
            volume = market_snapshot['ohlcv']['volume'].iloc[-1]
        else:
            logger.error("❌ Нет OHLCV данных")
            return False
        
        lpi_market_data = {
            'price': current_price,
            'volume': volume,
            'change_24h': 0.0
        }
        
        if market_snapshot.get('ticker'):
            lpi_market_data['change_24h'] = market_snapshot['ticker'].get('percentage_change_24h', 0.0)
        
        lpi_derivatives_data = {
            'funding_rate': 0.0001,
            'open_interest': 0
        }
        
        if market_snapshot.get('funding'):
            lpi_derivatives_data['funding_rate'] = market_snapshot['funding'].get('funding_rate', 0.0001)
            lpi_derivatives_data['open_interest'] = market_snapshot['funding'].get('open_interest', 0)
        
        lpi_onchain_data = {
            'netflow': 0.0,
            'whale_ratio': 0.5
        }
        
        if market_snapshot.get('cryptoquant'):
            lpi_onchain_data['netflow'] = market_snapshot['cryptoquant'].get('exchange_netflow', 0.0)
            lpi_onchain_data['whale_ratio'] = market_snapshot['cryptoquant'].get('whale_ratio', 0.5)
        
        lpi_microstructure_data = {}
        if market_snapshot.get('trades'):
            lpi_microstructure_data['cvd'] = market_snapshot['trades'].get('cvd_5min', 0.0)
        
        if market_snapshot.get('orderbook'):
            lpi_microstructure_data['obi'] = market_snapshot['orderbook'].get('obi_l5', 0.0)
        
        lpi_result = lpi.calculate_lpi(
            market_data=lpi_market_data,
            derivatives_data=lpi_derivatives_data,
            on_chain_data=lpi_onchain_data,
            microstructure_data=lpi_microstructure_data
        )
        
        logger.info(f"\n📊 LPI v2.0 Результат:")
        logger.info(f"   Total LPI: {lpi_result.get('total', 0):.4f}")
        logger.info(f"   Pressure Level: {lpi_result.get('pressure_level', 'N/A')}")
        logger.info(f"   Version: {lpi_result.get('version', 'N/A')}")
        
        if 'components' in lpi_result:
            logger.info(f"\n   Компоненты:")
            for comp, value in lpi_result['components'].items():
                weight = lpi_result['component_weights'].get(comp, 0)
                logger.info(f"   - {comp}: {value:.4f} (weight: {weight:.2f})")
        
        if 'data_quality' in lpi_result:
            logger.info(f"\n   Качество данных: {lpi_result['data_quality']}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Ошибка расчета LPI: {e}")
        import traceback
        traceback.print_exc()
        return False

async def main():
    """Запуск всех тестов"""
    logger.info("\n" + "=" * 80)
    logger.info("ИНТЕГРАЦИОННОЕ ТЕСТИРОВАНИЕ: PostgreSQL + CryptoQuant")
    logger.info("=" * 80)
    
    results = {}
    
    results['postgresql'] = await test_postgresql_connection()
    
    results['data_collection'] = await test_market_data_collection()
    
    results['lpi'] = await test_lpi_with_real_data()
    
    logger.info("\n" + "=" * 80)
    logger.info("ИТОГИ ТЕСТИРОВАНИЯ")
    logger.info("=" * 80)
    
    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        logger.info(f"   {test_name}: {status}")
    
    all_passed = all(results.values())
    
    if all_passed:
        logger.info("\n🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ!")
    else:
        logger.info("\n⚠️  НЕКОТОРЫЕ ТЕСТЫ НЕ ПРОШЛИ")
    
    return all_passed

if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
