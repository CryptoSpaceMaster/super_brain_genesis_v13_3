#!/usr/bin/env python3
"""
OPUS 4.1 COMPLETE - Тесты для новых компонентов
Проверка: SimpleMarginCalculator, AEGIS v2.0 Complete, ExchangeAdapter
БЕЗ ЗАГЛУШЕК
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import logging
from risk.simple_margin_calculator import SimpleMarginCalculator
from risk.aegis_v2_complete import AEGISv2Complete
from core.exchange_adapter import ExchangeAdapter
from core.truth_engine_v2 import TruthEngineV2

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TestSimpleMarginCalculator:
    """Тесты SimpleMarginCalculator"""
    
    def test_btc_allocation(self):
        """Тест расчета маржи для BTC"""
        calc = SimpleMarginCalculator()
        
        result = calc.calculate(15000, 'BTCUSDT', daf=0.5)
        
        assert result['margin'] > 0
        assert result['leverage'] == 10
        assert result['position_size'] == result['margin'] * 10
        assert result['asset'] == 'BTCUSDT'
        
        logger.info(f"✅ BTC allocation: ${result['margin']:.2f} @ {result['leverage']}x = ${result['position_size']:.2f}")
    
    def test_deposit_scaling(self):
        """Тест масштабирования по размеру депозита"""
        calc = SimpleMarginCalculator()
        
        small_deposit = calc.calculate(4000, 'BTCUSDT', daf=0.5)
        medium_deposit = calc.calculate(15000, 'BTCUSDT', daf=0.5)
        large_deposit = calc.calculate(25000, 'BTCUSDT', daf=0.5)
        
        small_pct = small_deposit['margin'] / 4000
        medium_pct = medium_deposit['margin'] / 15000
        large_pct = large_deposit['margin'] / 25000
        
        assert small_pct < medium_pct
        assert large_pct > medium_pct
        
        logger.info(f"✅ Deposit scaling: {small_pct:.2%} → {medium_pct:.2%} → {large_pct:.2%}")
    
    def test_daf_adjustment(self):
        """Тест DAF корректировки"""
        calc = SimpleMarginCalculator()
        
        conservative = calc.calculate(15000, 'BTCUSDT', daf=0.2)
        neutral = calc.calculate(15000, 'BTCUSDT', daf=0.5)
        aggressive = calc.calculate(15000, 'BTCUSDT', daf=0.8)
        
        assert conservative['margin'] < neutral['margin']
        assert aggressive['margin'] > neutral['margin']
        
        logger.info(f"✅ DAF adjustment: ${conservative['margin']:.0f} → ${neutral['margin']:.0f} → ${aggressive['margin']:.0f}")
    
    def test_default_asset(self):
        """Тест обработки неизвестного актива"""
        calc = SimpleMarginCalculator()
        
        result = calc.calculate(15000, 'ADAUSDT', daf=0.5)
        
        assert result['leverage'] == 5
        assert result['base_allocation_pct'] == 0.013
        
        logger.info(f"✅ Default asset: {result['asset']} → {result['leverage']}x, {result['base_allocation_pct']:.1%}")


class TestAEGISv2Complete:
    """Тесты AEGIS v2.0 Complete"""
    
    def test_session_baseline(self):
        """Тест создания сессии с baseline"""
        aegis = AEGISv2Complete(initial_capital=10000)
        
        session = aegis.start_new_session()
        
        assert session['baseline_equity_usd'] == 10000
        assert aegis.baseline_equity_usd == 10000
        assert aegis.session_realized_pnl_usd == 0.0
        
        logger.info(f"✅ Session baseline: ${session['baseline_equity_usd']:,.2f}")
    
    def test_realized_pnl_tracking(self):
        """Тест учета реализованного PnL"""
        aegis = AEGISv2Complete(initial_capital=10000)
        aegis.start_new_session()
        
        aegis.record_realized_pnl(500, 'T1', 'GRID', 'BTCUSDT')
        aegis.record_realized_pnl(-200, 'T2', 'SCALP', 'ETHUSDT')
        aegis.record_realized_pnl(300, 'T3', 'GRID', 'SOLUSDT')
        
        assert aegis.session_realized_pnl_usd == 600
        assert len(aegis.pnl_ledger) == 3
        
        logger.info(f"✅ PnL tracking: ${aegis.session_realized_pnl_usd:+,.2f} from 3 trades")
    
    def test_risk_equity_calculation(self):
        """Тест расчета Risk Equity"""
        aegis = AEGISv2Complete(initial_capital=10000)
        aegis.start_new_session()
        
        aegis.record_realized_pnl(1500, 'T1', 'GRID', 'BTCUSDT')
        
        risk_equity = aegis.get_risk_equity_usd()
        
        assert risk_equity == 10000 + 1500
        assert risk_equity == aegis.baseline_equity_usd + aegis.session_realized_pnl_usd
        
        logger.info(f"✅ Risk Equity: ${risk_equity:,.2f} = Baseline ${aegis.baseline_equity_usd:,.2f} + PnL ${aegis.session_realized_pnl_usd:+,.2f}")
    
    def test_strategic_drawdown(self):
        """Тест расчета стратегической просадки"""
        aegis = AEGISv2Complete(initial_capital=10000)
        aegis.start_new_session()
        
        aegis.record_realized_pnl(2000, 'T1', 'GRID', 'BTCUSDT')
        
        aegis.record_realized_pnl(-1500, 'T2', 'SCALP', 'ETHUSDT')
        
        dd = aegis.calculate_strategic_drawdown()
        
        assert dd['peak_equity'] == 12000
        assert dd['current_equity'] == 10500
        assert dd['drawdown_usd'] == 1500
        
        logger.info(f"✅ Strategic drawdown: {dd['drawdown_pct']:.2f}% (${dd['drawdown_usd']:,.0f})")
    
    def test_can_open_order(self):
        """Тест тактической проверки ордера"""
        aegis = AEGISv2Complete(initial_capital=10000)
        aegis.start_new_session()
        
        check_ok = aegis.can_open_order(5000, 'BTCUSDT')
        check_fail = aegis.can_open_order(15000, 'ETHUSDT')
        
        assert check_ok['allowed'] == True
        assert check_fail['allowed'] == False
        assert 'reduce_size' in check_fail['suggested_action'] or 'block' in check_fail['suggested_action']
        
        logger.info(f"✅ Order check: $5K allowed, $15K blocked")
    
    def test_progressive_grid_limits(self):
        """Тест лимитов прогрессивной сетки"""
        aegis = AEGISv2Complete(initial_capital=10000)
        aegis.start_new_session()
        
        grid_params_ok = {
            'total_exposure': 2000,
            'num_levels': 5,
            'progressive_mult': 1.5
        }
        
        grid_params_bad = {
            'total_exposure': 1000,
            'num_levels': 15,
            'progressive_mult': 2.5
        }
        
        check_ok = aegis.check_progressive_grid_limits('BTCUSDT', grid_params_ok)
        check_bad = aegis.check_progressive_grid_limits('ETHUSDT', grid_params_bad)
        
        assert check_ok['allowed'] == True
        assert check_bad['allowed'] == False
        
        logger.info(f"✅ Grid limits: Normal params OK, Aggressive params blocked")


class TestExchangeAdapter:
    """Тесты ExchangeAdapter"""
    
    def test_initialization(self):
        """Тест инициализации адаптера"""
        adapter = ExchangeAdapter('binance', testnet=True, simulation_mode=True)
        
        assert adapter.exchange_name == 'binance'
        assert adapter.testnet == True
        
        logger.info(f"✅ Exchange adapter initialized: {adapter.exchange_name}")
    
    def test_balance_fetch(self):
        """Тест получения баланса"""
        adapter = ExchangeAdapter('binance', testnet=True, simulation_mode=True)
        
        balance = adapter.fetch_balance(cache_ttl=2)
        
        assert 'free' in balance
        assert 'used' in balance
        assert 'total' in balance
        assert isinstance(balance['free'], (int, float))
        
        logger.info(f"✅ Balance: Free=${balance['free']:,.2f}, Total=${balance['total']:,.2f}, Simulation={balance.get('simulation', False)}")
    
    def test_cache_mechanism(self):
        """Тест механизма кэширования"""
        adapter = ExchangeAdapter('binance', testnet=True, simulation_mode=True)
        
        import time
        
        balance1 = adapter.fetch_balance(cache_ttl=2)
        time.sleep(0.1)
        balance2 = adapter.fetch_balance(cache_ttl=2)
        
        assert balance1 == balance2
        
        logger.info(f"✅ Cache working: Same balance returned within TTL")
    
    def test_available_margin(self):
        """Тест получения доступной маржи"""
        adapter = ExchangeAdapter('binance', testnet=True, simulation_mode=True)
        
        available = adapter.get_available_margin_usd()
        
        assert isinstance(available, (int, float))
        assert available >= 0
        
        logger.info(f"✅ Available margin: ${available:,.2f}")


class TestIntegration:
    """Интеграционные тесты"""
    
    def test_margin_calc_with_truth_engine(self):
        """Тест SimpleMarginCalculator с TRUTH ENGINE"""
        truth = TruthEngineV2()
        calc = SimpleMarginCalculator()
        
        import numpy as np
        fake_data = {
            'rsi': np.array([50.0]),
            'adx': np.array([30.0]),
            'atr': np.array([100.0]),
            'lpi': np.array([0.6]),
            'volume_ratio': np.array([1.5])
        }
        
        truth_result = truth.analyze(fake_data)
        daf = truth_result['daf'] if isinstance(truth_result, dict) else truth_result.daf
        
        margin_result = calc.calculate(15000, 'BTCUSDT', daf=daf)
        
        assert 0.0 <= daf <= 1.0
        assert margin_result['margin'] > 0
        
        logger.info(f"✅ Integration: DAF={daf:.2f} → Margin=${margin_result['margin']:.2f}")
    
    def test_aegis_with_exchange(self):
        """Тест AEGIS с ExchangeAdapter"""
        adapter = ExchangeAdapter('binance', testnet=True, simulation_mode=True)
        aegis = AEGISv2Complete(initial_capital=10000, exchange_adapter=adapter)
        
        session = aegis.start_new_session()
        available = aegis.get_available_usd()
        
        assert session is not None
        assert available > 0
        
        logger.info(f"✅ AEGIS + Exchange: Session started, Available=${available:,.2f}")
    
    def test_real_mode_without_api_keys(self):
        """Тест что real mode без API ключей выбрасывает ошибку"""
        import os
        
        saved_key = os.getenv('BINANCE_API_KEY')
        saved_secret = os.getenv('BINANCE_API_SECRET')
        
        try:
            if 'BINANCE_API_KEY' in os.environ:
                del os.environ['BINANCE_API_KEY']
            if 'BINANCE_API_SECRET' in os.environ:
                del os.environ['BINANCE_API_SECRET']
            
            try:
                adapter = ExchangeAdapter('binance', testnet=True, simulation_mode=False)
                assert False, "Should have raised ValueError"
            except ValueError as e:
                assert "CRITICAL" in str(e)
                assert "API keys not found" in str(e)
                logger.info(f"✅ Real mode without API keys correctly raises error")
        finally:
            if saved_key:
                os.environ['BINANCE_API_KEY'] = saved_key
            if saved_secret:
                os.environ['BINANCE_API_SECRET'] = saved_secret


def run_all_tests():
    """Запуск всех тестов"""
    logger.info("\n" + "="*80)
    logger.info("🧪 OPUS 4.1 COMPLETE - FULL TEST SUITE")
    logger.info("="*80)
    
    logger.info("\n📋 Group 1: SimpleMarginCalculator")
    logger.info("-" * 80)
    smc_tests = TestSimpleMarginCalculator()
    smc_tests.test_btc_allocation()
    smc_tests.test_deposit_scaling()
    smc_tests.test_daf_adjustment()
    smc_tests.test_default_asset()
    
    logger.info("\n📋 Group 2: AEGIS v2.0 Complete")
    logger.info("-" * 80)
    aegis_tests = TestAEGISv2Complete()
    aegis_tests.test_session_baseline()
    aegis_tests.test_realized_pnl_tracking()
    aegis_tests.test_risk_equity_calculation()
    aegis_tests.test_strategic_drawdown()
    aegis_tests.test_can_open_order()
    aegis_tests.test_progressive_grid_limits()
    
    logger.info("\n📋 Group 3: ExchangeAdapter")
    logger.info("-" * 80)
    exchange_tests = TestExchangeAdapter()
    exchange_tests.test_initialization()
    exchange_tests.test_balance_fetch()
    exchange_tests.test_cache_mechanism()
    exchange_tests.test_available_margin()
    
    logger.info("\n📋 Group 4: Integration Tests")
    logger.info("-" * 80)
    integration_tests = TestIntegration()
    integration_tests.test_margin_calc_with_truth_engine()
    integration_tests.test_aegis_with_exchange()
    integration_tests.test_real_mode_without_api_keys()
    
    logger.info("\n" + "="*80)
    logger.info("✅ ALL OPUS 4.1 COMPLETE TESTS PASSED!")
    logger.info("="*80 + "\n")

if __name__ == "__main__":
    run_all_tests()
