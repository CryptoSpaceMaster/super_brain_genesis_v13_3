"""
Unit tests for OPUS 4.1 compliance features
- Progressive order execution
- Position memory edge cases
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from executor.executor_layer import ExecutorLayer
from strategies.grid_oracle_v4 import GridOracleV4Ultimate, GridOrder
from risk.aegis_v2 import AEGISv2
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TestProgressiveOrderExecution:
    """Тесты для progressive order execution"""
    
    def test_linear_progression(self):
        """Тест линейной прогрессии"""
        executor = ExecutorLayer()
        
        results = []
        for level in range(3):
            result = executor.execute_progressive_order(
                symbol="BTCUSDT",
                side="BUY",
                base_size=100,
                level=level,
                price=60000 - level * 100,
                progression_type="linear",
                metadata={'grid_id': 'test_grid_1'}
            )
            results.append(result)
        
        assert all('error' not in r for r in results)
        sizes = [r['quantity'] for r in results]
        assert abs(sizes[1] - 130) < 1
        assert abs(sizes[2] - 160) < 1
        
        logger.info(f"✅ Linear progression test passed: {sizes}")
    
    def test_fibonacci_progression(self):
        """Тест Fibonacci прогрессии"""
        executor = ExecutorLayer()
        
        fib_multipliers = [1, 1, 2, 3, 5]
        results = []
        
        for level in range(5):
            result = executor.execute_progressive_order(
                symbol="ETHUSDT",
                side="SELL",
                base_size=50,
                level=level,
                price=3000 + level * 50,
                progression_type="fibonacci",
                metadata={'grid_id': 'test_grid_2'}
            )
            results.append(result)
        
        assert all('error' not in r for r in results)
        sizes = [r['quantity'] for r in results]
        
        for i, mult in enumerate(fib_multipliers):
            expected_size = 50 * mult
            assert abs(sizes[i] - expected_size) < 0.01, f"Level {i}: expected {expected_size}, got {sizes[i]}"
        
        logger.info(f"✅ Fibonacci progression test passed: {sizes}")
    
    def test_exponential_progression(self):
        """Тест экспоненциальной прогрессии"""
        executor = ExecutorLayer()
        
        results = []
        for level in range(4):
            result = executor.execute_progressive_order(
                symbol="SOLUSDT",
                side="BUY",
                base_size=20,
                level=level,
                price=100 - level * 5,
                progression_type="exponential",
                metadata={'grid_id': 'test_grid_3'}
            )
            results.append(result)
        
        assert all('error' not in r for r in results)
        sizes = [r['quantity'] for r in results]
        
        for i in range(len(sizes)):
            expected_size = 20 * (1.5 ** i)
            assert abs(sizes[i] - expected_size) < 0.01
        
        logger.info(f"✅ Exponential progression test passed: {sizes}")
    
    def test_invalid_progression_type(self):
        """Тест некорректного типа прогрессии (fallback to base_size)"""
        executor = ExecutorLayer()
        
        result = executor.execute_progressive_order(
            symbol="BTCUSDT",
            side="BUY",
            base_size=100,
            level=0,
            price=60000,
            progression_type="invalid_type",
            metadata={'grid_id': 'test_grid_4'}
        )
        
        assert 'error' not in result
        assert result['quantity'] == 100
        logger.info(f"✅ Invalid progression type test passed: fallback to base_size {result['quantity']}")


class TestPositionMemory:
    """Тесты для position memory edge cases"""
    
    def test_position_open_tracking(self):
        """Тест отслеживания открытия позиции"""
        grid = GridOracleV4Ultimate(config={'progression': 'fibonacci'})
        
        order = GridOrder(
            order_id='TEST_1',
            symbol='BTCUSDT',
            entry_price=60000,
            size=0.1,
            remaining_size=0.1,
            side='BUY',
            level=1
        )
        
        grid.update_position_memory(
            symbol="BTCUSDT",
            order=order,
            action="open"
        )
        
        memory = grid.position_memory.get("BTCUSDT")
        assert memory is not None
        assert 'total_entries' in memory
        assert 'orders_history' in memory
        
        logger.info(f"✅ Position open tracking test passed")
    
    def test_partial_close_tracking(self):
        """Тест отслеживания частичного закрытия"""
        grid = GridOracleV4Ultimate(config={'progression': 'linear'})
        
        order_open = GridOrder(order_id='TEST_2', symbol='BTCUSDT', entry_price=60000, size=0.1, remaining_size=0.1, side='BUY', level=1)
        grid.update_position_memory("BTCUSDT", order_open, "open")
        
        order_close = GridOrder(order_id='TEST_3', symbol='BTCUSDT', entry_price=61000, size=0.05, remaining_size=0, side='SELL', level=1)
        grid.update_position_memory("BTCUSDT", order_close, "partial_close")
        
        memory = grid.position_memory.get("BTCUSDT")
        assert memory is not None
        assert memory['total_exits'] > 0
        
        logger.info(f"✅ Partial close tracking test passed")
    
    def test_full_close_tracking(self):
        """Тест отслеживания полного закрытия"""
        grid = GridOracleV4Ultimate(config={'progression': 'exponential'})
        
        order_open = GridOrder(order_id='TEST_4', symbol='ETHUSDT', entry_price=3000, size=1.0, remaining_size=1.0, side='BUY', level=2)
        grid.update_position_memory("ETHUSDT", order_open, "open")
        
        order_close = GridOrder(order_id='TEST_5', symbol='ETHUSDT', entry_price=3100, size=1.0, remaining_size=0, side='SELL', level=2)
        grid.update_position_memory("ETHUSDT", order_close, "full_close")
        
        memory = grid.position_memory.get("ETHUSDT")
        assert memory is not None
        assert memory['total_exits'] > 0
        
        logger.info(f"✅ Full close tracking test passed")
    
    def test_selective_close_exists(self):
        """Тест наличия метода selective_close_positions"""
        grid = GridOracleV4Ultimate(config={'progression': 'fibonacci'})
        assert hasattr(grid, 'selective_close_positions')
        assert hasattr(grid, 'calculate_close_portion')
        logger.info(f"✅ Selective close methods exist")


class TestProgressiveGridLimits:
    """Тесты для progressive grid limits"""
    
    def test_within_limits(self):
        """Тест в пределах лимитов"""
        aegis = AEGISv2(initial_capital=10000)
        
        grid_params = {
            'total_exposure': 2000,
            'num_levels': 10,
            'progressive_mult': 1.5
        }
        
        result = aegis.check_progressive_grid_limits("BTCUSDT", grid_params)
        
        assert result['allowed'] == True
        logger.info(f"✅ Within limits test passed: {result}")
    
    def test_exceeds_exposure(self):
        """Тест превышения exposure"""
        aegis = AEGISv2(initial_capital=5000)
        
        grid_params = {
            'total_exposure': 3000,
            'num_levels': 10,
            'progressive_mult': 1.5
        }
        
        result = aegis.check_progressive_grid_limits("BTCUSDT", grid_params)
        
        assert result['allowed'] == False
        assert 'Exposure' in result['reason']
        logger.info(f"✅ Exceeds exposure test passed: {result['reason']}")
    
    def test_aggressive_params(self):
        """Тест агрессивных параметров (multiplier > 2.0 и levels > 10)"""
        aegis = AEGISv2(initial_capital=10000)
        
        grid_params = {
            'total_exposure': 1000,
            'num_levels': 15,
            'progressive_mult': 2.5
        }
        
        result = aegis.check_progressive_grid_limits("BTCUSDT", grid_params)
        
        assert result['allowed'] == False
        logger.info(f"✅ Aggressive params test passed: {result['reason']}")
    


def run_all_tests():
    """Запуск всех тестов"""
    logger.info("\n" + "="*80)
    logger.info("🧪 OPUS 4.1 UNIT TESTS")
    logger.info("="*80 + "\n")
    
    logger.info("📋 Test Group 1: Progressive Order Execution")
    logger.info("-" * 80)
    prog_tests = TestProgressiveOrderExecution()
    prog_tests.test_linear_progression()
    prog_tests.test_fibonacci_progression()
    prog_tests.test_exponential_progression()
    prog_tests.test_invalid_progression_type()
    
    logger.info("\n📋 Test Group 2: Position Memory Edge Cases")
    logger.info("-" * 80)
    mem_tests = TestPositionMemory()
    mem_tests.test_position_open_tracking()
    mem_tests.test_partial_close_tracking()
    mem_tests.test_full_close_tracking()
    mem_tests.test_selective_close_exists()
    
    logger.info("\n📋 Test Group 3: Progressive Grid Limits")
    logger.info("-" * 80)
    limit_tests = TestProgressiveGridLimits()
    limit_tests.test_within_limits()
    limit_tests.test_exceeds_exposure()
    limit_tests.test_aggressive_params()
    
    logger.info("\n" + "="*80)
    logger.info("✅ ALL TESTS COMPLETED SUCCESSFULLY!")
    logger.info("="*80 + "\n")


if __name__ == "__main__":
    run_all_tests()
