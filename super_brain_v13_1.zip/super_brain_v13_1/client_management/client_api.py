"""
ClientAPI - простой REST-like API handler
Интегрируется с существующим HTTP server (порт 5000)
"""
import logging
import json
from typing import Dict, Optional
from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

logger = logging.getLogger(__name__)


class ClientAPIHandler:
    """
    Обработчик API запросов для Client Management
    
    Интегрируется с существующим SimpleHTTPRequestHandler
    """
    
    def __init__(self, client_manager):
        """
        Инициализация API handler
        
        Args:
            client_manager: Instance ClientManager
        """
        self.client_manager = client_manager
        logger.info("🌐 ClientAPIHandler initialized")
    
    def handle_request(self, path: str, method: str, data: Optional[Dict] = None) -> Dict:
        """
        Обработка API запроса
        
        Args:
            path: URL path
            method: HTTP method (GET, POST, etc.)
            data: Request body (для POST)
        
        Returns:
            Response dict
        """
        parsed_url = urlparse(path)
        path_parts = parsed_url.path.strip('/').split('/')
        
        if path_parts[0] == 'api':
            if len(path_parts) > 1:
                if path_parts[1] == 'clients':
                    return self._handle_clients_endpoint(path_parts[2:], method, data)
                elif path_parts[1] == 'stats':
                    return self.get_stats()
        
        return {'error': 'Not found', 'status': 404}
    
    def _handle_clients_endpoint(self, path_parts: list, method: str, data: Optional[Dict]) -> Dict:
        """Обработка /api/clients/* endpoints"""
        
        if method == 'GET':
            if not path_parts or path_parts[0] == '':
                return self._get_all_clients()
            
            elif path_parts[0].isdigit():
                client_id = int(path_parts[0])
                
                if len(path_parts) == 1:
                    return self._get_client(client_id)
                
                elif path_parts[1] == 'stats':
                    return self._get_client_stats(client_id)
        
        elif method == 'POST':
            if not path_parts or path_parts[0] == '':
                return self._create_client(data)
            
            elif path_parts[0].isdigit() and len(path_parts) > 1:
                client_id = int(path_parts[0])
                
                if path_parts[1] == 'connections':
                    return self._create_connection(client_id, data)
                
                elif path_parts[1] == 'snapshot':
                    return self._create_snapshot(client_id)
        
        return {'error': 'Invalid endpoint', 'status': 404}
    
    def _get_all_clients(self) -> Dict:
        """GET /api/clients"""
        try:
            summaries = self.client_manager.get_all_clients_summary()
            return {
                'status': 200,
                'data': summaries,
                'count': len(summaries)
            }
        except Exception as e:
            logger.error(f"❌ Error getting clients: {e}")
            return {'error': str(e), 'status': 500}
    
    def _get_client(self, client_id: int) -> Dict:
        """GET /api/clients/{id}"""
        try:
            summary = self.client_manager.get_client_summary(client_id)
            if summary:
                return {'status': 200, 'data': summary}
            else:
                return {'error': 'Client not found', 'status': 404}
        except Exception as e:
            logger.error(f"❌ Error getting client {client_id}: {e}")
            return {'error': str(e), 'status': 500}
    
    def _get_client_stats(self, client_id: int) -> Dict:
        """GET /api/clients/{id}/stats"""
        try:
            summary = self.client_manager.get_client_summary(client_id)
            if summary:
                return {'status': 200, 'data': summary}
            else:
                return {'error': 'Client not found', 'status': 404}
        except Exception as e:
            logger.error(f"❌ Error getting client stats: {e}")
            return {'error': str(e), 'status': 500}
    
    def _create_client(self, data: Optional[Dict]) -> Dict:
        """POST /api/clients"""
        if not data:
            return {'error': 'Missing request body', 'status': 400}
        
        try:
            client_name = data.get('client_name')
            email = data.get('email')
            
            if not client_name or not email:
                return {'error': 'Missing required fields: client_name, email', 'status': 400}
            
            client = self.client_manager.add_client(client_name, email)
            
            if client:
                return {
                    'status': 201,
                    'data': client.to_dict(),
                    'message': f'Client {client_name} created successfully'
                }
            else:
                return {'error': 'Failed to create client', 'status': 500}
        
        except Exception as e:
            logger.error(f"❌ Error creating client: {e}")
            return {'error': str(e), 'status': 500}
    
    def _create_connection(self, client_id: int, data: Optional[Dict]) -> Dict:
        """POST /api/clients/{id}/connections"""
        if not data:
            return {'error': 'Missing request body', 'status': 400}
        
        try:
            exchange_name = data.get('exchange_name')
            api_key = data.get('api_key')
            api_secret = data.get('api_secret')
            
            if not all([exchange_name, api_key, api_secret]):
                return {
                    'error': 'Missing required fields: exchange_name, api_key, api_secret',
                    'status': 400
                }
            
            connection = self.client_manager.add_connection(
                client_id,
                exchange_name,
                api_key,
                api_secret
            )
            
            if connection:
                return {
                    'status': 201,
                    'data': {
                        'connection_id': connection.connection_id,
                        'exchange_name': connection.exchange_name,
                        'created_at': connection.created_at.isoformat()
                    },
                    'message': f'Connection to {exchange_name} created successfully'
                }
            else:
                return {'error': 'Failed to create connection', 'status': 500}
        
        except Exception as e:
            logger.error(f"❌ Error creating connection: {e}")
            return {'error': str(e), 'status': 500}
    
    def _create_snapshot(self, client_id: int) -> Dict:
        """POST /api/clients/{id}/snapshot"""
        try:
            connections = [
                conn for conn in self.client_manager.connections.values()
                if conn.client_id == client_id and conn.is_active
            ]
            
            if not connections:
                return {'error': 'No active connections for this client', 'status': 404}
            
            connection = connections[0]
            snapshot = self.client_manager.create_snapshot(connection.connection_id)
            
            if snapshot:
                return {
                    'status': 200,
                    'data': {
                        'snapshot_id': snapshot.snapshot_id,
                        'current_total_usd': snapshot.current_total_usd,
                        'session_pnl_usd': snapshot.session_realized_trading_pnl_usd,
                        'unrealized_pnl': snapshot.unrealized_pnl,
                        'timestamp': snapshot.timestamp.isoformat()
                    },
                    'message': 'Snapshot created successfully'
                }
            else:
                return {'error': 'Failed to create snapshot', 'status': 500}
        
        except Exception as e:
            logger.error(f"❌ Error creating snapshot: {e}")
            return {'error': str(e), 'status': 500}
    
    def get_stats(self) -> Dict:
        """GET /api/stats"""
        try:
            stats = self.client_manager.get_stats()
            return {'status': 200, 'data': stats}
        except Exception as e:
            logger.error(f"❌ Error getting stats: {e}")
            return {'error': str(e), 'status': 500}
