"""
ClientManager - главный оркестратор Client Management Platform
Модуль №23 системы СУПЕР МОЗГ GENESIS v13.1
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime

from client_management.models import Client, ClientConnection, ClientSnapshot, TradeHistory
from client_management.encryption_service import EncryptionService
from client_management.client_aggregator import ClientAggregator
from client_management.client_pnl_engine import ClientPnLEngine
from client_management.client_repository import ClientRepository

logger = logging.getLogger(__name__)


class ClientManager:
    """
    Центральный менеджер клиентских активов
    
    Интегрируется с:
    - PostgreSQL через ClientRepository
    - unified_scheduler для автоматических снапшотов
    - Существующий web server для REST API
    """
    
    def __init__(self, config: Dict, db_connector=None):
        """
        Инициализация Client Manager
        
        Args:
            config: Конфигурация из config.json
            db_connector: PostgreSQL connector (если None - in-memory mode)
        """
        self.config = config
        
        encryption_key = config.get('client_management', {}).get('encryption_key')
        if not encryption_key or encryption_key == "GENERATE_NEW_KEY_FOR_PRODUCTION":
            logger.error("❌ CRITICAL: No encryption key configured!")
            logger.error("   Generate key: python -c \"from client_management.encryption_service import EncryptionService; print(EncryptionService.generate_key())\"")
            logger.error("   Add to config.json: client_management.encryption_key")
            raise ValueError("Encryption key REQUIRED for Client Management - cannot proceed with placeholder")
        
        self.encryption_service = EncryptionService(encryption_key)
        self.aggregator = ClientAggregator(self.encryption_service)
        self.pnl_engine = ClientPnLEngine()
        
        self.use_persistence = db_connector is not None
        if self.use_persistence:
            self.repository = ClientRepository(db_connector)
            try:
                self.repository.ensure_tables()
                logger.info("💾 PostgreSQL persistence ENABLED")
            except Exception as e:
                logger.error(f"❌ Failed to initialize persistence: {e}")
                self.use_persistence = False
                self.repository = None
        else:
            self.repository = None
            logger.info("⚠️ In-memory mode (no persistence)")
        
        self.clients_cache: Dict[int, Client] = {}
        self.connections_cache: Dict[int, ClientConnection] = {}
        self.latest_snapshots: Dict[int, ClientSnapshot] = {}
        
        self.enabled = config.get('client_management', {}).get('enabled', False)
        
        if self.enabled:
            logger.info("✅ ClientManager initialized (ENABLED)")
            self._load_from_db()
        else:
            logger.info("ℹ️ ClientManager initialized (DISABLED - enable in config)")
    
    def _load_from_db(self):
        """Загрузка клиентов и подключений из БД в кеш"""
        if not self.use_persistence:
            return
        
        try:
            clients = self.repository.get_all_clients()
            for client in clients:
                self.clients_cache[client.client_id] = client
            
            for client_id in self.clients_cache.keys():
                connections = self.repository.get_connections_by_client(client_id)
                for conn in connections:
                    self.connections_cache[conn.connection_id] = conn
                    
                    if conn.is_active:
                        self.aggregator.initialize_connection(
                            conn.connection_id,
                            conn.exchange_name,
                            conn.api_key_encrypted,
                            conn.api_secret_encrypted
                        )
            
            logger.info(f"📥 Loaded {len(self.clients_cache)} clients, {len(self.connections_cache)} connections from DB")
        except Exception as e:
            logger.error(f"❌ Failed to load from DB: {e}")
    
    def add_client(
        self,
        client_name: str,
        email: str
    ) -> Optional[Client]:
        """
        Добавление нового клиента
        
        Args:
            client_name: Имя клиента
            email: Email клиента
        
        Returns:
            Client объект или None при ошибке
        """
        if not self.enabled:
            logger.warning("⚠️ ClientManager disabled")
            return None
        
        try:
            client = Client(
                client_id=0,
                client_name=client_name,
                email=email,
                is_active=True,
                created_at=datetime.now()
            )
            
            if self.use_persistence:
                client_id = self.repository.save_client(client)
                if client_id:
                    client.client_id = client_id
                    self.clients_cache[client_id] = client
                    logger.info(f"✅ Added client: {client_name} (ID: {client_id}) [DB]")
                    return client
            else:
                client_id = len(self.clients_cache) + 1
                client.client_id = client_id
                self.clients_cache[client_id] = client
                logger.info(f"✅ Added client: {client_name} (ID: {client_id}) [MEMORY]")
                return client
            
        except Exception as e:
            logger.error(f"❌ Failed to add client: {e}")
            return None
    
    def add_connection(
        self,
        client_id: int,
        exchange_name: str,
        api_key: str,
        api_secret: str
    ) -> Optional[ClientConnection]:
        """
        Добавление подключения клиента к бирже
        
        Args:
            client_id: ID клиента
            exchange_name: Название биржи
            api_key: API ключ
            api_secret: API secret
        
        Returns:
            ClientConnection объект или None при ошибке
        """
        if not self.enabled:
            logger.warning("⚠️ ClientManager disabled")
            return None
        
        if client_id not in self.clients_cache:
            logger.error(f"❌ Client {client_id} not found")
            return None
        
        try:
            api_key_encrypted = self.encryption_service.encrypt(api_key)
            api_secret_encrypted = self.encryption_service.encrypt(api_secret)
            
            connection = ClientConnection(
                connection_id=0,
                client_id=client_id,
                exchange_name=exchange_name,
                api_key_encrypted=api_key_encrypted,
                api_secret_encrypted=api_secret_encrypted,
                is_active=True,
                created_at=datetime.now()
            )
            
            if self.use_persistence:
                connection_id = self.repository.save_connection(connection)
                if connection_id:
                    connection.connection_id = connection_id
            else:
                connection_id = len(self.connections_cache) + 1
                connection.connection_id = connection_id
            
            self.connections_cache[connection_id] = connection
            
            exchange = self.aggregator.initialize_connection(
                connection_id,
                exchange_name,
                api_key_encrypted,
                api_secret_encrypted
            )
            
            if exchange:
                logger.info(f"✅ Added connection for client {client_id} to {exchange_name} (ID: {connection_id})")
                return connection
            else:
                logger.error(f"❌ Failed to initialize exchange connection")
                return None
            
        except Exception as e:
            logger.error(f"❌ Failed to add connection: {e}")
            return None
    
    def create_snapshot(self, connection_id: int) -> Optional[ClientSnapshot]:
        """
        Создание снапшота состояния клиентского счета
        
        Args:
            connection_id: ID подключения
        
        Returns:
            ClientSnapshot объект или None при ошибке
        """
        if not self.enabled:
            return None
        
        if connection_id not in self.connections_cache:
            logger.error(f"❌ Connection {connection_id} not found")
            return None
        
        try:
            balance = self.aggregator.get_balance(connection_id)
            if not balance:
                logger.error(f"❌ Failed to fetch balance for connection {connection_id}")
                return None
            
            positions = self.aggregator.get_positions(connection_id)
            
            prices = self._extract_prices(positions)
            
            metrics = self.pnl_engine.calculate_metrics(
                connection_id,
                balance['total'],
                positions,
                prices
            )
            
            snapshot_id = len(self.latest_snapshots) + 1
            
            snapshot = ClientSnapshot(
                snapshot_id=0,
                connection_id=connection_id,
                timestamp=datetime.now(),
                baseline_equity_usd=metrics.baseline_equity_usd,
                session_realized_trading_pnl_usd=metrics.session_realized_trading_pnl_usd,
                current_total_usd=metrics.current_total_usd,
                unrealized_pnl=metrics.unrealized_pnl,
                full_balance_payload={
                    'balance': balance,
                    'positions': positions
                }
            )
            
            if self.use_persistence:
                snapshot_id = self.repository.save_snapshot(snapshot)
                if snapshot_id:
                    snapshot.snapshot_id = snapshot_id
                self.repository.update_connection_sync(connection_id, None)
            
            self.latest_snapshots[connection_id] = snapshot
            
            connection = self.connections_cache[connection_id]
            connection.last_sync_at = datetime.now()
            connection.last_error = None
            
            logger.info(f"📊 Created snapshot for connection {connection_id}: "
                       f"${metrics.current_total_usd:.2f} USD")
            
            return snapshot
            
        except Exception as e:
            logger.error(f"❌ Failed to create snapshot for connection {connection_id}: {e}")
            
            if connection_id in self.connections_cache:
                self.connections_cache[connection_id].last_error = str(e)
                if self.use_persistence:
                    self.repository.update_connection_sync(connection_id, str(e))
            
            return None
    
    def create_all_snapshots(self):
        """
        Создание снапшотов для всех активных подключений
        Вызывается периодически через unified_scheduler
        """
        if not self.enabled:
            return
        
        logger.info("📊 Creating snapshots for all active connections")
        
        active_connections = [
            conn_id for conn_id, conn in self.connections_cache.items()
            if conn.is_active
        ]
        
        for connection_id in active_connections:
            self.create_snapshot(connection_id)
        
        logger.info(f"📊 Snapshots created for {len(active_connections)} connections")
    
    def get_client_summary(self, client_id: int) -> Optional[Dict]:
        """
        Получение сводной информации о клиенте
        
        Args:
            client_id: ID клиента
        
        Returns:
            Dict со сводной информацией
        """
        if client_id not in self.clients_cache:
            return None
        
        client = self.clients_cache[client_id]
        
        client_connections = [
            conn for conn in self.connections_cache.values()
            if conn.client_id == client_id and conn.is_active
        ]
        
        if not client_connections:
            return {
                'client_id': client.client_id,
                'client_name': client.client_name,
                'email': client.email,
                'status': 'No active connections',
                'total_usd': 0.0,
                'session_pnl_usd': 0.0
            }
        
        connection = client_connections[0]
        snapshot = self.latest_snapshots.get(connection.connection_id)
        
        if not snapshot:
            return {
                'client_id': client.client_id,
                'client_name': client.client_name,
                'email': client.email,
                'exchange': connection.exchange_name,
                'status': 'No snapshot data',
                'total_usd': 0.0,
                'session_pnl_usd': 0.0
            }
        
        return {
            'client_id': client.client_id,
            'client_name': client.client_name,
            'email': client.email,
            'exchange': connection.exchange_name,
            'status': 'Connected' if not connection.last_error else 'Error',
            'total_usd': snapshot.current_total_usd,
            'session_pnl_usd': snapshot.session_realized_trading_pnl_usd,
            'unrealized_pnl_usd': snapshot.unrealized_pnl,
            'last_sync': connection.last_sync_at.isoformat() if connection.last_sync_at else None
        }
    
    def get_all_clients_summary(self) -> List[Dict]:
        """
        Получение сводной информации по всем клиентам
        
        Returns:
            Список сводок
        """
        return [
            self.get_client_summary(client_id)
            for client_id in self.clients_cache.keys()
        ]
    
    def _extract_prices(self, positions: List[Dict]) -> Dict[str, float]:
        """Извлечение цен из позиций"""
        prices = {}
        for position in positions:
            symbol = position.get('symbol')
            mark_price = position.get('mark_price')
            if symbol and mark_price:
                prices[symbol] = mark_price
        return prices
    
    def get_stats(self) -> Dict:
        """Получение общей статистики"""
        return {
            'enabled': self.enabled,
            'persistence': 'PostgreSQL' if self.use_persistence else 'In-Memory',
            'total_clients': len(self.clients_cache),
            'total_connections': len(self.connections_cache),
            'active_connections': sum(1 for conn in self.connections_cache.values() if conn.is_active),
            'snapshots_created': len(self.latest_snapshots)
        }
