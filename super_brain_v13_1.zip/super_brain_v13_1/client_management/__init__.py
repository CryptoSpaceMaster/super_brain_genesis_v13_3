"""
Client Management Module - Централизованная платформа управления клиентскими активами
Модуль №23 системы СУПЕР МОЗГ GENESIS v13.1

Функциональность:
- Управление клиентами и их подключениями к биржам
- Автоматические снапшоты балансов (интеграция с unified_scheduler)
- Расчет P&L по системе AEGIS v2.0 (3-контурный учет)
- Синхронизация с биржами через CCXT
- REST API для визуализации
"""

__version__ = "1.0.0"
__all__ = [
    "Client",
    "ClientConnection",
    "ClientSnapshot",
    "TradeHistory",
    "ClientAggregator",
    "ClientPnLEngine",
    "EncryptionService",
    "ClientManager"
]
