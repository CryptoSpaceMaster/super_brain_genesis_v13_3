# Client Management Platform - Модуль №23

**Централизованная Платформа Управления Клиентскими Активами**  
Интегрирована в систему СУПЕР МОЗГ GENESIS v13.1

---

## 📋 Обзор

Client Management Platform - это модуль для управления клиентскими торговыми счетами на криптовалютных биржах с автоматическим расчетом P&L по системе AEGIS (3-контурный учет).

### Ключевые Особенности

✅ **Многобиржевая поддержка** - Binance, Bybit, OKX, Bitget через CCXT  
✅ **AEGIS P&L Tracking** - 3-контурный учет прибыльности  
✅ **Безопасность** - AES-256 шифрование API ключей  
✅ **Автоматизация** - Периодические снапшоты балансов (15 мин)  
✅ **REST API** - Простой API для визуализации  
✅ **Интеграция** - Совместимость с существующей архитектурой

---

## 🏗️ Архитектура

```
client_management/
├── __init__.py                  # Модуль exports
├── models.py                    # Data models (Client, Connection, Snapshot, Trade)
├── encryption_service.py        # AES-256 API key encryption
├── client_aggregator.py         # CCXT exchange integration
├── client_pnl_engine.py         # AEGIS-compatible P&L calculation
├── client_manager.py            # Main orchestrator
├── client_api.py                # REST API handler
└── README.md                    # This file
```

### Компоненты

#### 1. **EncryptionService**
- Шифрование/дешифрование API ключей
- Fernet (AES-256) encryption
- Base64 encoding для хранения

#### 2. **ClientAggregator**
- Синхронизация с биржами через CCXT
- Получение балансов, позиций, сделок
- Rate limiting (встроенный в CCXT)

#### 3. **ClientPnLEngine**
- Расчет P&L по системе AEGIS
- 3 контура: Baseline Equity, Session PnL, Current Total
- Совместим с существующим AEGIS v2.0

#### 4. **ClientManager**
- Главный оркестратор
- Управление клиентами и подключениями
- Создание снапшотов
- Интеграция с unified_scheduler

#### 5. **ClientAPIHandler**
- REST API endpoints
- GET/POST операции
- JSON responses

---

## 🚀 Быстрый Старт

### 1. Включение модуля

В `config/config.json` установите:

```json
{
  "client_management": {
    "enabled": true,
    "encryption_key": "YOUR_GENERATED_KEY_HERE",
    "snapshot_interval_minutes": 15,
    "auto_sync_trades": true,
    "daily_reset_hour": 0
  }
}
```

### 2. Генерация ключа шифрования

```python
from client_management.encryption_service import EncryptionService
print(EncryptionService.generate_key())
```

### 3. Инициализация в monolith.py

```python
from client_management.client_manager import ClientManager

# Инициализация
client_manager = ClientManager(config)

# Добавление клиента
client = client_manager.add_client(
    client_name="John Doe",
    email="john@example.com"
)

# Добавление подключения к бирже
connection = client_manager.add_connection(
    client_id=client.client_id,
    exchange_name="binance",
    api_key="YOUR_API_KEY",
    api_secret="YOUR_API_SECRET"
)

# Создание снапшота
snapshot = client_manager.create_snapshot(connection.connection_id)
```

---

## 📊 AEGIS v2.0 Integration

### 3-Контурная Система Учета

1. **Baseline Equity** (Контур №1)
   - Начальный капитал клиента
   - Устанавливается при старте сессии

2. **Session Realized Trading P&L** (Контур №2)
   - Реализованная прибыль от закрытых сделок
   - Накапливается в течение сессии

3. **Current Total** (Контур №3)
   - Текущая общая стоимость портфеля в USD
   - Включает нереализованную прибыль

### Пример расчета

```python
metrics = pnl_engine.calculate_metrics(
    connection_id=1,
    current_balance={'BTC': 0.5, 'USDT': 10000},
    positions=[...],
    prices={'BTC/USDT': 50000}
)

print(f"Baseline: ${metrics.baseline_equity_usd}")
print(f"Session PnL: ${metrics.session_realized_trading_pnl_usd}")
print(f"Current Total: ${metrics.current_total_usd}")
print(f"Unrealized: ${metrics.unrealized_pnl}")
```

---

## 🔒 Безопасность

### Шифрование API Ключей

- **Алгоритм**: AES-256 (Fernet)
- **Ключ**: 44-символьный Base64-encoded ключ
- **Хранение**: Зашифрованные ключи в памяти/БД
- **Безопасность**: Расшифровка только при использовании

### Генерация Ключа

```python
from client_management.encryption_service import EncryptionService

key = EncryptionService.generate_key()
print(f"ENCRYPTION_KEY={key}")
```

**ВАЖНО**: Храните encryption_key в `.env` или `config.json` ТОЛЬКО вне репозитория!

---

## 🌐 REST API

### Endpoints

#### GET /api/clients
Получение списка всех клиентов со сводной информацией

**Response:**
```json
{
  "status": 200,
  "data": [
    {
      "client_id": 1,
      "client_name": "John Doe",
      "email": "john@example.com",
      "exchange": "binance",
      "status": "Connected",
      "total_usd": 50000.00,
      "session_pnl_usd": 2500.00,
      "unrealized_pnl_usd": 150.00
    }
  ],
  "count": 1
}
```

#### GET /api/clients/{id}
Детальная информация о клиенте

#### POST /api/clients
Создание нового клиента

**Request Body:**
```json
{
  "client_name": "John Doe",
  "email": "john@example.com"
}
```

#### POST /api/clients/{id}/connections
Добавление подключения к бирже

**Request Body:**
```json
{
  "exchange_name": "binance",
  "api_key": "YOUR_API_KEY",
  "api_secret": "YOUR_API_SECRET"
}
```

#### POST /api/clients/{id}/snapshot
Создание снапшота (принудительное обновление)

---

## 📅 Scheduler Integration

### Автоматические Задачи

```python
# В unified_scheduler добавить:

# Снапшоты каждые 15 минут
scheduler.add_job(
    client_manager.create_all_snapshots,
    trigger=IntervalTrigger(minutes=15)
)

# Сброс дневных сессий (00:00 UTC)
scheduler.add_job(
    reset_daily_sessions,
    trigger=CronTrigger(hour=0, minute=0)
)
```

---

## 💾 Хранение Данных

### Текущая Реализация
- In-memory storage (Dict-based)
- Подходит для прототипирования

### PostgreSQL Integration (будущее)
- Таблицы: `clients`, `client_connections`, `client_snapshots`, `client_trades`
- TimescaleDB для снапшотов
- Full ACID compliance

---

## 🔧 Конфигурация

### Параметры в config.json

```json
{
  "client_management": {
    "enabled": false,                          // Включить/выключить модуль
    "encryption_key": "GENERATE_NEW_KEY",      // Ключ шифрования
    "snapshot_interval_minutes": 15,           // Интервал снапшотов
    "auto_sync_trades": true,                  // Автосинхронизация сделок
    "daily_reset_hour": 0                      // Час сброса сессии (UTC)
  }
}
```

---

## ⚠️ Важные Замечания

1. **Не дублирует AEGIS v2.0** системы - отдельный учет для клиентов
2. **Минималистичная архитектура** - без FastAPI/SQLAlchemy ORM
3. **Интегрируется с существующими провайдерами** - PostgreSQL, MarketDataCollector
4. **Безопасность превыше всего** - шифрование API ключей обязательно
5. **Отключен по умолчанию** - включается через `config.json`

---

## 📈 Статистика

```python
stats = client_manager.get_stats()
print(stats)

# Output:
# {
#   'enabled': True,
#   'total_clients': 5,
#   'total_connections': 7,
#   'active_connections': 6,
#   'snapshots_created': 42
# }
```

---

## 🛠️ Разработка

### Добавление Новой Биржи

```python
# В client_aggregator.py добавить конфигурацию:
self.exchange_configs = {
    'binance': {'rateLimit': 1200, 'enableRateLimit': True},
    'new_exchange': {'rateLimit': 1000, 'enableRateLimit': True},
}
```

### Расширение API

```python
# В client_api.py добавить новый endpoint:
def _handle_custom_endpoint(self, path_parts, method, data):
    # Your logic here
    pass
```

---

## 📝 TODO

- [ ] PostgreSQL persistence
- [ ] Web dashboard (dark theme)
- [ ] Real-time WebSocket updates
- [ ] Trade history sync
- [ ] Multi-currency support
- [ ] Performance metrics
- [ ] Advanced analytics

---

## 🎯 Интеграция с СУПЕР МОЗГ

Client Management Platform - это **Модуль №23** системы СУПЕР МОЗГ GENESIS v13.1.

Работает **параллельно** с основной торговой системой:
- **Система торгует** своим капиталом → AEGIS v2.0 в `risk/aegis_v2.py`
- **Клиенты торгуют** своим капиталом → ClientPnLEngine в `client_management/`

**Нет конфликтов, нет дублирования!**

---

## 📄 Лицензия

Proprietary - All Rights Reserved  
Часть системы СУПЕР МОЗГ GENESIS v13.1

---

**Created**: 2025-10-03  
**Version**: 1.0.0  
**Status**: ✅ READY FOR INTEGRATION
