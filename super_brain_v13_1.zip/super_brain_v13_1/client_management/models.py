"""
SQLAlchemy модели для Client Management
Таблицы: clients, client_connections, client_snapshots, client_trades
"""
import logging
from datetime import datetime
from typing import Dict, Optional, List
import json

logger = logging.getLogger(__name__)


class Client:
    """
    Модель клиента (упрощенная, без SQLAlchemy ORM)
    Хранение в PostgreSQL через raw SQL или dict-based approach
    """
    
    def __init__(
        self,
        client_id: int,
        client_name: str,
        email: str,
        is_active: bool = True,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None
    ):
        self.client_id = client_id
        self.client_name = client_name
        self.email = email
        self.is_active = is_active
        self.created_at = created_at or datetime.now()
        self.updated_at = updated_at
    
    def to_dict(self) -> Dict:
        """Конвертация в словарь"""
        return {
            'client_id': self.client_id,
            'client_name': self.client_name,
            'email': self.email,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Client':
        """Создание из словаря"""
        return cls(
            client_id=data['client_id'],
            client_name=data['client_name'],
            email=data['email'],
            is_active=data.get('is_active', True),
            created_at=datetime.fromisoformat(data['created_at']) if data.get('created_at') else None,
            updated_at=datetime.fromisoformat(data['updated_at']) if data.get('updated_at') else None
        )


class ClientConnection:
    """
    Модель подключения клиента к бирже
    """
    
    def __init__(
        self,
        connection_id: int,
        client_id: int,
        exchange_name: str,
        api_key_encrypted: str,
        api_secret_encrypted: str,
        is_active: bool = True,
        created_at: Optional[datetime] = None,
        last_sync_at: Optional[datetime] = None,
        last_error: Optional[str] = None
    ):
        self.connection_id = connection_id
        self.client_id = client_id
        self.exchange_name = exchange_name.lower()
        self.api_key_encrypted = api_key_encrypted
        self.api_secret_encrypted = api_secret_encrypted
        self.is_active = is_active
        self.created_at = created_at or datetime.now()
        self.last_sync_at = last_sync_at
        self.last_error = last_error
    
    def to_dict(self) -> Dict:
        """Конвертация в словарь"""
        return {
            'connection_id': self.connection_id,
            'client_id': self.client_id,
            'exchange_name': self.exchange_name,
            'api_key_encrypted': self.api_key_encrypted,
            'api_secret_encrypted': self.api_secret_encrypted,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_sync_at': self.last_sync_at.isoformat() if self.last_sync_at else None,
            'last_error': self.last_error
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ClientConnection':
        """Создание из словаря"""
        return cls(
            connection_id=data['connection_id'],
            client_id=data['client_id'],
            exchange_name=data['exchange_name'],
            api_key_encrypted=data['api_key_encrypted'],
            api_secret_encrypted=data['api_secret_encrypted'],
            is_active=data.get('is_active', True),
            created_at=datetime.fromisoformat(data['created_at']) if data.get('created_at') else None,
            last_sync_at=datetime.fromisoformat(data['last_sync_at']) if data.get('last_sync_at') else None,
            last_error=data.get('last_error')
        )


class ClientSnapshot:
    """
    Модель снапшота состояния клиентского счета
    AEGIS v2.0: 3-контурный учет
    """
    
    def __init__(
        self,
        snapshot_id: int,
        connection_id: int,
        timestamp: datetime,
        baseline_equity_usd: float,
        session_realized_trading_pnl_usd: float,
        current_total_usd: float,
        unrealized_pnl: float = 0.0,
        margin_balance: Optional[float] = None,
        available_balance: Optional[float] = None,
        full_balance_payload: Optional[Dict] = None
    ):
        self.snapshot_id = snapshot_id
        self.connection_id = connection_id
        self.timestamp = timestamp
        
        self.baseline_equity_usd = baseline_equity_usd
        self.session_realized_trading_pnl_usd = session_realized_trading_pnl_usd
        self.current_total_usd = current_total_usd
        
        self.unrealized_pnl = unrealized_pnl
        self.margin_balance = margin_balance
        self.available_balance = available_balance
        self.full_balance_payload = full_balance_payload or {}
    
    def to_dict(self) -> Dict:
        """Конвертация в словарь"""
        return {
            'snapshot_id': self.snapshot_id,
            'connection_id': self.connection_id,
            'timestamp': self.timestamp.isoformat(),
            'baseline_equity_usd': self.baseline_equity_usd,
            'session_realized_trading_pnl_usd': self.session_realized_trading_pnl_usd,
            'current_total_usd': self.current_total_usd,
            'unrealized_pnl': self.unrealized_pnl,
            'margin_balance': self.margin_balance,
            'available_balance': self.available_balance,
            'full_balance_payload': json.dumps(self.full_balance_payload) if self.full_balance_payload else None
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ClientSnapshot':
        """Создание из словаря"""
        return cls(
            snapshot_id=data['snapshot_id'],
            connection_id=data['connection_id'],
            timestamp=datetime.fromisoformat(data['timestamp']),
            baseline_equity_usd=float(data['baseline_equity_usd']),
            session_realized_trading_pnl_usd=float(data['session_realized_trading_pnl_usd']),
            current_total_usd=float(data['current_total_usd']),
            unrealized_pnl=float(data.get('unrealized_pnl', 0)),
            margin_balance=float(data['margin_balance']) if data.get('margin_balance') else None,
            available_balance=float(data['available_balance']) if data.get('available_balance') else None,
            full_balance_payload=json.loads(data['full_balance_payload']) if data.get('full_balance_payload') else None
        )


class TradeHistory:
    """
    Модель истории сделок клиента
    """
    
    def __init__(
        self,
        trade_id: int,
        connection_id: int,
        exchange_trade_id: str,
        symbol: str,
        side: str,
        amount: float,
        price: float,
        fee: float = 0.0,
        fee_currency: Optional[str] = None,
        timestamp: Optional[datetime] = None
    ):
        self.trade_id = trade_id
        self.connection_id = connection_id
        self.exchange_trade_id = exchange_trade_id
        self.symbol = symbol
        self.side = side.lower()
        self.amount = amount
        self.price = price
        self.fee = fee
        self.fee_currency = fee_currency
        self.timestamp = timestamp or datetime.now()
    
    def to_dict(self) -> Dict:
        """Конвертация в словарь"""
        return {
            'trade_id': self.trade_id,
            'connection_id': self.connection_id,
            'exchange_trade_id': self.exchange_trade_id,
            'symbol': self.symbol,
            'side': self.side,
            'amount': self.amount,
            'price': self.price,
            'fee': self.fee,
            'fee_currency': self.fee_currency,
            'timestamp': self.timestamp.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'TradeHistory':
        """Создание из словаря"""
        return cls(
            trade_id=data['trade_id'],
            connection_id=data['connection_id'],
            exchange_trade_id=data['exchange_trade_id'],
            symbol=data['symbol'],
            side=data['side'],
            amount=float(data['amount']),
            price=float(data['price']),
            fee=float(data.get('fee', 0)),
            fee_currency=data.get('fee_currency'),
            timestamp=datetime.fromisoformat(data['timestamp']) if data.get('timestamp') else None
        )
