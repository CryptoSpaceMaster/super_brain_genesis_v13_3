"""
ClientPnLEngine - расчет P&L клиентов
ИНТЕГРАЦИЯ С СУЩЕСТВУЮЩИМ AEGIS v2.0 из risk/aegis_v2.py
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ClientAEGISMetrics:
    """Метрики системы AEGIS для клиента"""
    connection_id: int
    baseline_equity_usd: float
    session_realized_trading_pnl_usd: float
    current_total_usd: float
    unrealized_pnl: float
    timestamp: datetime


class ClientPnLEngine:
    """
    Движок расчета P&L для клиентов
    
    КРИТИЧЕСКИ ВАЖНО: Не дублирует AEGIS v2.0!
    Использует упрощенную логику для клиентских счетов,
    а собственный трейдинг системы использует risk/aegis_v2.py
    """
    
    def __init__(self):
        self.session_start_time: Dict[int, datetime] = {}
        self.baseline_equity: Dict[int, float] = {}
        self.session_pnl: Dict[int, float] = {}
        
        logger.info("💰 ClientPnLEngine initialized (AEGIS-compatible)")
    
    def start_new_session(self, connection_id: int, initial_equity_usd: float):
        """
        Начало новой торговой сессии для клиента
        
        Args:
            connection_id: ID подключения
            initial_equity_usd: Начальный капитал в USD
        """
        self.session_start_time[connection_id] = datetime.utcnow()
        self.baseline_equity[connection_id] = initial_equity_usd
        self.session_pnl[connection_id] = 0.0
        
        logger.info(f"🆕 Started AEGIS session for connection {connection_id}, "
                   f"baseline: ${initial_equity_usd:.2f}")
    
    def calculate_metrics(
        self,
        connection_id: int,
        current_balance: Dict[str, float],
        positions: List[Dict],
        prices: Dict[str, float]
    ) -> ClientAEGISMetrics:
        """
        Расчет всех метрик AEGIS для клиента
        
        Args:
            connection_id: ID подключения
            current_balance: Текущий баланс {"BTC": 0.5, "USDT": 10000}
            positions: Список открытых позиций
            prices: Текущие цены {"BTC/USDT": 50000}
        
        Returns:
            ClientAEGISMetrics с 3-контурным учетом
        """
        current_total_usd = self._calculate_total_equity(current_balance, prices)
        
        unrealized_pnl = self._calculate_unrealized_pnl(positions)
        
        if connection_id not in self.baseline_equity:
            self.start_new_session(connection_id, current_total_usd)
        
        baseline = self.baseline_equity[connection_id]
        
        session_pnl = self.session_pnl.get(connection_id, 0.0)
        
        return ClientAEGISMetrics(
            connection_id=connection_id,
            baseline_equity_usd=baseline,
            session_realized_trading_pnl_usd=session_pnl,
            current_total_usd=current_total_usd,
            unrealized_pnl=unrealized_pnl,
            timestamp=datetime.utcnow()
        )
    
    def record_closed_trade(
        self,
        connection_id: int,
        realized_pnl_usd: float
    ):
        """
        Запись реализованной прибыли от закрытой сделки
        
        Args:
            connection_id: ID подключения
            realized_pnl_usd: Реализованная прибыль в USD
        """
        if connection_id not in self.session_pnl:
            self.session_pnl[connection_id] = 0.0
        
        self.session_pnl[connection_id] += realized_pnl_usd
        
        logger.info(f"📈 Recorded closed trade PnL for connection {connection_id}: "
                   f"${realized_pnl_usd:.2f}, total session PnL: ${self.session_pnl[connection_id]:.2f}")
    
    def _calculate_total_equity(
        self,
        balance: Dict[str, float],
        prices: Dict[str, float]
    ) -> float:
        """
        Расчет общей стоимости в USD
        
        AEGIS Контур №3: Текущая общая стоимость
        """
        total = 0.0
        
        for asset, amount in balance.items():
            if asset in ['USDT', 'USD', 'USDC', 'BUSD']:
                total += amount
            else:
                symbol = f"{asset}/USDT"
                if symbol in prices:
                    price = prices[symbol]
                    total += amount * price
                else:
                    logger.warning(f"⚠️ Price not found for {symbol}, skipping in equity calculation")
        
        return total
    
    def _calculate_unrealized_pnl(self, positions: List[Dict]) -> float:
        """
        Расчет нереализованной прибыли
        
        Часть AEGIS учета
        """
        total_unrealized = 0.0
        
        for position in positions:
            unrealized = position.get('unrealized_pnl', 0)
            total_unrealized += unrealized
        
        return total_unrealized
    
    def reset_session(self, connection_id: int):
        """
        Сброс сессии (например, в начале нового дня)
        
        Args:
            connection_id: ID подключения
        """
        if connection_id in self.baseline_equity:
            logger.info(f"🔄 Resetting AEGIS session for connection {connection_id}")
            self.session_pnl[connection_id] = 0.0
            self.session_start_time[connection_id] = datetime.utcnow()
    
    def get_session_stats(self, connection_id: int) -> Optional[Dict]:
        """
        Получение статистики сессии
        
        Args:
            connection_id: ID подключения
        
        Returns:
            Статистика сессии или None
        """
        if connection_id not in self.baseline_equity:
            return None
        
        return {
            'connection_id': connection_id,
            'baseline_equity_usd': self.baseline_equity[connection_id],
            'session_pnl_usd': self.session_pnl.get(connection_id, 0.0),
            'session_start_time': self.session_start_time.get(connection_id).isoformat() if connection_id in self.session_start_time else None
        }
