"""
ClientRepository - PostgreSQL persistence layer для Client Management
Интегрируется с существующим PostgreSQLDataProvider
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime
import json

from client_management.models import Client, ClientConnection, ClientSnapshot, TradeHistory

logger = logging.getLogger(__name__)


class ClientRepository:
    """
    Репозиторий для работы с клиентскими данными в PostgreSQL
    Переиспользует существующий UniversalDBConnector
    """
    
    def __init__(self, db_connector):
        """
        Инициализация репозитория
        
        Args:
            db_connector: Instance UniversalDBConnector
        """
        self.db = db_connector
        logger.info("💾 ClientRepository initialized with PostgreSQL")
    
    def ensure_tables(self):
        """Создание таблиц если их нет (миграция)"""
        try:
            self._create_clients_table()
            self._create_connections_table()
            self._create_snapshots_table()
            self._create_trades_table()
            logger.info("✅ All Client Management tables ensured")
        except Exception as e:
            logger.error(f"❌ Failed to ensure tables: {e}")
            raise
    
    def _create_clients_table(self):
        """Таблица clients"""
        sql = """
        CREATE TABLE IF NOT EXISTS clients (
            client_id SERIAL PRIMARY KEY,
            client_name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """
        self.db.execute_query(sql)
    
    def _create_connections_table(self):
        """Таблица client_connections"""
        sql = """
        CREATE TABLE IF NOT EXISTS client_connections (
            connection_id SERIAL PRIMARY KEY,
            client_id INTEGER REFERENCES clients(client_id) ON DELETE CASCADE,
            exchange_name VARCHAR(50) NOT NULL,
            api_key_encrypted TEXT NOT NULL,
            api_secret_encrypted TEXT NOT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_sync_at TIMESTAMP,
            last_error TEXT
        );
        """
        self.db.execute_query(sql)
    
    def _create_snapshots_table(self):
        """Таблица client_snapshots (TimescaleDB hypertable)"""
        sql = """
        CREATE TABLE IF NOT EXISTS client_snapshots (
            snapshot_id SERIAL PRIMARY KEY,
            connection_id INTEGER REFERENCES client_connections(connection_id) ON DELETE CASCADE,
            timestamp TIMESTAMP NOT NULL,
            baseline_equity_usd NUMERIC(18, 2) NOT NULL,
            session_realized_trading_pnl_usd NUMERIC(18, 2) DEFAULT 0,
            current_total_usd NUMERIC(18, 2) NOT NULL,
            unrealized_pnl NUMERIC(18, 2) DEFAULT 0,
            margin_balance NUMERIC(18, 2),
            available_balance NUMERIC(18, 2),
            full_balance_payload JSONB
        );
        CREATE INDEX IF NOT EXISTS idx_snapshots_connection_time 
        ON client_snapshots(connection_id, timestamp DESC);
        """
        self.db.execute_query(sql)
    
    def _create_trades_table(self):
        """Таблица client_trades"""
        sql = """
        CREATE TABLE IF NOT EXISTS client_trades (
            trade_id SERIAL PRIMARY KEY,
            connection_id INTEGER REFERENCES client_connections(connection_id) ON DELETE CASCADE,
            exchange_trade_id VARCHAR(255) NOT NULL,
            symbol VARCHAR(50) NOT NULL,
            side VARCHAR(10) NOT NULL,
            amount NUMERIC(18, 8) NOT NULL,
            price NUMERIC(18, 8) NOT NULL,
            fee NUMERIC(18, 8) DEFAULT 0,
            fee_currency VARCHAR(10),
            timestamp TIMESTAMP NOT NULL,
            UNIQUE(connection_id, exchange_trade_id)
        );
        CREATE INDEX IF NOT EXISTS idx_trades_connection_time 
        ON client_trades(connection_id, timestamp DESC);
        """
        self.db.execute_query(sql)
    
    def save_client(self, client: Client) -> int:
        """
        Сохранение клиента
        
        Args:
            client: Client объект
        
        Returns:
            client_id
        """
        sql = """
        INSERT INTO clients (client_name, email, is_active, created_at)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (email) DO UPDATE SET
            client_name = EXCLUDED.client_name,
            is_active = EXCLUDED.is_active,
            updated_at = CURRENT_TIMESTAMP
        RETURNING client_id;
        """
        result = self.db.execute_query(
            sql,
            (client.client_name, client.email, client.is_active, client.created_at)
        )
        
        if result and len(result) > 0:
            return result[0]['client_id']
        return None
    
    def get_client(self, client_id: int) -> Optional[Client]:
        """Получение клиента по ID"""
        sql = "SELECT * FROM clients WHERE client_id = %s;"
        result = self.db.execute_query(sql, (client_id,))
        
        if result and len(result) > 0:
            return Client.from_dict(result[0])
        return None
    
    def get_all_clients(self) -> List[Client]:
        """Получение всех клиентов"""
        sql = "SELECT * FROM clients ORDER BY created_at DESC;"
        result = self.db.execute_query(sql)
        
        return [Client.from_dict(row) for row in result] if result else []
    
    def save_connection(self, connection: ClientConnection) -> int:
        """
        Сохранение подключения
        
        Args:
            connection: ClientConnection объект
        
        Returns:
            connection_id
        """
        sql = """
        INSERT INTO client_connections (
            client_id, exchange_name, api_key_encrypted, api_secret_encrypted,
            is_active, created_at
        )
        VALUES (%s, %s, %s, %s, %s, %s)
        RETURNING connection_id;
        """
        result = self.db.execute_query(
            sql,
            (
                connection.client_id,
                connection.exchange_name,
                connection.api_key_encrypted,
                connection.api_secret_encrypted,
                connection.is_active,
                connection.created_at
            )
        )
        
        if result and len(result) > 0:
            return result[0]['connection_id']
        return None
    
    def get_connection(self, connection_id: int) -> Optional[ClientConnection]:
        """Получение подключения по ID"""
        sql = "SELECT * FROM client_connections WHERE connection_id = %s;"
        result = self.db.execute_query(sql, (connection_id,))
        
        if result and len(result) > 0:
            return ClientConnection.from_dict(result[0])
        return None
    
    def get_connections_by_client(self, client_id: int) -> List[ClientConnection]:
        """Получение всех подключений клиента"""
        sql = """
        SELECT * FROM client_connections 
        WHERE client_id = %s 
        ORDER BY created_at DESC;
        """
        result = self.db.execute_query(sql, (client_id,))
        
        return [ClientConnection.from_dict(row) for row in result] if result else []
    
    def update_connection_sync(
        self,
        connection_id: int,
        last_error: Optional[str] = None
    ):
        """Обновление времени синхронизации подключения"""
        sql = """
        UPDATE client_connections 
        SET last_sync_at = CURRENT_TIMESTAMP, last_error = %s
        WHERE connection_id = %s;
        """
        self.db.execute_query(sql, (last_error, connection_id))
    
    def save_snapshot(self, snapshot: ClientSnapshot) -> int:
        """
        Сохранение снапшота
        
        Args:
            snapshot: ClientSnapshot объект
        
        Returns:
            snapshot_id
        """
        sql = """
        INSERT INTO client_snapshots (
            connection_id, timestamp, baseline_equity_usd,
            session_realized_trading_pnl_usd, current_total_usd,
            unrealized_pnl, margin_balance, available_balance,
            full_balance_payload
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        RETURNING snapshot_id;
        """
        result = self.db.execute_query(
            sql,
            (
                snapshot.connection_id,
                snapshot.timestamp,
                snapshot.baseline_equity_usd,
                snapshot.session_realized_trading_pnl_usd,
                snapshot.current_total_usd,
                snapshot.unrealized_pnl,
                snapshot.margin_balance,
                snapshot.available_balance,
                json.dumps(snapshot.full_balance_payload) if snapshot.full_balance_payload else None
            )
        )
        
        if result and len(result) > 0:
            return result[0]['snapshot_id']
        return None
    
    def get_latest_snapshot(self, connection_id: int) -> Optional[ClientSnapshot]:
        """Получение последнего снапшота для подключения"""
        sql = """
        SELECT * FROM client_snapshots 
        WHERE connection_id = %s 
        ORDER BY timestamp DESC 
        LIMIT 1;
        """
        result = self.db.execute_query(sql, (connection_id,))
        
        if result and len(result) > 0:
            return ClientSnapshot.from_dict(result[0])
        return None
    
    def get_snapshots_history(
        self,
        connection_id: int,
        limit: int = 100
    ) -> List[ClientSnapshot]:
        """Получение истории снапшотов"""
        sql = """
        SELECT * FROM client_snapshots 
        WHERE connection_id = %s 
        ORDER BY timestamp DESC 
        LIMIT %s;
        """
        result = self.db.execute_query(sql, (connection_id, limit))
        
        return [ClientSnapshot.from_dict(row) for row in result] if result else []
    
    def save_trade(self, trade: TradeHistory) -> int:
        """
        Сохранение сделки
        
        Args:
            trade: TradeHistory объект
        
        Returns:
            trade_id
        """
        sql = """
        INSERT INTO client_trades (
            connection_id, exchange_trade_id, symbol, side,
            amount, price, fee, fee_currency, timestamp
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (connection_id, exchange_trade_id) DO NOTHING
        RETURNING trade_id;
        """
        result = self.db.execute_query(
            sql,
            (
                trade.connection_id,
                trade.exchange_trade_id,
                trade.symbol,
                trade.side,
                trade.amount,
                trade.price,
                trade.fee,
                trade.fee_currency,
                trade.timestamp
            )
        )
        
        if result and len(result) > 0:
            return result[0]['trade_id']
        return None
    
    def get_trades(
        self,
        connection_id: int,
        limit: int = 100
    ) -> List[TradeHistory]:
        """Получение истории сделок"""
        sql = """
        SELECT * FROM client_trades 
        WHERE connection_id = %s 
        ORDER BY timestamp DESC 
        LIMIT %s;
        """
        result = self.db.execute_query(sql, (connection_id, limit))
        
        return [TradeHistory.from_dict(row) for row in result] if result else []
