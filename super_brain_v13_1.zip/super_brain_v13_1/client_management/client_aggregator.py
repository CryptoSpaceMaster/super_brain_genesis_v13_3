"""
ClientAggregator - синхронизация данных с бирж клиентов через CCXT
Интегрируется с существующим MarketDataCollector и PostgreSQLDataProvider
"""
import logging
import ccxt
from typing import Dict, List, Optional
from datetime import datetime, timedelta

from client_management.encryption_service import EncryptionService

logger = logging.getLogger(__name__)


class ClientAggregator:
    """
    Агрегатор данных клиентских счетов с бирж через CCXT
    Переиспользует rate limiting из существующих провайдеров
    """
    
    def __init__(self, encryption_service: EncryptionService):
        self.encryption_service = encryption_service
        self.exchanges: Dict[int, ccxt.Exchange] = {}
        
        self.exchange_configs = {
            'binance': {'rateLimit': 1200, 'enableRateLimit': True},
            'bybit': {'rateLimit': 1000, 'enableRateLimit': True},
            'okx': {'rateLimit': 1000, 'enableRateLimit': True},
            'bitget': {'rateLimit': 1000, 'enableRateLimit': True},
        }
        
        logger.info("📊 ClientAggregator initialized")
    
    def initialize_connection(
        self,
        connection_id: int,
        exchange_name: str,
        api_key_encrypted: str,
        api_secret_encrypted: str
    ) -> Optional[ccxt.Exchange]:
        """
        Инициализация подключения к бирже клиента
        
        Args:
            connection_id: ID подключения
            exchange_name: Имя биржи (binance, bybit, okx)
            api_key_encrypted: Зашифрованный API ключ
            api_secret_encrypted: Зашифрованный API секрет
        
        Returns:
            CCXT exchange instance или None при ошибке
        """
        try:
            api_key = self.encryption_service.decrypt(api_key_encrypted)
            api_secret = self.encryption_service.decrypt(api_secret_encrypted)
            
            exchange_class = getattr(ccxt, exchange_name.lower())
            
            config = self.exchange_configs.get(exchange_name.lower(), {})
            config.update({
                'apiKey': api_key,
                'secret': api_secret,
            })
            
            exchange = exchange_class(config)
            
            self.exchanges[connection_id] = exchange
            
            logger.info(f"✅ Initialized connection {connection_id} to {exchange_name}")
            return exchange
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize connection {connection_id}: {e}")
            return None
    
    def get_balance(self, connection_id: int) -> Optional[Dict]:
        """
        Получение баланса клиента
        
        Args:
            connection_id: ID подключения
        
        Returns:
            Dict с балансом {'total': {...}, 'free': {...}, 'used': {...}}
        """
        exchange = self.exchanges.get(connection_id)
        if not exchange:
            logger.error(f"❌ Connection {connection_id} not initialized")
            return None
        
        try:
            balance = exchange.fetch_balance()
            return self._normalize_balance(balance)
        except Exception as e:
            logger.error(f"❌ Error fetching balance for connection {connection_id}: {e}")
            return None
    
    def get_positions(self, connection_id: int) -> List[Dict]:
        """
        Получение открытых позиций клиента
        
        Args:
            connection_id: ID подключения
        
        Returns:
            Список открытых позиций
        """
        exchange = self.exchanges.get(connection_id)
        if not exchange:
            logger.error(f"❌ Connection {connection_id} not initialized")
            return []
        
        try:
            if hasattr(exchange, 'fetch_positions'):
                positions = exchange.fetch_positions()
                return [
                    self._normalize_position(p) 
                    for p in positions 
                    if float(p.get('contracts', 0)) != 0
                ]
            return []
        except Exception as e:
            logger.error(f"❌ Error fetching positions for connection {connection_id}: {e}")
            return []
    
    def get_trade_history(
        self,
        connection_id: int,
        symbol: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict]:
        """
        Получение истории сделок клиента
        
        Args:
            connection_id: ID подключения
            symbol: Символ для фильтрации (опционально)
            since: Начальная дата (опционально)
            limit: Максимальное количество сделок
        
        Returns:
            Список сделок
        """
        exchange = self.exchanges.get(connection_id)
        if not exchange:
            logger.error(f"❌ Connection {connection_id} not initialized")
            return []
        
        try:
            since_ms = int(since.timestamp() * 1000) if since else None
            
            if symbol:
                trades = exchange.fetch_my_trades(symbol, since=since_ms, limit=limit)
            else:
                trades = []
            
            return [self._normalize_trade(t) for t in trades]
        except Exception as e:
            logger.error(f"❌ Error fetching trades for connection {connection_id}: {e}")
            return []
    
    def _normalize_balance(self, raw_balance: Dict) -> Dict:
        """Нормализация данных баланса"""
        total = raw_balance.get('total', {})
        free = raw_balance.get('free', {})
        used = raw_balance.get('used', {})
        
        return {
            'total': {k: float(v) for k, v in total.items() if float(v) > 0},
            'free': {k: float(v) for k, v in free.items() if float(v) > 0},
            'used': {k: float(v) for k, v in used.items() if float(v) > 0},
            'timestamp': datetime.utcnow()
        }
    
    def _normalize_position(self, raw_position: Dict) -> Dict:
        """Нормализация данных позиции"""
        return {
            'symbol': raw_position.get('symbol'),
            'side': raw_position.get('side'),
            'contracts': float(raw_position.get('contracts', 0)),
            'entry_price': float(raw_position.get('entryPrice', 0)),
            'mark_price': float(raw_position.get('markPrice', 0)),
            'unrealized_pnl': float(raw_position.get('unrealizedPnl', 0)),
            'liquidation_price': float(raw_position.get('liquidationPrice', 0)) if raw_position.get('liquidationPrice') else None,
            'leverage': float(raw_position.get('leverage', 1)),
        }
    
    def _normalize_trade(self, raw_trade: Dict) -> Dict:
        """Нормализация данных сделки"""
        return {
            'exchange_trade_id': raw_trade.get('id'),
            'symbol': raw_trade.get('symbol'),
            'side': raw_trade.get('side'),
            'amount': float(raw_trade.get('amount', 0)),
            'price': float(raw_trade.get('price', 0)),
            'fee': float(raw_trade.get('fee', {}).get('cost', 0)),
            'fee_currency': raw_trade.get('fee', {}).get('currency'),
            'timestamp': datetime.fromtimestamp(raw_trade.get('timestamp', 0) / 1000)
        }
    
    def close_connection(self, connection_id: int):
        """Закрытие подключения"""
        if connection_id in self.exchanges:
            try:
                self.exchanges[connection_id].close()
            except:
                pass
            del self.exchanges[connection_id]
            logger.info(f"🔌 Closed connection {connection_id}")
    
    def close_all(self):
        """Закрытие всех подключений"""
        for connection_id in list(self.exchanges.keys()):
            self.close_connection(connection_id)
        logger.info("🔌 All connections closed")
