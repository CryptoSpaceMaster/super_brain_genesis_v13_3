"""
Сервис шифрования API-ключей клиентов
AES-256 encryption через cryptography.fernet
"""
import logging
from cryptography.fernet import Fernet
from base64 import urlsafe_b64encode, urlsafe_b64decode

logger = logging.getLogger(__name__)


class EncryptionService:
    """Сервис шифрования API-ключей для безопасного хранения"""
    
    def __init__(self, encryption_key: str):
        """
        Инициализация сервиса шифрования
        
        Args:
            encryption_key: Base64-encoded ключ шифрования (44 символа)
        """
        try:
            self.fernet = Fernet(encryption_key.encode())
            logger.info("🔐 EncryptionService initialized")
        except Exception as e:
            logger.error(f"❌ Failed to initialize encryption: {e}")
            raise
    
    def encrypt(self, data: str) -> str:
        """
        Шифрование данных
        
        Args:
            data: Строка для шифрования (API key, secret)
        
        Returns:
            Base64-encoded зашифрованная строка
        """
        if not data:
            raise ValueError("Data cannot be empty")
        
        try:
            encrypted = self.fernet.encrypt(data.encode())
            return urlsafe_b64encode(encrypted).decode()
        except Exception as e:
            logger.error(f"❌ Encryption failed: {e}")
            raise
    
    def decrypt(self, encrypted_data: str) -> str:
        """
        Дешифрование данных
        
        Args:
            encrypted_data: Base64-encoded зашифрованная строка
        
        Returns:
            Расшифрованная строка
        """
        if not encrypted_data:
            raise ValueError("Encrypted data cannot be empty")
        
        try:
            decoded = urlsafe_b64decode(encrypted_data.encode())
            decrypted = self.fernet.decrypt(decoded)
            return decrypted.decode()
        except Exception as e:
            logger.error(f"❌ Decryption failed: {e}")
            raise ValueError(f"Decryption failed: {str(e)}")
    
    @staticmethod
    def generate_key() -> str:
        """Генерация нового ключа шифрования"""
        return Fernet.generate_key().decode()


if __name__ == "__main__":
    print(f"Generated encryption key: {EncryptionService.generate_key()}")
