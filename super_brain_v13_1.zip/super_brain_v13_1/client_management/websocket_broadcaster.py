"""
WebSocket Broadcaster для real-time обновлений Client Management
Использует простой WebSocket для передачи обновлений снапшотов
"""
import logging
import json
import asyncio
from typing import Set, Dict
import threading

logger = logging.getLogger(__name__)


class WebSocketBroadcaster:
    """
    Простой WebSocket broadcaster для real-time обновлений
    
    Интегрируется с ClientManager для передачи:
    - Новых снапшотов
    - Обновлений балансов
    - Изменений P&L
    """
    
    def __init__(self):
        self.clients: Set = set()
        self.update_queue = asyncio.Queue()
        self.enabled = False
        
        logger.info("📡 WebSocketBroadcaster initialized")
    
    def enable(self):
        """Включение broadcaster"""
        self.enabled = True
        logger.info("✅ WebSocket broadcasting ENABLED")
    
    def disable(self):
        """Выключение broadcaster"""
        self.enabled = False
        logger.info("⏸️ WebSocket broadcasting DISABLED")
    
    async def register_client(self, websocket):
        """Регистрация WebSocket клиента"""
        self.clients.add(websocket)
        logger.info(f"📥 WebSocket client connected ({len(self.clients)} total)")
    
    async def unregister_client(self, websocket):
        """Отмена регистрации WebSocket клиента"""
        self.clients.discard(websocket)
        logger.info(f"📤 WebSocket client disconnected ({len(self.clients)} total)")
    
    async def broadcast_snapshot(self, snapshot_data: Dict):
        """
        Рассылка снапшота всем подключенным клиентам
        
        Args:
            snapshot_data: Dict с данными снапшота
        """
        if not self.enabled or not self.clients:
            return
        
        message = json.dumps({
            'type': 'snapshot',
            'data': snapshot_data,
            'timestamp': snapshot_data.get('timestamp')
        })
        
        disconnected = set()
        
        for client in self.clients:
            try:
                await client.send(message)
            except Exception as e:
                logger.error(f"Failed to send to client: {e}")
                disconnected.add(client)
        
        for client in disconnected:
            await self.unregister_client(client)
    
    async def broadcast_client_update(self, client_summary: Dict):
        """
        Рассылка обновления клиента
        
        Args:
            client_summary: Dict с данными клиента
        """
        if not self.enabled or not self.clients:
            return
        
        message = json.dumps({
            'type': 'client_update',
            'data': client_summary
        })
        
        disconnected = set()
        
        for client in self.clients:
            try:
                await client.send(message)
            except Exception as e:
                logger.error(f"Failed to send to client: {e}")
                disconnected.add(client)
        
        for client in disconnected:
            await self.unregister_client(client)
    
    def notify_snapshot(self, snapshot_data: Dict):
        """
        Синхронный метод для уведомления о снапшоте
        Вызывается из ClientManager.create_snapshot
        
        Args:
            snapshot_data: Dict с данными снапшота
        """
        if not self.enabled:
            return
        
        try:
            asyncio.create_task(self.broadcast_snapshot(snapshot_data))
        except RuntimeError:
            pass
    
    def get_stats(self) -> Dict:
        """Получение статистики broadcaster"""
        return {
            'enabled': self.enabled,
            'connected_clients': len(self.clients),
            'queue_size': self.update_queue.qsize()
        }


broadcaster_instance = WebSocketBroadcaster()


def get_broadcaster() -> WebSocketBroadcaster:
    """Получение глобального instance broadcaster"""
    return broadcaster_instance
