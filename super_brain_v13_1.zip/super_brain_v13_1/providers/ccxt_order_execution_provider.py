#!/usr/bin/env python3
"""
CCXT Order Execution Provider
Реальное исполнение ордеров через CCXT library
"""
import ccxt.async_support as ccxt
from typing import Dict, List, Optional
from datetime import datetime
import logging

from .order_execution_provider import (
    OrderExecutionProvider, OrderSide, OrderType, OrderStatus
)

logger = logging.getLogger(__name__)

class CCXTOrderExecutionProvider(OrderExecutionProvider):
    """
    Real order execution provider using CCXT
    Подключается к реальным биржам для исполнения ордеров
    
    ⚠️ ВАЖНО: Работает с реальными деньгами!
    """
    
    def __init__(self, exchange_id: str = 'binance', 
                 api_key: Optional[str] = None,
                 api_secret: Optional[str] = None,
                 testnet: bool = True,
                 config: Optional[Dict] = None):
        """
        Args:
            exchange_id: ID биржи ('binance', 'bybit', 'okx', etc)
            api_key: API ключ
            api_secret: API secret
            testnet: Использовать testnet (безопасно для тестов)
            config: Дополнительная конфигурация
        """
        self.exchange_id = exchange_id
        self.testnet = testnet
        
        exchange_config = {
            'apiKey': api_key,
            'secret': api_secret,
            'enableRateLimit': True,
            'options': {
                'defaultType': 'future',
            }
        }
        
        if testnet:
            exchange_config['options']['defaultType'] = 'future'
            if exchange_id == 'binance':
                exchange_config['urls'] = {
                    'api': {
                        'public': 'https://testnet.binancefuture.com',
                        'private': 'https://testnet.binancefuture.com',
                    }
                }
        
        if config:
            exchange_config.update(config)
        
        exchange_class = getattr(ccxt, exchange_id)
        self.exchange = exchange_class(exchange_config)
        
        mode = "TESTNET" if testnet else "PRODUCTION"
        logger.info(f"✅ CCXTOrderExecutionProvider initialized ({exchange_id} - {mode})")
        
        if not testnet:
            logger.warning("⚠️ PRODUCTION MODE - реальные деньги!")
    
    async def initialize(self):
        """Загрузка рынков и проверка подключения"""
        try:
            await self.exchange.load_markets()
            balance = await self.get_balance()
            
            logger.info(f"✅ Connected to {self.exchange_id}")
            logger.info(f"   Balance: {list(balance['total'].keys())}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to initialize {self.exchange_id}: {e}")
            return False
    
    async def create_order(self, symbol: str, side: OrderSide, order_type: OrderType,
                          amount: float, price: Optional[float] = None,
                          params: Optional[Dict] = None) -> Dict:
        """Создать ордер"""
        try:
            ccxt_params = params or {}
            
            if order_type == OrderType.MARKET:
                order = await self.exchange.create_market_order(
                    symbol, side.value, amount, ccxt_params
                )
            elif order_type == OrderType.LIMIT:
                if price is None:
                    raise ValueError("Price required for LIMIT orders")
                order = await self.exchange.create_limit_order(
                    symbol, side.value, amount, price, ccxt_params
                )
            else:
                raise ValueError(f"Unsupported order type: {order_type}")
            
            result = {
                'order_id': order['id'],
                'symbol': symbol,
                'side': side.value,
                'type': order_type.value,
                'amount': amount,
                'price': price or order.get('price', 0),
                'status': self._map_order_status(order['status']),
                'timestamp': datetime.fromtimestamp(order['timestamp'] / 1000),
                'filled': order.get('filled', 0),
                'remaining': order.get('remaining', amount),
                'cost': order.get('cost', 0)
            }
            
            logger.info(f"✅ Order created: {result['order_id']} {side.value} {amount} {symbol}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Error creating order: {e}")
            raise
    
    async def cancel_order(self, order_id: str, symbol: str) -> Dict:
        """Отменить ордер"""
        try:
            order = await self.exchange.cancel_order(order_id, symbol)
            
            result = {
                'order_id': order['id'],
                'symbol': symbol,
                'status': self._map_order_status(order['status']),
                'timestamp': datetime.fromtimestamp(order['timestamp'] / 1000)
            }
            
            logger.info(f"✅ Order canceled: {order_id}")
            return result
            
        except Exception as e:
            logger.error(f"❌ Error canceling order {order_id}: {e}")
            raise
    
    async def get_order(self, order_id: str, symbol: str) -> Dict:
        """Получить информацию об ордере"""
        try:
            order = await self.exchange.fetch_order(order_id, symbol)
            
            return {
                'order_id': order['id'],
                'symbol': symbol,
                'side': order['side'],
                'type': order['type'],
                'amount': order['amount'],
                'price': order.get('price', 0),
                'status': self._map_order_status(order['status']),
                'timestamp': datetime.fromtimestamp(order['timestamp'] / 1000),
                'filled': order.get('filled', 0),
                'remaining': order.get('remaining', 0),
                'cost': order.get('cost', 0)
            }
        except Exception as e:
            logger.error(f"❌ Error fetching order {order_id}: {e}")
            raise
    
    async def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict]:
        """Получить все открытые ордера"""
        try:
            orders = await self.exchange.fetch_open_orders(symbol)
            
            return [
                {
                    'order_id': order['id'],
                    'symbol': order['symbol'],
                    'side': order['side'],
                    'type': order['type'],
                    'amount': order['amount'],
                    'price': order.get('price', 0),
                    'status': self._map_order_status(order['status']),
                    'timestamp': datetime.fromtimestamp(order['timestamp'] / 1000),
                    'filled': order.get('filled', 0),
                    'remaining': order.get('remaining', 0)
                }
                for order in orders
            ]
        except Exception as e:
            logger.error(f"❌ Error fetching open orders: {e}")
            raise
    
    async def get_balance(self) -> Dict:
        """Получить баланс аккаунта"""
        try:
            balance = await self.exchange.fetch_balance()
            
            return {
                'total': balance['total'],
                'free': balance['free'],
                'used': balance['used'],
                'timestamp': datetime.now()
            }
        except Exception as e:
            logger.error(f"❌ Error fetching balance: {e}")
            raise
    
    async def get_positions(self, symbol: Optional[str] = None) -> List[Dict]:
        """Получить открытые позиции"""
        try:
            positions = await self.exchange.fetch_positions([symbol] if symbol else None)
            
            return [
                {
                    'symbol': pos['symbol'],
                    'side': pos['side'],
                    'amount': abs(pos['contracts']),
                    'entry_price': pos['entryPrice'],
                    'current_price': pos['markPrice'],
                    'unrealized_pnl': pos['unrealizedPnl'],
                    'liquidation_price': pos.get('liquidationPrice', 0),
                    'leverage': pos.get('leverage', 1),
                    'margin': pos.get('collateral', 0),
                    'timestamp': datetime.fromtimestamp(pos['timestamp'] / 1000)
                }
                for pos in positions
                if pos['contracts'] != 0
            ]
        except Exception as e:
            logger.error(f"❌ Error fetching positions: {e}")
            return []
    
    async def close_position(self, symbol: str, side: str) -> Dict:
        """Закрыть позицию"""
        try:
            positions = await self.get_positions(symbol)
            
            for pos in positions:
                if pos['symbol'] == symbol and pos['side'] == side:
                    close_side = OrderSide.SELL if side == 'long' else OrderSide.BUY
                    
                    result = await self.create_order(
                        symbol=symbol,
                        side=close_side,
                        order_type=OrderType.MARKET,
                        amount=pos['amount'],
                        params={'reduceOnly': True}
                    )
                    
                    logger.info(f"✅ Position closed: {symbol} {side}")
                    return result
            
            raise ValueError(f"No {side} position found for {symbol}")
            
        except Exception as e:
            logger.error(f"❌ Error closing position: {e}")
            raise
    
    async def health_check(self) -> Dict:
        """Проверка подключения к бирже"""
        try:
            import asyncio
            start_time = asyncio.get_event_loop().time()
            
            await self.exchange.fetch_time()
            
            latency = (asyncio.get_event_loop().time() - start_time) * 1000
            
            rate_limits = self.exchange.rateLimit if hasattr(self.exchange, 'rateLimit') else {}
            
            return {
                'healthy': True,
                'exchange': self.exchange_id,
                'latency_ms': round(latency, 2),
                'api_limits': rate_limits,
                'timestamp': datetime.now(),
                'testnet': self.testnet
            }
        except Exception as e:
            logger.error(f"❌ Health check failed: {e}")
            return {
                'healthy': False,
                'exchange': self.exchange_id,
                'latency_ms': -1,
                'api_limits': {},
                'timestamp': datetime.now(),
                'error': str(e),
                'testnet': self.testnet
            }
    
    def _map_order_status(self, ccxt_status: str) -> str:
        """Маппинг статусов CCXT в наши OrderStatus"""
        mapping = {
            'open': OrderStatus.OPEN.value,
            'closed': OrderStatus.FILLED.value,
            'canceled': OrderStatus.CANCELED.value,
            'expired': OrderStatus.CANCELED.value,
            'rejected': OrderStatus.REJECTED.value,
        }
        return mapping.get(ccxt_status, OrderStatus.PENDING.value)
    
    async def close(self):
        """Закрыть соединение с биржей"""
        await self.exchange.close()
        logger.info(f"✅ Closed connection to {self.exchange_id}")
