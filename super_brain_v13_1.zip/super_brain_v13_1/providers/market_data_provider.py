#!/usr/bin/env python3
"""
Market Data Provider Interface
Абстрактный базовый класс для провайдеров рыночных данных
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
import pandas as pd
from datetime import datetime

class MarketDataProvider(ABC):
    """
    Абстрактный интерфейс для провайдеров рыночных данных
    
    Заменяет simulation stubs реальными источниками данных:
    - CCXT для real-time биржевых данных
    - TimescaleDB для исторических данных
    - WebSocket для streaming данных
    """
    
    @abstractmethod
    async def get_ticker(self, symbol: str) -> Dict:
        """
        Получить текущую цену и статистику символа
        
        Returns:
            {
                'symbol': str,
                'price': float,
                'bid': float,
                'ask': float,
                'volume_24h': float,
                'high_24h': float,
                'low_24h': float,
                'change_24h': float,
                'timestamp': datetime
            }
        """
        pass
    
    @abstractmethod
    async def get_ohlcv(self, symbol: str, timeframe: str = '1h', 
                        limit: int = 100, since: Optional[datetime] = None) -> pd.DataFrame:
        """
        Получить OHLCV данные (klines)
        
        Args:
            symbol: Торговая пара (e.g. 'BTC/USDT')
            timeframe: Таймфрейм ('1m', '5m', '15m', '1h', '4h', '1d')
            limit: Количество свечей
            since: Начальная дата
        
        Returns:
            DataFrame с колонками: [timestamp, open, high, low, close, volume]
        """
        pass
    
    @abstractmethod
    async def get_orderbook(self, symbol: str, limit: int = 20) -> Dict:
        """
        Получить стакан ордеров
        
        Returns:
            {
                'symbol': str,
                'timestamp': datetime,
                'bids': List[Tuple[price, amount]],
                'asks': List[Tuple[price, amount]],
                'bid_volume': float,
                'ask_volume': float
            }
        """
        pass
    
    @abstractmethod
    async def get_recent_trades(self, symbol: str, limit: int = 100) -> List[Dict]:
        """
        Получить последние сделки
        
        Returns:
            List of trades: [
                {
                    'timestamp': datetime,
                    'price': float,
                    'amount': float,
                    'side': 'buy' | 'sell',
                    'id': str
                }
            ]
        """
        pass
    
    @abstractmethod
    async def get_funding_rate(self, symbol: str) -> Dict:
        """
        Получить funding rate для фьючерсов
        
        Returns:
            {
                'symbol': str,
                'funding_rate': float,
                'next_funding_time': datetime,
                'timestamp': datetime
            }
        """
        pass
    
    @abstractmethod
    async def get_open_interest(self, symbol: str) -> Dict:
        """
        Получить открытый интерес для фьючерсов
        
        Returns:
            {
                'symbol': str,
                'open_interest': float,
                'timestamp': datetime
            }
        """
        pass
    
    @abstractmethod
    async def health_check(self) -> Dict:
        """
        Проверка доступности источника данных
        
        Returns:
            {
                'healthy': bool,
                'latency_ms': float,
                'provider': str,
                'timestamp': datetime
            }
        """
        pass
