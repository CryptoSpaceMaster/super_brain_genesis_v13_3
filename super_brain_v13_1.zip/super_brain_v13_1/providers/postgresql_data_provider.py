"""
PostgreSQL Data Provider - Универсальный провайдер для получения всех рыночных данных
Источник: PostgreSQL/TimescaleDB с 6 типами данных:
1. OHLCV (klines.py) - свечные данные
2. Trades (trades.py) - CVD расчет
3. OrderBook (orderbook.py) - OBI расчет  
4. Tickers (tickers.py) - топ-100 пар
5. Funding (funding.py) - derivatives данные
6. CryptoQuant - ончейн метрики (отдельный провайдер)

Все данные в реальном времени из производственной базы данных.
"""

import logging
import psycopg2
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import os
from enum import Enum

logger = logging.getLogger(__name__)


class TableType(Enum):
    """Типы таблиц в PostgreSQL"""
    OHLCV = "ohlcv"
    TRADES = "trades"
    ORDERBOOK = "orderbook"
    TICKERS = "tickers"
    FUNDING = "funding"


class PostgreSQLDataProvider:
    """
    PostgreSQL Data Provider - центральный провайдер рыночных данных
    
    Подключается к PostgreSQL/TimescaleDB и получает актуальные данные
    из всех таблиц, создаваемых сборщиками данных.
    """
    
    def __init__(
        self, 
        config: Dict = None,
        host: str = None,
        database: str = None,
        user: str = None,
        password: str = None,
        port: int = None,
        simulation_mode: bool = False
    ):
        """
        Args:
            config: Config dict (если передан, параметры берутся из него)
            host: Хост PostgreSQL (default: db)
            database: Имя базы данных (default: postgres)
            user: Пользователь (default: postgres)
            password: Пароль
            port: Порт (default: 5432)
            simulation_mode: Режим симуляции (без реальной БД)
        """
        if isinstance(config, dict):
            self.simulation_mode = config.get('simulation_mode', False)
            self.host = config.get('host', os.getenv('DB_HOST', 'db'))
            self.database = config.get('database', os.getenv('DB_NAME', 'postgres'))
            self.user = config.get('user', os.getenv('DB_USER', 'postgres'))
            self.password = config.get('password', os.getenv('DB_PASS', ''))
            self.port = config.get('port', int(os.getenv('DB_PORT', '5432')))
        else:
            self.simulation_mode = simulation_mode
            self.host = host or os.getenv('DB_HOST', 'db')
            self.database = database or os.getenv('DB_NAME', 'postgres')
            self.user = user or os.getenv('DB_USER', 'postgres')
            self.password = password or os.getenv('DB_PASS', '')
            self.port = port or int(os.getenv('DB_PORT', '5432'))
        
        self.connection = None
        self._last_connection_attempt = None
        
        logger.info("🔌 PostgreSQL Data Provider initialized")
        logger.info(f"   Host: {self.host}:{self.port}")
        logger.info(f"   Database: {self.database}")
        logger.info(f"   User: {self.user}")
        logger.info(f"   Mode: {'SIMULATION' if simulation_mode else 'PRODUCTION'}")
    
    def connect(self) -> bool:
        """Подключение к PostgreSQL"""
        if self.simulation_mode:
            logger.info("📦 Simulation mode - skipping real connection")
            return True
        
        try:
            if self.connection and not self.connection.closed:
                return True
            
            self.connection = psycopg2.connect(
                host=self.host,
                database=self.database,
                user=self.user,
                password=self.password,
                port=self.port
            )
            self._last_connection_attempt = datetime.now()
            
            logger.info("✅ PostgreSQL connected successfully")
            return True
            
        except Exception as e:
            logger.error(f"❌ PostgreSQL connection failed: {e}")
            self.connection = None
            return False
    
    def disconnect(self):
        """Закрытие соединения"""
        if self.connection and not self.connection.closed:
            self.connection.close()
            logger.info("🔌 PostgreSQL disconnected")
    
    def execute_query(self, query: str, params: tuple = None) -> Optional[List[tuple]]:
        """
        Выполнение SQL запроса
        
        Args:
            query: SQL запрос
            params: Параметры запроса
            
        Returns:
            Список результатов или None при ошибке
        """
        if self.simulation_mode:
            logger.debug(f"📦 Simulation mode - query skipped: {query[:100]}")
            return []
        
        try:
            if not self.connect():
                return None
            
            cursor = self.connection.cursor()
            cursor.execute(query, params or ())
            results = cursor.fetchall()
            cursor.close()
            
            return results
            
        except Exception as e:
            logger.error(f"❌ Query execution failed: {e}")
            logger.error(f"   Query: {query[:200]}")
            return None
    
    def get_ohlcv_data(
        self, 
        exchange: str, 
        symbol: str, 
        timeframe: str = '1h',
        limit: int = 100
    ) -> Optional[List[Dict]]:
        """
        Получение OHLCV данных (свечей)
        
        Args:
            exchange: Биржа (binance, okx, etc)
            symbol: Символ (BTC/USDT)
            timeframe: Таймфрейм (1h, 4h, etc)
            limit: Количество свечей
            
        Returns:
            Список OHLCV данных с полями:
            - timestamp, datetime, bar_index
            - open, high, low, close, volume
            - hl2, hlc3, ohlc4
        """
        if self.simulation_mode:
            logger.warning(f"📦 Simulation mode - returning mock OHLCV for {symbol}")
            return self._get_mock_ohlcv(symbol, limit)
        
        clean_symbol = symbol.replace('/', '_').replace('-', '_').lower()
        table_name = f"ohlcv_{exchange.lower()}_{clean_symbol}_{timeframe}"
        
        query = f"""
            SELECT 
                timestamp, bar_index,
                open, high, low, close, volume,
                hl2, hlc3, ohlc4
            FROM {table_name}
            WHERE symbol = %s AND timeframe = %s
            ORDER BY timestamp DESC
            LIMIT %s
        """
        
        try:
            results = self.execute_query(query, (symbol, timeframe, limit))
            
            if not results:
                logger.warning(f"⚠️  No OHLCV data found for {symbol} {timeframe}")
                return []
            
            ohlcv_data = []
            for row in reversed(results):
                ohlcv_data.append({
                    'timestamp': int(row[0].timestamp() * 1000),
                    'datetime': row[0].isoformat(),
                    'bar_index': row[1],
                    'open': float(row[2]),
                    'high': float(row[3]),
                    'low': float(row[4]),
                    'close': float(row[5]),
                    'volume': float(row[6]),
                    'hl2': float(row[7]),
                    'hlc3': float(row[8]),
                    'ohlc4': float(row[9])
                })
            
            logger.info(f"✅ OHLCV data loaded: {len(ohlcv_data)} bars for {symbol}")
            return ohlcv_data
            
        except Exception as e:
            logger.error(f"❌ Failed to load OHLCV for {symbol}: {e}")
            return []
    
    def get_trades_data(
        self, 
        exchange: str, 
        symbol: str,
        timeframe: str = '1m'
    ) -> Optional[Dict]:
        """
        Получение Trades данных (CVD, buy/sell volume)
        
        Args:
            exchange: Биржа
            symbol: Символ
            timeframe: Таймфрейм для агрегации
            
        Returns:
            Dict с CVD метриками:
            - cvd_total, cvd_1min, cvd_5min
            - buy_volume_1min, sell_volume_1min
            - buy_volume_5min, sell_volume_5min
            - buy_sell_ratio, aggressive_buy_pct, aggressive_sell_pct
        """
        if self.simulation_mode:
            return self._get_mock_trades(symbol)
        
        table_name = f"trades_{exchange.lower()}_{timeframe}"
        
        query = f"""
            SELECT 
                cvd_total, cvd_1min, cvd_5min,
                buy_volume_1min, sell_volume_1min,
                buy_volume_5min, sell_volume_5min,
                buy_sell_ratio, aggressive_buy_pct, aggressive_sell_pct
            FROM {table_name}
            WHERE symbol = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (symbol,))
            
            if not results or len(results) == 0:
                logger.warning(f"⚠️  No trades data found for {symbol}")
                return None
            
            row = results[0]
            trades_data = {
                'cvd_total': float(row[0]) if row[0] else 0.0,
                'cvd_1min': float(row[1]) if row[1] else 0.0,
                'cvd_5min': float(row[2]) if row[2] else 0.0,
                'buy_volume_1min': float(row[3]) if row[3] else 0.0,
                'sell_volume_1min': float(row[4]) if row[4] else 0.0,
                'buy_volume_5min': float(row[5]) if row[5] else 0.0,
                'sell_volume_5min': float(row[6]) if row[6] else 0.0,
                'buy_sell_ratio': float(row[7]) if row[7] else 1.0,
                'aggressive_buy_pct': float(row[8]) if row[8] else 50.0,
                'aggressive_sell_pct': float(row[9]) if row[9] else 50.0
            }
            
            logger.info(f"✅ Trades data loaded for {symbol}: CVD={trades_data['cvd_total']:.2f}")
            return trades_data
            
        except Exception as e:
            logger.error(f"❌ Failed to load trades for {symbol}: {e}")
            return None
    
    def get_orderbook_data(
        self, 
        exchange: str, 
        symbol: str,
        timeframe: str = '30s'
    ) -> Optional[Dict]:
        """
        Получение OrderBook данных (OBI, spread, depth)
        
        Args:
            exchange: Биржа
            symbol: Символ
            timeframe: Таймфрейм обновления
            
        Returns:
            Dict с OrderBook метриками:
            - best_bid, best_ask, spread_abs, spread_pct
            - obi_l5, obi_l10
            - bid_depth_1pct, ask_depth_1pct
            - max_bid_level, max_ask_level
            - bid_wall_price, ask_wall_price
        """
        if self.simulation_mode:
            return self._get_mock_orderbook(symbol)
        
        table_name = f"orderbook_{exchange.lower()}_{timeframe}"
        
        query = f"""
            SELECT 
                best_bid, best_ask, spread_abs, spread_pct,
                bids_volume_l5, asks_volume_l5,
                obi_l5, obi_l10,
                bid_depth_1pct, ask_depth_1pct,
                max_bid_level, max_ask_level,
                bid_wall_price, ask_wall_price
            FROM {table_name}
            WHERE symbol = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (symbol,))
            
            if not results or len(results) == 0:
                logger.warning(f"⚠️  No orderbook data found for {symbol}")
                return None
            
            row = results[0]
            orderbook_data = {
                'best_bid': float(row[0]) if row[0] else 0.0,
                'best_ask': float(row[1]) if row[1] else 0.0,
                'spread_abs': float(row[2]) if row[2] else 0.0,
                'spread_pct': float(row[3]) if row[3] else 0.0,
                'bids_volume_l5': float(row[4]) if row[4] else 0.0,
                'asks_volume_l5': float(row[5]) if row[5] else 0.0,
                'obi_l5': float(row[6]) if row[6] else 0.0,
                'obi_l10': float(row[7]) if row[7] else 0.0,
                'bid_depth_1pct': float(row[8]) if row[8] else 0.0,
                'ask_depth_1pct': float(row[9]) if row[9] else 0.0,
                'max_bid_level': float(row[10]) if row[10] else 0.0,
                'max_ask_level': float(row[11]) if row[11] else 0.0,
                'bid_wall_price': float(row[12]) if row[12] else 0.0,
                'ask_wall_price': float(row[13]) if row[13] else 0.0
            }
            
            logger.info(f"✅ OrderBook data loaded for {symbol}: OBI_L5={orderbook_data['obi_l5']:.4f}")
            return orderbook_data
            
        except Exception as e:
            logger.error(f"❌ Failed to load orderbook for {symbol}: {e}")
            return None
    
    def get_ticker_data(
        self, 
        exchange: str, 
        symbol: str
    ) -> Optional[Dict]:
        """
        Получение Ticker данных (цены, объемы, изменения)
        
        Args:
            exchange: Биржа
            symbol: Символ
            
        Returns:
            Dict с ticker метриками:
            - last_price, bid, ask
            - base_volume, quote_volume
            - price_change_24h, percentage_change_24h
            - high_24h, low_24h
        """
        if self.simulation_mode:
            return self._get_mock_ticker(symbol)
        
        table_name = f"tickers_{exchange.lower()}_5m"
        
        query = f"""
            SELECT 
                last_price, bid, ask,
                base_volume, quote_volume,
                price_change_24h, percentage_change_24h,
                high_24h, low_24h,
                timestamp
            FROM {table_name}
            WHERE symbol = %s
            ORDER BY created_at DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (symbol,))
            
            if not results or len(results) == 0:
                logger.warning(f"⚠️  No ticker data found for {symbol}")
                return None
            
            row = results[0]
            ticker_data = {
                'last_price': float(row[0]) if row[0] else 0.0,
                'bid': float(row[1]) if row[1] else 0.0,
                'ask': float(row[2]) if row[2] else 0.0,
                'base_volume': float(row[3]) if row[3] else 0.0,
                'quote_volume': float(row[4]) if row[4] else 0.0,
                'price_change_24h': float(row[5]) if row[5] else 0.0,
                'percentage_change_24h': float(row[6]) if row[6] else 0.0,
                'high_24h': float(row[7]) if row[7] else 0.0,
                'low_24h': float(row[8]) if row[8] else 0.0,
                'timestamp': row[9].isoformat() if row[9] else datetime.now().isoformat()
            }
            
            logger.info(f"✅ Ticker data loaded for {symbol}: ${ticker_data['last_price']:.2f}")
            return ticker_data
            
        except Exception as e:
            logger.error(f"❌ Failed to load ticker for {symbol}: {e}")
            return None
    
    def get_funding_data(
        self, 
        exchange: str, 
        symbol: str,
        timeframe: str = '1h'
    ) -> Optional[Dict]:
        """
        Получение Funding данных (derivatives, open interest)
        
        Args:
            exchange: Биржа
            symbol: Символ (должен быть futures формат, например BTC/USDT:USDT)
            timeframe: Таймфрейм
            
        Returns:
            Dict с funding метриками:
            - funding_rate, next_funding_time
            - open_interest
            - mark_price, index_price, premium_index
            - basis_rate
            - long_short_ratio, top_trader_sentiment
        """
        if self.simulation_mode:
            return self._get_mock_funding(symbol)
        
        table_name = f"funding_{exchange.lower()}_{timeframe}"
        
        query = f"""
            SELECT 
                funding_rate, funding_timestamp, next_funding_time,
                open_interest, mark_price, index_price,
                premium_index, basis_rate,
                base_volume_24h, quote_volume_24h,
                max_leverage, long_short_ratio, top_trader_sentiment,
                contract_size, contract_type
            FROM {table_name}
            WHERE symbol = %s
            ORDER BY last_updated DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (symbol,))
            
            if not results or len(results) == 0:
                logger.warning(f"⚠️  No funding data found for {symbol}")
                return None
            
            row = results[0]
            funding_data = {
                'funding_rate': float(row[0]) if row[0] else 0.0,
                'funding_timestamp': row[1].isoformat() if row[1] else None,
                'next_funding_time': row[2].isoformat() if row[2] else None,
                'open_interest': float(row[3]) if row[3] else 0.0,
                'mark_price': float(row[4]) if row[4] else 0.0,
                'index_price': float(row[5]) if row[5] else 0.0,
                'premium_index': float(row[6]) if row[6] else 0.0,
                'basis_rate': float(row[7]) if row[7] else 0.0,
                'base_volume_24h': float(row[8]) if row[8] else 0.0,
                'quote_volume_24h': float(row[9]) if row[9] else 0.0,
                'max_leverage': int(row[10]) if row[10] else 125,
                'long_short_ratio': float(row[11]) if row[11] else 1.0,
                'top_trader_sentiment': float(row[12]) if row[12] else 50.0,
                'contract_size': float(row[13]) if row[13] else 1.0,
                'contract_type': row[14] if row[14] else 'perpetual'
            }
            
            logger.info(f"✅ Funding data loaded for {symbol}: FR={funding_data['funding_rate']:.6f}%")
            return funding_data
            
        except Exception as e:
            logger.error(f"❌ Failed to load funding for {symbol}: {e}")
            return None
    
    def get_all_market_data(
        self, 
        exchange: str, 
        symbol: str,
        timeframe: str = '1h',
        ohlcv_limit: int = 100
    ) -> Dict:
        """
        Получение ВСЕХ рыночных данных для символа
        
        Args:
            exchange: Биржа
            symbol: Символ
            timeframe: Таймфрейм
            ohlcv_limit: Количество свечей
            
        Returns:
            Dict со всеми данными:
            - ohlcv: список OHLCV баров
            - trades: CVD метрики
            - orderbook: OBI метрики
            - ticker: ценовые данные
            - funding: derivatives данные
        """
        logger.info(f"📊 Loading ALL market data for {symbol}")
        
        all_data = {
            'symbol': symbol,
            'exchange': exchange,
            'timeframe': timeframe,
            'timestamp': datetime.now().isoformat(),
            'ohlcv': self.get_ohlcv_data(exchange, symbol, timeframe, ohlcv_limit),
            'trades': self.get_trades_data(exchange, symbol),
            'orderbook': self.get_orderbook_data(exchange, symbol),
            'ticker': self.get_ticker_data(exchange, symbol),
            'funding': self.get_funding_data(exchange, symbol.replace('/USDT', '/USDT:USDT'))
        }
        
        logger.info(f"✅ ALL market data loaded for {symbol}")
        return all_data
    
    def _get_mock_ohlcv(self, symbol: str, limit: int):
        """Mock OHLCV для simulation mode - returns DataFrame compatible with production"""
        import random
        import pandas as pd
        
        base_price = 50000 if 'BTC' in symbol else 3000
        
        mock_data = []
        for i in range(limit):
            price = base_price * (1 + random.uniform(-0.02, 0.02))
            mock_data.append({
                'timestamp': int((datetime.now() - timedelta(hours=limit-i)).timestamp() * 1000),
                'datetime': (datetime.now() - timedelta(hours=limit-i)).isoformat(),
                'bar_index': limit - i - 1,
                'open': price,
                'high': price * 1.01,
                'low': price * 0.99,
                'close': price * (1 + random.uniform(-0.01, 0.01)),
                'volume': random.uniform(100, 1000),
                'hl2': price,
                'hlc3': price,
                'ohlc4': price
            })
        
        return pd.DataFrame(mock_data)
    
    def _get_mock_trades(self, symbol: str) -> Dict:
        """Mock Trades для simulation mode"""
        return {
            'cvd_total': 150000.0,
            'cvd_1min': 5000.0,
            'cvd_5min': 15000.0,
            'buy_volume_1min': 50000.0,
            'sell_volume_1min': 45000.0,
            'buy_volume_5min': 250000.0,
            'sell_volume_5min': 235000.0,
            'buy_sell_ratio': 1.05,
            'aggressive_buy_pct': 52.5,
            'aggressive_sell_pct': 47.5
        }
    
    def _get_mock_orderbook(self, symbol: str) -> Dict:
        """Mock OrderBook для simulation mode"""
        price = 50000 if 'BTC' in symbol else 3000
        return {
            'best_bid': price * 0.9999,
            'best_ask': price * 1.0001,
            'spread_abs': price * 0.0002,
            'spread_pct': 0.02,
            'bids_volume_l5': 100.0,
            'asks_volume_l5': 95.0,
            'obi_l5': 0.025,
            'obi_l10': 0.03,
            'bid_depth_1pct': 500.0,
            'ask_depth_1pct': 480.0,
            'max_bid_level': 50.0,
            'max_ask_level': 45.0,
            'bid_wall_price': price * 0.998,
            'ask_wall_price': price * 1.002
        }
    
    def _get_mock_ticker(self, symbol: str) -> Dict:
        """Mock Ticker для simulation mode"""
        price = 50000 if 'BTC' in symbol else 3000
        return {
            'last_price': price,
            'bid': price * 0.9999,
            'ask': price * 1.0001,
            'base_volume': 10000.0,
            'quote_volume': price * 10000.0,
            'price_change_24h': price * 0.02,
            'percentage_change_24h': 2.0,
            'high_24h': price * 1.05,
            'low_24h': price * 0.95,
            'timestamp': datetime.now().isoformat()
        }
    
    def _get_mock_funding(self, symbol: str) -> Dict:
        """Mock Funding для simulation mode"""
        price = 50000 if 'BTC' in symbol else 3000
        return {
            'funding_rate': 0.0001,
            'funding_timestamp': datetime.now().isoformat(),
            'next_funding_time': (datetime.now() + timedelta(hours=8)).isoformat(),
            'open_interest': 1000000.0,
            'mark_price': price,
            'index_price': price * 0.9999,
            'premium_index': 0.01,
            'basis_rate': 0.03,
            'base_volume_24h': 10000.0,
            'quote_volume_24h': price * 10000.0,
            'max_leverage': 125,
            'long_short_ratio': 1.05,
            'top_trader_sentiment': 52.0,
            'contract_size': 1.0,
            'contract_type': 'perpetual'
        }
