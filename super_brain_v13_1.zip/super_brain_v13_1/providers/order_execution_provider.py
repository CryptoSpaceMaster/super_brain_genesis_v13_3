#!/usr/bin/env python3
"""
Order Execution Provider Interface
Абстрактный базовый класс для исполнения ордеров
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from datetime import datetime
from enum import Enum

class OrderSide(Enum):
    BUY = 'buy'
    SELL = 'sell'

class OrderType(Enum):
    MARKET = 'market'
    LIMIT = 'limit'
    STOP_LOSS = 'stop_loss'
    TAKE_PROFIT = 'take_profit'

class OrderStatus(Enum):
    PENDING = 'pending'
    OPEN = 'open'
    FILLED = 'filled'
    PARTIALLY_FILLED = 'partially_filled'
    CANCELED = 'canceled'
    REJECTED = 'rejected'

class OrderExecutionProvider(ABC):
    """
    Абстрактный интерфейс для исполнения ордеров
    
    Заменяет simulation mode реальным подключением к бирже
    """
    
    @abstractmethod
    async def create_order(self, symbol: str, side: OrderSide, order_type: OrderType,
                          amount: float, price: Optional[float] = None,
                          params: Optional[Dict] = None) -> Dict:
        """
        Создать ордер
        
        Args:
            symbol: Торговая пара (e.g. 'BTC/USDT')
            side: Направление (BUY/SELL)
            order_type: Тип ордера (MARKET/LIMIT/etc)
            amount: Количество
            price: Цена (для LIMIT ордеров)
            params: Дополнительные параметры (stop_loss, take_profit, etc)
        
        Returns:
            {
                'order_id': str,
                'symbol': str,
                'side': str,
                'type': str,
                'amount': float,
                'price': float,
                'status': str,
                'timestamp': datetime,
                'filled': float,
                'remaining': float,
                'cost': float
            }
        """
        pass
    
    @abstractmethod
    async def cancel_order(self, order_id: str, symbol: str) -> Dict:
        """
        Отменить ордер
        
        Returns:
            {
                'order_id': str,
                'symbol': str,
                'status': str,
                'timestamp': datetime
            }
        """
        pass
    
    @abstractmethod
    async def get_order(self, order_id: str, symbol: str) -> Dict:
        """
        Получить информацию об ордере
        
        Returns: Order dict (same format as create_order)
        """
        pass
    
    @abstractmethod
    async def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict]:
        """
        Получить все открытые ордера
        
        Args:
            symbol: Фильтр по символу (optional)
        
        Returns:
            List of open orders
        """
        pass
    
    @abstractmethod
    async def get_balance(self) -> Dict:
        """
        Получить баланс аккаунта
        
        Returns:
            {
                'total': Dict[str, float],  # {'USDT': 5000.0, 'BTC': 0.1}
                'free': Dict[str, float],   # Доступный баланс
                'used': Dict[str, float],   # Заблокированный в ордерах
                'timestamp': datetime
            }
        """
        pass
    
    @abstractmethod
    async def get_positions(self, symbol: Optional[str] = None) -> List[Dict]:
        """
        Получить открытые позиции (для futures/margin)
        
        Returns:
            List of positions:
            [
                {
                    'symbol': str,
                    'side': str,  # 'long' | 'short'
                    'amount': float,
                    'entry_price': float,
                    'current_price': float,
                    'unrealized_pnl': float,
                    'liquidation_price': float,
                    'leverage': float,
                    'margin': float,
                    'timestamp': datetime
                }
            ]
        """
        pass
    
    @abstractmethod
    async def close_position(self, symbol: str, side: str) -> Dict:
        """
        Закрыть позицию
        
        Args:
            symbol: Торговая пара
            side: Сторона позиции ('long' | 'short')
        
        Returns:
            Order dict для closing order
        """
        pass
    
    @abstractmethod
    async def health_check(self) -> Dict:
        """
        Проверка подключения к бирже
        
        Returns:
            {
                'healthy': bool,
                'exchange': str,
                'latency_ms': float,
                'api_limits': Dict,
                'timestamp': datetime
            }
        """
        pass
