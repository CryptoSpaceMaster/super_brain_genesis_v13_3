#!/usr/bin/env python3
"""
CCXT Market Data Provider
Реальный провайдер данных через CCXT library
"""
import ccxt.async_support as ccxt
import pandas as pd
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime
import logging
import asyncio

from .market_data_provider import MarketDataProvider

logger = logging.getLogger(__name__)

class CCXTMarketDataProvider(MarketDataProvider):
    """
    Real market data provider using CCXT
    Подключается к реальным биржам для получения данных
    """
    
    def __init__(self, exchange_id: str = 'binance', config: Optional[Dict] = None):
        """
        Args:
            exchange_id: ID биржи ('binance', 'bybit', 'okx', etc)
            config: Конфигурация (API keys, testnet, etc)
        """
        self.exchange_id = exchange_id
        self.config = config or {}
        
        exchange_class = getattr(ccxt, exchange_id)
        self.exchange = exchange_class({
            'enableRateLimit': True,
            'options': {
                'defaultType': 'future',
            },
            **self.config
        })
        
        self.cache = {}
        self.cache_ttl = 1
        
        logger.info(f"✅ CCXTMarketDataProvider initialized ({exchange_id})")
    
    async def initialize(self):
        """Загрузка рынков"""
        try:
            await self.exchange.load_markets()
            logger.info(f"✅ Loaded {len(self.exchange.markets)} markets from {self.exchange_id}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to initialize {self.exchange_id}: {e}")
            return False
    
    async def get_ticker(self, symbol: str) -> Dict:
        """Получить текущую цену и статистику"""
        try:
            ticker = await self.exchange.fetch_ticker(symbol)
            
            return {
                'symbol': symbol,
                'price': ticker['last'],
                'bid': ticker['bid'],
                'ask': ticker['ask'],
                'volume_24h': ticker['quoteVolume'],
                'high_24h': ticker['high'],
                'low_24h': ticker['low'],
                'change_24h': ticker['percentage'],
                'timestamp': datetime.fromtimestamp(ticker['timestamp'] / 1000)
            }
        except Exception as e:
            logger.error(f"❌ Error fetching ticker for {symbol}: {e}")
            raise
    
    async def get_ohlcv(self, symbol: str, timeframe: str = '1h', 
                        limit: int = 100, since: Optional[datetime] = None) -> pd.DataFrame:
        """Получить OHLCV данные"""
        try:
            since_ms = int(since.timestamp() * 1000) if since else None
            
            ohlcv = await self.exchange.fetch_ohlcv(
                symbol, 
                timeframe=timeframe,
                limit=limit,
                since=since_ms
            )
            
            df = pd.DataFrame(
                ohlcv,
                columns=['timestamp', 'open', 'high', 'low', 'close', 'volume']
            )
            
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            df[['open', 'high', 'low', 'close', 'volume']] = df[['open', 'high', 'low', 'close', 'volume']].astype(float)
            
            logger.debug(f"✅ Fetched {len(df)} OHLCV bars for {symbol} ({timeframe})")
            return df
            
        except Exception as e:
            logger.error(f"❌ Error fetching OHLCV for {symbol}: {e}")
            raise
    
    async def get_orderbook(self, symbol: str, limit: int = 20) -> Dict:
        """Получить стакан ордеров"""
        try:
            orderbook = await self.exchange.fetch_order_book(symbol, limit=limit)
            
            bid_volume = sum([bid[1] for bid in orderbook['bids']])
            ask_volume = sum([ask[1] for ask in orderbook['asks']])
            
            timestamp = orderbook.get('timestamp')
            if timestamp is not None:
                timestamp = datetime.fromtimestamp(timestamp / 1000)
            else:
                timestamp = datetime.now()
            
            return {
                'symbol': symbol,
                'timestamp': timestamp,
                'bids': orderbook['bids'],
                'asks': orderbook['asks'],
                'bid_volume': bid_volume,
                'ask_volume': ask_volume
            }
        except Exception as e:
            logger.error(f"❌ Error fetching orderbook for {symbol}: {e}")
            raise
    
    async def get_recent_trades(self, symbol: str, limit: int = 100) -> List[Dict]:
        """Получить последние сделки"""
        try:
            trades = await self.exchange.fetch_trades(symbol, limit=limit)
            
            return [
                {
                    'timestamp': datetime.fromtimestamp(trade['timestamp'] / 1000),
                    'price': trade['price'],
                    'amount': trade['amount'],
                    'side': trade['side'],
                    'id': trade['id']
                }
                for trade in trades
            ]
        except Exception as e:
            logger.error(f"❌ Error fetching trades for {symbol}: {e}")
            raise
    
    async def get_funding_rate(self, symbol: str) -> Dict:
        """Получить funding rate"""
        try:
            funding_rate = await self.exchange.fetch_funding_rate(symbol)
            
            return {
                'symbol': symbol,
                'funding_rate': funding_rate['fundingRate'],
                'next_funding_time': datetime.fromtimestamp(
                    funding_rate['fundingTimestamp'] / 1000
                ) if 'fundingTimestamp' in funding_rate else None,
                'timestamp': datetime.fromtimestamp(funding_rate['timestamp'] / 1000)
            }
        except Exception as e:
            logger.error(f"❌ Error fetching funding rate for {symbol}: {e}")
            return {
                'symbol': symbol,
                'funding_rate': 0.0001,
                'next_funding_time': None,
                'timestamp': datetime.now()
            }
    
    async def get_open_interest(self, symbol: str) -> Dict:
        """Получить открытый интерес"""
        try:
            if hasattr(self.exchange, 'fetch_open_interest'):
                oi = await self.exchange.fetch_open_interest(symbol)
                
                return {
                    'symbol': symbol,
                    'open_interest': oi.get('openInterestAmount', 0),
                    'timestamp': datetime.fromtimestamp(oi['timestamp'] / 1000)
                }
            else:
                return {
                    'symbol': symbol,
                    'open_interest': 0.0,
                    'timestamp': datetime.now()
                }
        except Exception as e:
            logger.warning(f"⚠️ Open interest not available for {symbol}: {e}")
            return {
                'symbol': symbol,
                'open_interest': 0.0,
                'timestamp': datetime.now()
            }
    
    async def health_check(self) -> Dict:
        """Проверка доступности биржи"""
        try:
            start_time = asyncio.get_event_loop().time()
            
            await self.exchange.fetch_time()
            
            latency = (asyncio.get_event_loop().time() - start_time) * 1000
            
            return {
                'healthy': True,
                'latency_ms': round(latency, 2),
                'provider': f'CCXT-{self.exchange_id}',
                'timestamp': datetime.now()
            }
        except Exception as e:
            logger.error(f"❌ Health check failed for {self.exchange_id}: {e}")
            return {
                'healthy': False,
                'latency_ms': -1,
                'provider': f'CCXT-{self.exchange_id}',
                'timestamp': datetime.now(),
                'error': str(e)
            }
    
    async def close(self):
        """Закрыть соединение с биржей"""
        await self.exchange.close()
        logger.info(f"✅ Closed connection to {self.exchange_id}")
