"""
CryptoQuant Data Provider - Провайдер для получения ончейн метрик
Источник: PostgreSQL таблицы, заполняемые через n8n workflow CryptoQuant API

Поддерживаемые метрики:
1. Exchange Netflow - потоки на/с бирж
2. Whale Ratio - доля крупных холдеров
3. SOPR - Spent Output Profit Ratio
4. MVRV - Market Value to Realized Value
5. Fear & Greed Index
6. Active Addresses
7. Hash Rate
8. Mining Revenue
9. Supply metrics (Circulating, Total)
10. Reserve Risk
"""

import logging
import psycopg2
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import os

logger = logging.getLogger(__name__)


class CryptoQuantDataProvider:
    """
    CryptoQuant Data Provider - провайдер ончейн метрик
    
    Подключается к PostgreSQL и извлекает данные из таблиц,
    заполняемых CryptoQuant n8n workflow.
    """
    
    def __init__(
        self,
        config: Dict = None,
        host: str = None,
        database: str = None,
        user: str = None,
        password: str = None,
        port: int = None,
        simulation_mode: bool = False
    ):
        """
        Args:
            config: Config dict (если передан, параметры берутся из него)
            host: Хост PostgreSQL
            database: Имя базы данных
            user: Пользователь
            password: Пароль
            port: Порт
            simulation_mode: Режим симуляции
        """
        if isinstance(config, dict):
            self.simulation_mode = config.get('simulation_mode', False)
            self.host = config.get('host', os.getenv('DB_HOST', 'db'))
            self.database = config.get('database', os.getenv('DB_NAME', 'postgres'))
            self.user = config.get('user', os.getenv('DB_USER', 'postgres'))
            self.password = config.get('password', os.getenv('DB_PASS', ''))
            self.port = config.get('port', int(os.getenv('DB_PORT', '5432')))
        else:
            self.simulation_mode = simulation_mode
            self.host = host or os.getenv('DB_HOST', 'db')
            self.database = database or os.getenv('DB_NAME', 'postgres')
            self.user = user or os.getenv('DB_USER', 'postgres')
            self.password = password or os.getenv('DB_PASS', '')
            self.port = port or int(os.getenv('DB_PORT', '5432'))
        
        self.connection = None
        
        logger.info("🔗 CryptoQuant Data Provider initialized")
        logger.info(f"   Mode: {'SIMULATION' if simulation_mode else 'PRODUCTION'}")
    
    def connect(self) -> bool:
        """Подключение к PostgreSQL"""
        if self.simulation_mode:
            logger.info("📦 Simulation mode - skipping connection")
            return True
        
        try:
            if self.connection and not self.connection.closed:
                return True
            
            self.connection = psycopg2.connect(
                host=self.host,
                database=self.database,
                user=self.user,
                password=self.password,
                port=self.port
            )
            
            logger.info("✅ CryptoQuant PostgreSQL connected")
            return True
            
        except Exception as e:
            logger.error(f"❌ CryptoQuant connection failed: {e}")
            self.connection = None
            return False
    
    def disconnect(self):
        """Закрытие соединения"""
        if self.connection and not self.connection.closed:
            self.connection.close()
            logger.info("🔌 CryptoQuant disconnected")
    
    def execute_query(self, query: str, params: tuple = None) -> Optional[List[tuple]]:
        """Выполнение SQL запроса"""
        if self.simulation_mode:
            logger.debug(f"📦 Simulation mode - query skipped")
            return []
        
        try:
            if not self.connect():
                return None
            
            cursor = self.connection.cursor()
            cursor.execute(query, params or ())
            results = cursor.fetchall()
            cursor.close()
            
            return results
            
        except Exception as e:
            logger.error(f"❌ CryptoQuant query failed: {e}")
            return None
    
    def get_exchange_netflow(self, asset: str = 'BTC', hours: int = 24) -> Optional[float]:
        """
        Exchange Netflow - чистый поток на биржи
        
        Положительное значение = приток (bearish)
        Отрицательное значение = отток (bullish)
        
        Args:
            asset: Актив (BTC, ETH)
            hours: За сколько часов агрегировать
            
        Returns:
            Netflow в единицах актива
        """
        if self.simulation_mode:
            return -250.5
        
        query = """
            SELECT 
                SUM(inflow - outflow) as netflow
            FROM cryptoquant_exchange_flows
            WHERE asset = %s
              AND timestamp > NOW() - INTERVAL '%s hours'
        """
        
        try:
            results = self.execute_query(query, (asset, hours))
            
            if results and results[0] and results[0][0]:
                netflow = float(results[0][0])
                logger.info(f"✅ Exchange Netflow [{asset}]: {netflow:.2f}")
                return netflow
            else:
                logger.warning(f"⚠️  No netflow data for {asset}")
                return 0.0
                
        except Exception as e:
            logger.error(f"❌ Failed to get netflow: {e}")
            return None
    
    def get_whale_ratio(self, asset: str = 'BTC') -> Optional[float]:
        """
        Whale Ratio - доля крупных холдеров (>100 BTC)
        
        Высокое значение = киты накапливают (bullish)
        Низкое значение = киты распродают (bearish)
        
        Args:
            asset: Актив
            
        Returns:
            Whale ratio (0.0 - 1.0)
        """
        if self.simulation_mode:
            return 0.78
        
        query = """
            SELECT whale_ratio
            FROM cryptoquant_whale_metrics
            WHERE asset = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (asset,))
            
            if results and results[0] and results[0][0]:
                ratio = float(results[0][0])
                logger.info(f"✅ Whale Ratio [{asset}]: {ratio:.4f}")
                return ratio
            else:
                logger.warning(f"⚠️  No whale ratio data for {asset}")
                return 0.5
                
        except Exception as e:
            logger.error(f"❌ Failed to get whale ratio: {e}")
            return None
    
    def get_sopr(self, asset: str = 'BTC') -> Optional[float]:
        """
        SOPR - Spent Output Profit Ratio
        
        > 1.0 = монеты продаются в прибыли (может быть вершина)
        < 1.0 = монеты продаются в убытке (может быть дно)
        
        Args:
            asset: Актив
            
        Returns:
            SOPR значение
        """
        if self.simulation_mode:
            return 1.05
        
        query = """
            SELECT sopr
            FROM cryptoquant_sopr
            WHERE asset = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (asset,))
            
            if results and results[0] and results[0][0]:
                sopr = float(results[0][0])
                logger.info(f"✅ SOPR [{asset}]: {sopr:.4f}")
                return sopr
            else:
                logger.warning(f"⚠️  No SOPR data for {asset}")
                return 1.0
                
        except Exception as e:
            logger.error(f"❌ Failed to get SOPR: {e}")
            return None
    
    def get_mvrv(self, asset: str = 'BTC') -> Optional[float]:
        """
        MVRV - Market Value to Realized Value
        
        > 3.0 = перекупленность, потенциальная вершина
        < 1.0 = перепроданность, потенциальное дно
        
        Args:
            asset: Актив
            
        Returns:
            MVRV ratio
        """
        if self.simulation_mode:
            return 1.85
        
        query = """
            SELECT mvrv_ratio
            FROM cryptoquant_mvrv
            WHERE asset = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (asset,))
            
            if results and results[0] and results[0][0]:
                mvrv = float(results[0][0])
                logger.info(f"✅ MVRV [{asset}]: {mvrv:.4f}")
                return mvrv
            else:
                logger.warning(f"⚠️  No MVRV data for {asset}")
                return 1.5
                
        except Exception as e:
            logger.error(f"❌ Failed to get MVRV: {e}")
            return None
    
    def get_fear_greed_index(self) -> Optional[int]:
        """
        Fear & Greed Index - индекс страха и жадности
        
        0-25: Extreme Fear (покупай)
        25-45: Fear
        45-55: Neutral
        55-75: Greed
        75-100: Extreme Greed (продавай)
        
        Returns:
            Index value (0-100)
        """
        if self.simulation_mode:
            return 58
        
        query = """
            SELECT index_value
            FROM cryptoquant_fear_greed
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query)
            
            if results and results[0] and results[0][0]:
                index = int(results[0][0])
                logger.info(f"✅ Fear & Greed Index: {index}")
                return index
            else:
                logger.warning(f"⚠️  No Fear & Greed data")
                return 50
                
        except Exception as e:
            logger.error(f"❌ Failed to get Fear & Greed: {e}")
            return None
    
    def get_active_addresses(self, asset: str = 'BTC', period: str = '24h') -> Optional[int]:
        """
        Active Addresses - количество активных адресов
        
        Рост = увеличение сетевой активности (bullish)
        Падение = снижение активности (bearish)
        
        Args:
            asset: Актив
            period: Период агрегации (24h, 7d, 30d)
            
        Returns:
            Количество активных адресов
        """
        if self.simulation_mode:
            return 850000
        
        query = """
            SELECT active_addresses
            FROM cryptoquant_network_activity
            WHERE asset = %s AND period = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (asset, period))
            
            if results and results[0] and results[0][0]:
                addresses = int(results[0][0])
                logger.info(f"✅ Active Addresses [{asset}]: {addresses:,}")
                return addresses
            else:
                logger.warning(f"⚠️  No active addresses data for {asset}")
                return 500000
                
        except Exception as e:
            logger.error(f"❌ Failed to get active addresses: {e}")
            return None
    
    def get_hashrate(self, asset: str = 'BTC') -> Optional[float]:
        """
        Hash Rate - вычислительная мощность сети
        
        Рост = укрепление сети (bullish)
        Падение = ослабление безопасности (bearish)
        
        Args:
            asset: Актив
            
        Returns:
            Hashrate в EH/s
        """
        if self.simulation_mode:
            return 450.5
        
        query = """
            SELECT hashrate
            FROM cryptoquant_mining
            WHERE asset = %s
            ORDER BY timestamp DESC
            LIMIT 1
        """
        
        try:
            results = self.execute_query(query, (asset,))
            
            if results and results[0] and results[0][0]:
                hashrate = float(results[0][0])
                logger.info(f"✅ Hashrate [{asset}]: {hashrate:.2f} EH/s")
                return hashrate
            else:
                logger.warning(f"⚠️  No hashrate data for {asset}")
                return 400.0
                
        except Exception as e:
            logger.error(f"❌ Failed to get hashrate: {e}")
            return None
    
    def get_all_onchain_metrics(self, asset: str = 'BTC') -> Dict:
        """
        Получение ВСЕХ ончейн метрик для актива
        
        Args:
            asset: Актив (BTC, ETH)
            
        Returns:
            Dict со всеми метриками:
            - exchange_netflow
            - whale_ratio
            - sopr
            - mvrv
            - fear_greed_index
            - active_addresses
            - hashrate
        """
        logger.info(f"🔗 Loading ALL onchain metrics for {asset}")
        
        metrics = {
            'asset': asset,
            'timestamp': datetime.now().isoformat(),
            'exchange_netflow': self.get_exchange_netflow(asset),
            'whale_ratio': self.get_whale_ratio(asset),
            'sopr': self.get_sopr(asset),
            'mvrv': self.get_mvrv(asset),
            'fear_greed_index': self.get_fear_greed_index(),
            'active_addresses': self.get_active_addresses(asset),
            'hashrate': self.get_hashrate(asset)
        }
        
        logger.info(f"✅ ALL onchain metrics loaded for {asset}")
        return metrics
    
    def calculate_lpi_onchain_component(self, asset: str = 'BTC') -> Dict:
        """
        Расчет ончейн компонента для LPI v2.0 (C3: Киты и CryptoQuant)
        
        Формула C3 (40%):
        - Whale Ratio (20%)
        - Exchange Netflow (10%)
        - SOPR (5%)
        - MVRV (5%)
        
        Args:
            asset: Актив
            
        Returns:
            Dict с компонентами LPI:
            - whale_score: 0-100
            - netflow_score: 0-100
            - sopr_score: 0-100
            - mvrv_score: 0-100
            - c3_total: 0-100 (взвешенная сумма)
        """
        logger.info(f"📊 Calculating LPI onchain component for {asset}")
        
        whale_ratio = self.get_whale_ratio(asset) or 0.5
        netflow = self.get_exchange_netflow(asset) or 0.0
        sopr = self.get_sopr(asset) or 1.0
        mvrv = self.get_mvrv(asset) or 1.5
        
        whale_score = min(100, max(0, whale_ratio * 100))
        
        if netflow < 0:
            netflow_score = min(100, max(0, 50 + abs(netflow) / 10))
        else:
            netflow_score = max(0, 50 - netflow / 10)
        
        if sopr > 1.0:
            sopr_score = min(100, 50 + (sopr - 1.0) * 100)
        else:
            sopr_score = max(0, 50 - (1.0 - sopr) * 100)
        
        if mvrv < 1.0:
            mvrv_score = min(100, 50 + (1.0 - mvrv) * 100)
        elif mvrv > 3.0:
            mvrv_score = max(0, 50 - (mvrv - 3.0) * 20)
        else:
            mvrv_score = 50 + (mvrv - 2.0) * 10
        
        c3_total = (
            whale_score * 0.20 +
            netflow_score * 0.10 +
            sopr_score * 0.05 +
            mvrv_score * 0.05
        )
        
        result = {
            'whale_ratio': whale_ratio,
            'whale_score': round(whale_score, 2),
            'exchange_netflow': netflow,
            'netflow_score': round(netflow_score, 2),
            'sopr': sopr,
            'sopr_score': round(sopr_score, 2),
            'mvrv': mvrv,
            'mvrv_score': round(mvrv_score, 2),
            'c3_total': round(c3_total, 2)
        }
        
        logger.info(f"✅ LPI C3 calculated: {result['c3_total']:.2f}")
        logger.info(f"   Whale: {result['whale_score']:.1f}, Netflow: {result['netflow_score']:.1f}")
        logger.info(f"   SOPR: {result['sopr_score']:.1f}, MVRV: {result['mvrv_score']:.1f}")
        
        return result
