"""
Market Data Collector - Центральный агрегатор ВСЕХ рыночных и ончейн данных
Объединяет:
1. PostgreSQLDataProvider - OHLCV, Trades (CVD), OrderBook (OBI), Tickers, Funding
2. CryptoQuantDataProvider - Ончейн метрики (netflow, whale_ratio, sopr, mvrv, etc)

Предоставляет единый интерфейс для всех модулей системы СУПЕР МОЗГ.
NO MORE STUBS - только реальные данные из PostgreSQL.
"""

import logging
from typing import Dict, List, Optional
from datetime import datetime

from .postgresql_data_provider import PostgreSQLDataProvider
from .cryptoquant_data_provider import CryptoQuantDataProvider

logger = logging.getLogger(__name__)


class MarketDataCollector:
    """
    Market Data Collector - единый интерфейс для всех данных
    
    Архитектура:
    - PostgreSQL: рыночные данные в реальном времени
    - CryptoQuant: ончейн метрики через PostgreSQL
    - Кэширование: минимизация запросов к БД
    - Fallback: graceful degradation при недоступности данных
    """
    
    def __init__(
        self,
        config: Dict = None,
        exchange: str = None,
        simulation_mode: bool = None,
        cache_ttl: int = None
    ):
        """
        Args:
            config: Config dict (если передан, параметры берутся из него)
            exchange: Основная биржа для данных
            simulation_mode: Режим симуляции (без реальной БД)
            cache_ttl: TTL кэша в секундах
        """
        if isinstance(config, dict):
            providers_cfg = config.get('providers', {})
            trading_cfg = config.get('trading', {})
            db_cfg = config.get('database', {})
            
            self.exchange = providers_cfg.get('exchange_id', 'binance')
            self.simulation_mode = providers_cfg.get('simulation_mode', False)
            self.cache_ttl = providers_cfg.get('cache_ttl', 60)
            
            db_cfg_with_sim = {**db_cfg, 'simulation_mode': self.simulation_mode}
            logger.debug(f"📋 Creating providers with config: simulation_mode={self.simulation_mode}, db_cfg_with_sim={db_cfg_with_sim}")
            
            self.postgres_provider = PostgreSQLDataProvider(db_cfg_with_sim)
            self.cryptoquant_provider = CryptoQuantDataProvider(db_cfg_with_sim)
        else:
            self.exchange = exchange or 'binance'
            self.simulation_mode = simulation_mode if simulation_mode is not None else False
            self.cache_ttl = cache_ttl or 60
            
            self.postgres_provider = PostgreSQLDataProvider(simulation_mode=self.simulation_mode)
            self.cryptoquant_provider = CryptoQuantDataProvider(simulation_mode=self.simulation_mode)
        
        self._cache = {}
        self._cache_timestamps = {}
        
        logger.info("📡 Market Data Collector initialized")
        logger.info(f"   Exchange: {self.exchange}")
        logger.info(f"   Mode: {'SIMULATION' if self.simulation_mode else 'PRODUCTION'}")
        logger.info(f"   Cache TTL: {self.cache_ttl}s")
    
    def _is_cache_valid(self, key: str) -> bool:
        """Проверка валидности кэша"""
        if key not in self._cache_timestamps:
            return False
        
        age = (datetime.now() - self._cache_timestamps[key]).total_seconds()
        return age < self.cache_ttl
    
    def _get_from_cache(self, key: str) -> Optional[any]:
        """Получение из кэша"""
        if self._is_cache_valid(key):
            logger.debug(f"📦 Cache HIT: {key}")
            return self._cache.get(key)
        return None
    
    def _store_in_cache(self, key: str, value: any):
        """Сохранение в кэш"""
        self._cache[key] = value
        self._cache_timestamps[key] = datetime.now()
        logger.debug(f"💾 Cache STORE: {key}")
    
    def get_market_snapshot(
        self,
        symbol: str,
        timeframe: str = '1h',
        ohlcv_limit: int = 100,
        use_cache: bool = True
    ) -> Dict:
        """
        Получение ПОЛНОГО рыночного снапшота для символа
        
        Включает ВСЕ типы данных:
        - OHLCV: свечи для индикаторов
        - Trades: CVD метрики
        - OrderBook: OBI метрики
        - Ticker: актуальные цены
        - Funding: derivatives данные
        - CryptoQuant: ончейн метрики
        
        Args:
            symbol: Символ (BTC/USDT)
            timeframe: Таймфрейм
            ohlcv_limit: Количество свечей
            use_cache: Использовать кэш
            
        Returns:
            Dict с ВСЕМИ рыночными данными
        """
        cache_key = f"snapshot_{symbol}_{timeframe}_{ohlcv_limit}"
        
        if use_cache:
            cached = self._get_from_cache(cache_key)
            if cached:
                return cached
        
        logger.info("="*80)
        logger.info(f"📡 COLLECTING FULL MARKET SNAPSHOT: {symbol}")
        logger.info("="*80)
        
        asset = symbol.split('/')[0] if '/' in symbol else 'BTC'
        
        snapshot = {
            'symbol': symbol,
            'exchange': self.exchange,
            'timeframe': timeframe,
            'timestamp': datetime.now().isoformat(),
            'simulation_mode': self.simulation_mode,
            
            'ohlcv': None,
            'trades': None,
            'orderbook': None,
            'ticker': None,
            'funding': None,
            'cryptoquant': None,
            
            'status': {
                'ohlcv': 'PENDING',
                'trades': 'PENDING',
                'orderbook': 'PENDING',
                'ticker': 'PENDING',
                'funding': 'PENDING',
                'cryptoquant': 'PENDING'
            }
        }
        
        try:
            snapshot['ohlcv'] = self.postgres_provider.get_ohlcv_data(
                self.exchange, symbol, timeframe, ohlcv_limit
            )
            snapshot['status']['ohlcv'] = 'OK' if snapshot['ohlcv'] is not None else 'FAILED'
        except Exception as e:
            logger.error(f"❌ OHLCV collection failed: {e}")
            snapshot['status']['ohlcv'] = 'ERROR'
        
        try:
            snapshot['trades'] = self.postgres_provider.get_trades_data(
                self.exchange, symbol
            )
            snapshot['status']['trades'] = 'OK' if snapshot['trades'] else 'FAILED'
        except Exception as e:
            logger.error(f"❌ Trades collection failed: {e}")
            snapshot['status']['trades'] = 'ERROR'
        
        try:
            snapshot['orderbook'] = self.postgres_provider.get_orderbook_data(
                self.exchange, symbol
            )
            snapshot['status']['orderbook'] = 'OK' if snapshot['orderbook'] else 'FAILED'
        except Exception as e:
            logger.error(f"❌ OrderBook collection failed: {e}")
            snapshot['status']['orderbook'] = 'ERROR'
        
        try:
            snapshot['ticker'] = self.postgres_provider.get_ticker_data(
                self.exchange, symbol
            )
            snapshot['status']['ticker'] = 'OK' if snapshot['ticker'] else 'FAILED'
        except Exception as e:
            logger.error(f"❌ Ticker collection failed: {e}")
            snapshot['status']['ticker'] = 'ERROR'
        
        try:
            futures_symbol = symbol.replace('/USDT', '/USDT:USDT')
            snapshot['funding'] = self.postgres_provider.get_funding_data(
                self.exchange, futures_symbol
            )
            snapshot['status']['funding'] = 'OK' if snapshot['funding'] else 'FAILED'
        except Exception as e:
            logger.error(f"❌ Funding collection failed: {e}")
            snapshot['status']['funding'] = 'ERROR'
        
        try:
            snapshot['cryptoquant'] = self.cryptoquant_provider.get_all_onchain_metrics(asset)
            snapshot['status']['cryptoquant'] = 'OK' if snapshot['cryptoquant'] else 'FAILED'
        except Exception as e:
            logger.error(f"❌ CryptoQuant collection failed: {e}")
            snapshot['status']['cryptoquant'] = 'ERROR'
        
        logger.info("="*80)
        logger.info("📊 MARKET SNAPSHOT COLLECTION RESULTS")
        logger.info("="*80)
        for data_type, status in snapshot['status'].items():
            icon = "✅" if status == "OK" else "❌"
            logger.info(f"{icon} {data_type.upper()}: {status}")
        logger.info("="*80)
        
        if use_cache:
            self._store_in_cache(cache_key, snapshot)
        
        return snapshot
    
    def get_lpi_data(self, symbol: str) -> Dict:
        """
        Получение данных для расчета LPI v2.0
        
        LPI v2.0 компоненты:
        - C1 (30%): Структурный - OHLCV, RSI, ATR
        - C2 (30%): Риск - Funding Rate, Open Interest, Premium
        - C3 (20%): Киты - Whale Ratio, Exchange Netflow
        - C4 (20%): Микроструктура - CVD, OBI
        
        Args:
            symbol: Символ
            
        Returns:
            Dict с данными для всех компонентов LPI
        """
        logger.info(f"📊 Collecting LPI data for {symbol}")
        
        asset = symbol.split('/')[0] if '/' in symbol else 'BTC'
        
        lpi_data = {
            'symbol': symbol,
            'timestamp': datetime.now().isoformat(),
            
            'c1_structural': {},
            'c2_risk': {},
            'c3_whales': {},
            'c4_microstructure': {}
        }
        
        try:
            ohlcv = self.postgres_provider.get_ohlcv_data(
                self.exchange, symbol, '1h', 100
            )
            lpi_data['c1_structural']['ohlcv'] = ohlcv
            lpi_data['c1_structural']['status'] = 'OK' if ohlcv else 'FAILED'
        except Exception as e:
            logger.error(f"❌ C1 OHLCV failed: {e}")
            lpi_data['c1_structural']['status'] = 'ERROR'
        
        try:
            futures_symbol = symbol.replace('/USDT', '/USDT:USDT')
            funding = self.postgres_provider.get_funding_data(
                self.exchange, futures_symbol
            )
            lpi_data['c2_risk']['funding'] = funding
            lpi_data['c2_risk']['status'] = 'OK' if funding else 'FAILED'
        except Exception as e:
            logger.error(f"❌ C2 Funding failed: {e}")
            lpi_data['c2_risk']['status'] = 'ERROR'
        
        try:
            cryptoquant = self.cryptoquant_provider.calculate_lpi_onchain_component(asset)
            lpi_data['c3_whales']['cryptoquant'] = cryptoquant
            lpi_data['c3_whales']['status'] = 'OK' if cryptoquant else 'FAILED'
        except Exception as e:
            logger.error(f"❌ C3 CryptoQuant failed: {e}")
            lpi_data['c3_whales']['status'] = 'ERROR'
        
        try:
            trades = self.postgres_provider.get_trades_data(self.exchange, symbol)
            orderbook = self.postgres_provider.get_orderbook_data(self.exchange, symbol)
            lpi_data['c4_microstructure']['cvd'] = trades
            lpi_data['c4_microstructure']['obi'] = orderbook
            lpi_data['c4_microstructure']['status'] = 'OK' if (trades and orderbook) else 'PARTIAL'
        except Exception as e:
            logger.error(f"❌ C4 Microstructure failed: {e}")
            lpi_data['c4_microstructure']['status'] = 'ERROR'
        
        logger.info(f"✅ LPI data collected for {symbol}")
        logger.info(f"   C1 Structural: {lpi_data['c1_structural']['status']}")
        logger.info(f"   C2 Risk: {lpi_data['c2_risk']['status']}")
        logger.info(f"   C3 Whales: {lpi_data['c3_whales']['status']}")
        logger.info(f"   C4 Microstructure: {lpi_data['c4_microstructure']['status']}")
        
        return lpi_data
    
    def get_truth_engine_data(self, symbol: str) -> Dict:
        """
        Получение данных для TRUTH ENGINE v2.0
        
        TRUTH ENGINE требует:
        - OHLCV: для индикаторов
        - LPI: для оценки ликвидности
        - Funding: для derivatives анализа
        - Volume: для объемного анализа
        
        Args:
            symbol: Символ
            
        Returns:
            Dict с данными для TRUTH ENGINE
        """
        logger.info(f"🎯 Collecting TRUTH ENGINE data for {symbol}")
        
        truth_data = {
            'symbol': symbol,
            'timestamp': datetime.now().isoformat(),
            'ohlcv': None,
            'lpi': None,
            'funding': None,
            'trades': None,
            'orderbook': None
        }
        
        try:
            truth_data['ohlcv'] = self.postgres_provider.get_ohlcv_data(
                self.exchange, symbol, '1h', 100
            )
        except Exception as e:
            logger.error(f"❌ TRUTH OHLCV failed: {e}")
        
        try:
            truth_data['lpi'] = self.get_lpi_data(symbol)
        except Exception as e:
            logger.error(f"❌ TRUTH LPI failed: {e}")
        
        try:
            futures_symbol = symbol.replace('/USDT', '/USDT:USDT')
            truth_data['funding'] = self.postgres_provider.get_funding_data(
                self.exchange, futures_symbol
            )
        except Exception as e:
            logger.error(f"❌ TRUTH Funding failed: {e}")
        
        try:
            truth_data['trades'] = self.postgres_provider.get_trades_data(
                self.exchange, symbol
            )
        except Exception as e:
            logger.error(f"❌ TRUTH Trades failed: {e}")
        
        try:
            truth_data['orderbook'] = self.postgres_provider.get_orderbook_data(
                self.exchange, symbol
            )
        except Exception as e:
            logger.error(f"❌ TRUTH OrderBook failed: {e}")
        
        logger.info(f"✅ TRUTH ENGINE data collected for {symbol}")
        return truth_data
    
    def disconnect(self):
        """Закрытие всех соединений"""
        logger.info("🔌 Disconnecting all data providers")
        self.postgres_provider.disconnect()
        self.cryptoquant_provider.disconnect()
        logger.info("✅ All providers disconnected")
    
    def __enter__(self):
        """Context manager entry"""
        self.postgres_provider.connect()
        self.cryptoquant_provider.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.disconnect()
