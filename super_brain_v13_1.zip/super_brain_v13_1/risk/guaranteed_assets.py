#!/usr/bin/env python3
"""
GUARANTEED ASSETS - Управление гарантированными активами
ТОЧНО ПО ЭНЦИКЛОПЕДИИ
"""
import logging
from typing import Dict, List
from datetime import datetime

logger = logging.getLogger(__name__)

class GuaranteedAssets:
    """
    GUARANTEED ASSETS - Система защищенных активов
    
    Функции:
    - Резервирование части капитала
    - Защита от полного слива
    - Управление безопасным капиталом
    - Автоматическое восстановление
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        
        # Процент гарантированного капитала
        self.guaranteed_percentage = 0.3  # 30% защищено
        
        self.guaranteed_vault = {}
        self.withdrawal_history = []
        
        logger.info("GUARANTEED ASSETS initialized")
    
    def initialize_vault(self, symbol: str, total_capital: float) -> Dict:
        """
        Инициализация хранилища гарантированных активов
        
        Args:
            symbol: Символ актива
            total_capital: Общий капитал
        """
        
        guaranteed_amount = total_capital * self.guaranteed_percentage
        tradable_amount = total_capital - guaranteed_amount
        
        self.guaranteed_vault[symbol] = {
            'total_capital': total_capital,
            'guaranteed_amount': guaranteed_amount,
            'tradable_amount': tradable_amount,
            'guaranteed_percentage': self.guaranteed_percentage,
            'created_at': datetime.now().isoformat(),
            'last_update': datetime.now().isoformat()
        }
        
        logger.info(f"✅ Vault initialized for {symbol}: "
                   f"${guaranteed_amount:.2f} guaranteed, "
                   f"${tradable_amount:.2f} tradable")
        
        return self.guaranteed_vault[symbol]
    
    def check_drawdown_limit(self, symbol: str, current_balance: float) -> Dict:
        """
        Проверка предела просадки
        
        Args:
            symbol: Символ актива
            current_balance: Текущий баланс
        """
        
        if symbol not in self.guaranteed_vault:
            return {'error': 'Vault not initialized'}
        
        vault = self.guaranteed_vault[symbol]
        guaranteed_amount = vault['guaranteed_amount']
        
        # Проверка: не упал ли баланс ниже гарантированного порога
        if current_balance < guaranteed_amount:
            return {
                'status': 'CRITICAL_DRAWDOWN',
                'current_balance': current_balance,
                'guaranteed_amount': guaranteed_amount,
                'deficit': guaranteed_amount - current_balance,
                'action': 'STOP_TRADING'
            }
        
        # Расчет оставшегося торгового капитала
        tradable_remaining = current_balance - guaranteed_amount
        
        return {
            'status': 'OK',
            'current_balance': current_balance,
            'guaranteed_amount': guaranteed_amount,
            'tradable_remaining': tradable_remaining,
            'action': 'CONTINUE_TRADING'
        }
    
    def emergency_withdrawal(self, symbol: str, reason: str) -> Dict:
        """
        Экстренное снятие средств в защищенное хранилище
        
        Args:
            symbol: Символ актива
            reason: Причина снятия
        """
        
        if symbol not in self.guaranteed_vault:
            return {'error': 'Vault not initialized'}
        
        vault = self.guaranteed_vault[symbol]
        
        withdrawal = {
            'symbol': symbol,
            'guaranteed_amount': vault['guaranteed_amount'],
            'reason': reason,
            'timestamp': datetime.now().isoformat()
        }
        
        self.withdrawal_history.append(withdrawal)
        
        logger.warning(f"⚠️ Emergency withdrawal: {symbol}, ${vault['guaranteed_amount']:.2f}, reason: {reason}")
        
        return withdrawal
    
    def get_vault_status(self, symbol: str) -> Dict:
        """Статус хранилища"""
        
        if symbol not in self.guaranteed_vault:
            return {'error': 'Vault not initialized'}
        
        return self.guaranteed_vault[symbol]
    
    def get_all_vaults(self) -> Dict:
        """Все хранилища"""
        return self.guaranteed_vault

if __name__ == "__main__":
    print("✅ GUARANTEED ASSETS создан")
