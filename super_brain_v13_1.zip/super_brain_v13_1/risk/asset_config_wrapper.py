#!/usr/bin/env python3
"""
Asset Config Wrapper - Безопасное управление параметрами активов
ПОЛНАЯ ИНТЕГРАЦИЯ С SimpleMarginCalculator (БЕЗ ЗАГЛУШЕК)
"""
import json
import logging
from typing import Dict, Any, Optional
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class SafeAssetConfigWrapper:
    """
    Безопасная обертка для управления параметрами активов.
    Интегрирована с SimpleMarginCalculator для получения allocation.
    НЕТ HARDCODED ЗАГЛУШЕК!
    """
    
    def __init__(self, fallback_capital: float = 200, fallback_leverage: float = 5,
                 margin_calculator=None):
        self.fallback_capital = fallback_capital
        self.fallback_leverage = fallback_leverage
        self.margin_calculator = margin_calculator  # SimpleMarginCalculator для allocation
        
        self.configs = self._safe_load_configs()
        self.validation_passed = self._validate_all_configs()
        self._log_initialization_status()
    
    def _safe_load_configs(self) -> Dict:
        """
        БЕЗОПАСНАЯ загрузка конфигурации БЕЗ HARDCODED заглушек
        Приоритет: ENV vars > JSON file > SimpleMarginCalculator
        """
        configs = {}
        
        # Попытка 1: Environment variables (highest priority)
        try:
            btc_capital = os.getenv('BTC_CAPITAL', None)
            if btc_capital:
                configs['BTC'] = {
                    'capital': float(btc_capital),
                    'leverage': float(os.getenv('BTC_LEVERAGE', '10'))
                }
                
            eth_capital = os.getenv('ETH_CAPITAL', None)
            if eth_capital:
                configs['ETH'] = {
                    'capital': float(eth_capital),
                    'leverage': float(os.getenv('ETH_LEVERAGE', '7'))
                }
                
            sol_capital = os.getenv('SOL_CAPITAL', None)
            if sol_capital:
                configs['SOL'] = {
                    'capital': float(sol_capital),
                    'leverage': float(os.getenv('SOL_LEVERAGE', '7'))
                }
            
            if configs:
                logger.info("✅ Loaded configs from environment variables")
                return configs
                
        except Exception as e:
            logger.warning(f"Failed to load from env vars: {e}")
        
        # Попытка 2: JSON file
        try:
            config_file = 'config/asset_configs.json'
            if os.path.exists(config_file):
                with open(config_file, 'r') as f:
                    configs = json.load(f)
                logger.info(f"✅ Loaded configs from {config_file}")
                return configs
        except Exception as e:
            logger.warning(f"Failed to load from JSON: {e}")
        
        # Попытка 3: Использовать SimpleMarginCalculator если доступен
        if self.margin_calculator:
            try:
                logger.info("✅ Using SimpleMarginCalculator for allocation")
                # SimpleMarginCalculator уже имеет правильные allocation и leverage
                # Не создаем hardcoded defaults!
                return {}
            except Exception as e:
                logger.warning(f"Failed to use SimpleMarginCalculator: {e}")
        
        # Если ничего не сработало - пустой конфиг, будем использовать SimpleMarginCalculator в runtime
        logger.warning("⚠️ No configs loaded, will use SimpleMarginCalculator in runtime")
        return {}
    
    def _validate_all_configs(self) -> bool:
        """Валидация ВСЕХ параметров"""
        all_valid = True
        
        for symbol, config in self.configs.items():
            if config.get('capital', 0) <= 0:
                logger.warning(f"⚠️ Invalid capital for {symbol}, using fallback")
                config['capital'] = self.fallback_capital
                all_valid = False
            
            leverage = config.get('leverage', 0)
            if leverage <= 0 or leverage > 20:
                logger.warning(f"⚠️ Invalid leverage for {symbol}, using fallback")
                config['leverage'] = self.fallback_leverage
                all_valid = False
            
            config['validated'] = True
            
        return all_valid
    
    def _log_initialization_status(self):
        """Логирование статуса инициализации"""
        logger.info("=" * 60)
        logger.info("SAFE ASSET CONFIG WRAPPER - INITIALIZATION STATUS")
        logger.info("=" * 60)
        
        if self.validation_passed:
            logger.info("✅ All configurations validated successfully")
        else:
            logger.info("⚠️ Some configurations were auto-corrected")
        
        logger.info("\nActive configurations:")
        for symbol, config in self.configs.items():
            safe_flag = "🛡️" if config.get('safe', False) else "✅"
            logger.info(f"{safe_flag} {symbol}: ${config['capital']} @ {config['leverage']}x")
        
        logger.info("=" * 60)
    
    def get_safe_params(self, symbol: str, total_capital: float = 15000) -> Dict[str, Any]:
        """
        Безопасное получение параметров для актива
        БЕЗ HARDCODED DEFAULTS - использует SimpleMarginCalculator
        
        Args:
            symbol: Символ актива
            total_capital: Общий капитал для расчета allocation
        """
        clean_symbol = symbol.replace('/USDT', '').replace('-USDT', '').upper()
        
        # Приоритет 1: Проверяем загруженные конфиги
        if clean_symbol in self.configs:
            config = self.configs[clean_symbol].copy()
            config['source'] = 'config'
            logger.debug(f"{symbol}: Using loaded config")
        
        # Приоритет 2: Используем SimpleMarginCalculator
        elif self.margin_calculator:
            try:
                # Получаем allocation и leverage из SimpleMarginCalculator
                # calculate(total_capital, symbol, daf)
                calc_result = self.margin_calculator.calculate(
                    total_capital,  # позиционный аргумент
                    symbol,
                    0.5  # daf
                )
                
                config = {
                    'capital': calc_result['margin'],
                    'leverage': calc_result['leverage'],
                    'allocation': calc_result.get('allocation_pct', 0),  # Правильный ключ
                    'source': 'SimpleMarginCalculator',
                    'calculated': True
                }
                logger.debug(f"{symbol}: Using SimpleMarginCalculator (allocation={calc_result.get('allocation_pct', 0):.1%})")
            except Exception as e:
                logger.warning(f"SimpleMarginCalculator failed for {symbol}: {e}, using fallback")
                config = {
                    'capital': self.fallback_capital,
                    'leverage': self.fallback_leverage,
                    'source': 'fallback',
                    'safe': True
                }
        
        # Приоритет 3: Только если нет SimpleMarginCalculator - fallback
        else:
            config = {
                'capital': self.fallback_capital,
                'leverage': self.fallback_leverage,
                'source': 'fallback',
                'safe': True
            }
            logger.debug(f"{symbol}: Using fallback values")
        
        # Валидация и границы
        config['capital'] = max(10, min(10000, config.get('capital', self.fallback_capital)))
        config['leverage'] = max(1, min(20, config.get('leverage', self.fallback_leverage)))
        
        # Метаданные
        config['symbol'] = symbol
        config['clean_symbol'] = clean_symbol
        config['timestamp'] = datetime.now().isoformat()
        
        return config
    
    def get_grid_capital(self, symbol: str) -> float:
        """Безопасное получение капитала для сетки"""
        params = self.get_safe_params(symbol)
        return params['capital']
    
    def get_leverage(self, symbol: str) -> float:
        """Безопасное получение плеча"""
        params = self.get_safe_params(symbol)
        return params['leverage']

if __name__ == "__main__":
    print("✅ Asset Config Wrapper создан")
