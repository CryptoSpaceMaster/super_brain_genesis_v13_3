#!/usr/bin/env python3
"""
AEGIS v2.0 - Система трехконтурного учета капитала
ТОЧНО ПО ЭНЦИКЛОПЕДИИ
"""
import logging
from typing import Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

class AEGISv2:
    """
    AEGIS v2.0 - Трехконтурный учет капитала
    
    Контуры:
    1. Оперативный USD - реализованный PnL
    2. Залоговый портфель - нереализованный PnL
    3. Вспомогательная буферная зона
    """
    
    def __init__(self, initial_capital: float = 5000):
        self.initial_capital = initial_capital
        self.operational_usd = initial_capital
        self.realized_pnl_buffer = 0.0
        self.collateral_portfolio = {}
        self.sessions = []
        self.current_session = None
        
        self.limit_check_stats = {
            'total_checks': 0,
            'allowed': 0,
            'rejected': 0,
            'rejection_reasons': {}
        }
        
        logger.info(f"AEGIS v2.0 initialized with capital: ${initial_capital}")
    
    def start_new_session(self, session_id: Optional[str] = None) -> Dict:
        """Запуск новой торговой сессии"""
        if session_id is None:
            session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        self.current_session = {
            'id': session_id,
            'start_time': datetime.now(),
            'initial_usd': self.operational_usd,
            'realized_pnl': 0.0,
            'trades_count': 0
        }
        self.sessions.append(self.current_session)
        
        logger.info(f"✅ Started session: {session_id} with ${self.operational_usd}")
        return self.current_session
    
    def record_realized_pnl(self, pnl: float, trade_id: Optional[str] = None) -> Dict:
        """Запись реализованного PnL"""
        self.realized_pnl_buffer += pnl
        self.operational_usd += pnl
        
        if self.current_session:
            self.current_session['realized_pnl'] += pnl
            self.current_session['trades_count'] += 1
        
        logger.info(f"💰 Realized PnL: ${pnl:.2f} | New balance: ${self.operational_usd:.2f}")
        
        return {
            'pnl': pnl,
            'operational_usd': self.operational_usd,
            'buffer': self.realized_pnl_buffer,
            'trade_id': trade_id
        }
    
    def get_available_usd(self) -> float:
        """Получение доступного USD для торговли"""
        return self.operational_usd
    
    def get_total_pnl(self) -> float:
        """Получение общего PnL"""
        return self.operational_usd - self.initial_capital
    
    def get_stats(self) -> Dict:
        """Получение статистики"""
        return {
            'initial_capital': self.initial_capital,
            'operational_usd': self.operational_usd,
            'total_pnl': self.get_total_pnl(),
            'realized_buffer': self.realized_pnl_buffer,
            'sessions_count': len(self.sessions),
            'current_session': self.current_session
        }
    
    def check_progressive_grid_limits(self, symbol: str, grid_params: Dict, 
                                     position_memory: Optional[Dict] = None) -> Dict:
        """
        OPUS 4.1: Проверка лимитов для прогрессивной сеточной торговли
        
        Args:
            symbol: Символ актива
            grid_params: Параметры сетки (num_levels, total_exposure, etc.)
            position_memory: История позиций
        
        Returns:
            Dict с allowed: bool и reason
        """
        self.limit_check_stats['total_checks'] += 1
        
        available_capital = self.get_available_usd()
        
        total_exposure = grid_params.get('total_exposure', 0)
        num_levels = grid_params.get('num_levels', 0)
        progressive_mult = grid_params.get('progressive_mult', 1.0)
        
        max_exposure_pct = 0.3
        max_allowed_exposure = available_capital * max_exposure_pct
        
        if total_exposure > max_allowed_exposure:
            self.limit_check_stats['rejected'] += 1
            reason_key = 'exposure_limit'
            self.limit_check_stats['rejection_reasons'][reason_key] = \
                self.limit_check_stats['rejection_reasons'].get(reason_key, 0) + 1
            
            logger.warning(f"🚫 LIMIT CHECK: {symbol} exposure ${total_exposure:.2f} exceeds max ${max_allowed_exposure:.2f}")
            
            return {
                'allowed': False,
                'reason': f'Exposure ${total_exposure:.2f} exceeds max ${max_allowed_exposure:.2f}',
                'available_capital': available_capital,
                'max_exposure': max_allowed_exposure,
                'requested_exposure': total_exposure
            }
        
        if position_memory:
            current_exposure = position_memory.get('current_exposure', 0)
            total_entries = position_memory.get('total_entries', 0)
            
            if total_entries > 20:
                self.limit_check_stats['rejected'] += 1
                reason_key = 'too_many_entries'
                self.limit_check_stats['rejection_reasons'][reason_key] = \
                    self.limit_check_stats['rejection_reasons'].get(reason_key, 0) + 1
                
                logger.warning(f"🚫 LIMIT CHECK: {symbol} entries {total_entries} exceeds max 20")
                
                return {
                    'allowed': False,
                    'reason': f'Too many entries: {total_entries} > 20',
                    'total_entries': total_entries
                }
            
            if current_exposure + total_exposure > max_allowed_exposure:
                self.limit_check_stats['rejected'] += 1
                reason_key = 'combined_exposure'
                self.limit_check_stats['rejection_reasons'][reason_key] = \
                    self.limit_check_stats['rejection_reasons'].get(reason_key, 0) + 1
                
                logger.warning(f"🚫 LIMIT CHECK: {symbol} combined exposure ${current_exposure + total_exposure:.2f} exceeds limit")
                
                return {
                    'allowed': False,
                    'reason': f'Combined exposure ${current_exposure + total_exposure:.2f} exceeds limit',
                    'current_exposure': current_exposure,
                    'new_exposure': total_exposure
                }
        
        if progressive_mult > 2.0 and num_levels > 10:
            self.limit_check_stats['rejected'] += 1
            reason_key = 'aggressive_multiplier'
            self.limit_check_stats['rejection_reasons'][reason_key] = \
                self.limit_check_stats['rejection_reasons'].get(reason_key, 0) + 1
            
            logger.warning(f"🚫 LIMIT CHECK: {symbol} multiplier {progressive_mult} too aggressive for {num_levels} levels")
            
            return {
                'allowed': False,
                'reason': 'Progressive multiplier too aggressive for level count',
                'progressive_mult': progressive_mult,
                'num_levels': num_levels
            }
        
        self.limit_check_stats['allowed'] += 1
        utilization_pct = (total_exposure / max_allowed_exposure * 100) if max_allowed_exposure > 0 else 0
        
        logger.info(f"✅ LIMIT CHECK: {symbol} allowed | Exposure: ${total_exposure:.2f} ({utilization_pct:.1f}% utilization)")
        
        return {
            'allowed': True,
            'reason': 'All limits passed',
            'available_capital': available_capital,
            'max_exposure': max_allowed_exposure,
            'requested_exposure': total_exposure,
            'utilization_pct': utilization_pct
        }
    
    def get_limit_check_stats(self) -> Dict:
        """Получение статистики проверки лимитов (мониторинг)"""
        total = self.limit_check_stats['total_checks']
        allowed = self.limit_check_stats['allowed']
        rejected = self.limit_check_stats['rejected']
        
        return {
            'total_checks': total,
            'allowed': allowed,
            'rejected': rejected,
            'approval_rate': (allowed / total * 100) if total > 0 else 0,
            'rejection_rate': (rejected / total * 100) if total > 0 else 0,
            'rejection_reasons': self.limit_check_stats['rejection_reasons']
        }

if __name__ == "__main__":
    print("✅ AEGIS v2.0 создан с check_progressive_grid_limits()")
