#!/usr/bin/env python3
"""
Smart Drawdown Manager v2.0
ТОЧНО ПО ЭНЦИКЛОПЕДИИ OPUS 4.1
"""
import logging
from typing import Dict, Optional
from enum import Enum

logger = logging.getLogger(__name__)

class DrawdownMode(Enum):
    """Режимы работы с просадками"""
    PROTECT = "PROTECT"  # Защита капитала
    ACCUMULATE = "ACCUMULATE"  # Накопление (антихрупкий режим)
    HARVEST = "HARVEST"  # Сбор прибыли

class SmartDrawdownManager:
    """
    Smart Drawdown Manager v2.0 - ПОЛНАЯ РЕАЛИЗАЦИЯ OPUS 4.1
    
    Интеллектуальная работа с просадками на основе вердиктов TRUTH ENGINE:
    - Индивидуальные лимиты просадки по активам
    - Эффективная просадка с учетом накопленной прибыли
    - Временное расширение лимита при сквизе
    - Интеллектуальное закрытие позиций
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.current_mode = DrawdownMode.PROTECT
        
        # Индивидуальные лимиты просадки по активам (%)
        self.drawdown_limits = {
            'BTC': 0.10,    # BTC может просесть на 10%
            'ETH': 0.12,    # ETH - на 12%
            'SOL': 0.15,    # SOL - на 15%
            'DEFAULT': 0.08  # Остальные - 8%
        }
        
        # История накопленной прибыли по активам
        self.accumulated_profit: Dict[str, float] = {}
        
        # Публичный алиас для внешнего доступа
        self.asset_limits = self.drawdown_limits
        
        logger.info("Smart Drawdown Manager v2.0 initialized (OPUS 4.1)")
        logger.info(f"  Drawdown limits: BTC {self.drawdown_limits['BTC']:.0%}, "
                   f"ETH {self.drawdown_limits['ETH']:.0%}, SOL {self.drawdown_limits['SOL']:.0%}")
    
    def analyze_drawdown(self, current_dd: float, truth_verdict: str, confidence: float,
                         asset: str = 'BTC', accumulated_profit: float = 0.0) -> Dict:
        """
        ГЛАВНАЯ ФУНКЦИЯ - Анализ просадки и выбор режима (OPUS 4.1)
        
        Backward compatible: поддерживает старый вызов (dd, verdict, confidence)
        и новый (dd, verdict, confidence, asset, profit)
        
        Args:
            asset: Актив (BTC, ETH, SOL и т.д.)
            current_dd: Текущая просадка (0.0-1.0, например 0.08 = 8%)
            truth_verdict: Вердикт TRUTH ENGINE
            confidence: Уверенность вердикта (0.0-1.0)
            accumulated_profit: Накопленная прибыль от дробных закрытий
        
        Returns:
            Dict с решением и multipliers
        """
        # Обновляем накопленную прибыль
        if accumulated_profit > 0:
            self.accumulated_profit[asset] = accumulated_profit
        
        # Получаем лимит для актива
        clean_asset = asset.replace('/USDT', '').replace('-USDT', '').upper()
        limit = self.drawdown_limits.get(clean_asset, self.drawdown_limits['DEFAULT'])
        
        # Расчет ЭФФЕКТИВНОЙ просадки (ключевая фича OPUS 4.1)
        effective_dd = current_dd - (accumulated_profit / 100 if accumulated_profit > 0 else 0)
        effective_dd = max(0, effective_dd)  # Не может быть отрицательной
        
        # Процент достижения лимита
        dd_percentage = abs(effective_dd) / limit * 100 if limit > 0 else 0
        
        # КЛЮЧЕВОЕ РЕШЕНИЕ - что делать с просадкой
        if truth_verdict == "Manipulation_Squeeze" and confidence > 0.7:
            # ЭТО СКВИЗ! Не паникуем, а накапливаем!
            self.current_mode = DrawdownMode.ACCUMULATE
            grid_density_mult = 1.5
            position_size_mult = 1.2
            action = "INCREASE_AGGRESSION"
            
            # Временно расширяем лимит на 50%
            extended_limit = limit * 1.5
            
            logger.info(f"🎯 {asset}: ACCUMULATE режим (сквиз обнаружен!)")
            logger.info(f"   Лимит расширен: {limit:.0%} → {extended_limit:.0%}")
            
            return {
                'mode': self.current_mode.value,
                'asset': asset,
                'current_dd': current_dd,
                'effective_dd': effective_dd,
                'accumulated_profit': accumulated_profit,
                'limit': limit,
                'extended_limit': extended_limit,
                'dd_percentage': dd_percentage,
                'truth_verdict': truth_verdict,
                'confidence': confidence,
                'grid_density_mult': grid_density_mult,
                'position_size_mult': position_size_mult,
                'action': action,
                'kill_switch': False
            }
            
        elif truth_verdict == "Trend_Impulse" and dd_percentage > 80:
            # Опасный тренд при большой просадке - защищаемся
            self.current_mode = DrawdownMode.PROTECT
            grid_density_mult = 0.7
            position_size_mult = 0.8
            action = "REDUCE_RISK"
            
            logger.warning(f"🛡️ {asset}: PROTECT режим (опасный тренд, DD {dd_percentage:.1f}%)")
            
            return {
                'mode': self.current_mode.value,
                'asset': asset,
                'current_dd': current_dd,
                'effective_dd': effective_dd,
                'accumulated_profit': accumulated_profit,
                'limit': limit,
                'extended_limit': limit,
                'dd_percentage': dd_percentage,
                'truth_verdict': truth_verdict,
                'confidence': confidence,
                'grid_density_mult': grid_density_mult,
                'position_size_mult': position_size_mult,
                'action': action,
                'kill_switch': dd_percentage > 95  # Закрываем если >95% лимита
            }
            
        else:
            # Нормальная ситуация - собираем прибыль
            self.current_mode = DrawdownMode.HARVEST
            aggression = 0.5 + (1 - dd_percentage/100) * 0.3  # Адаптивная агрессия
            grid_density_mult = 1.0
            position_size_mult = min(1.0, aggression)
            action = "HARVEST"
            
            logger.info(f"💰 {asset}: HARVEST режим (effective DD {effective_dd:.1%})")
            
            return {
                'mode': self.current_mode.value,
                'asset': asset,
                'current_dd': current_dd,
                'effective_dd': effective_dd,
                'accumulated_profit': accumulated_profit,
                'limit': limit,
                'extended_limit': limit,
                'dd_percentage': dd_percentage,
                'truth_verdict': truth_verdict,
                'confidence': confidence,
                'grid_density_mult': grid_density_mult,
                'position_size_mult': position_size_mult,
                'action': action,
                'kill_switch': False
            }
    
    def should_close_position(self, asset: str, current_dd: float, 
                             unrealized_pnl: float, truth_verdict: str,
                             confidence: float) -> bool:
        """
        Решение о закрытии позиции - УМНОЕ, а не паническое! (OPUS 4.1)
        
        Args:
            asset: Актив
            current_dd: Текущая просадка
            unrealized_pnl: Нереализованный PnL
            truth_verdict: Вердикт TRUTH ENGINE
            confidence: Уверенность
            
        Returns:
            True если нужно закрыть позицию
        """
        accumulated = self.accumulated_profit.get(asset, 0.0)
        analysis = self.analyze_drawdown(
            current_dd=current_dd,
            truth_verdict=truth_verdict,
            confidence=confidence,
            asset=asset,
            accumulated_profit=accumulated
        )
        
        # НЕ закрываем если:
        # 1. Truth Engine видит манипуляцию (режим ACCUMULATE)
        if analysis['mode'] == 'ACCUMULATE':
            logger.info(f"   {asset}: Не закрываем - обнаружен сквиз")
            return False
        
        # 2. У нас есть накопленная прибыль которая покрывает 30%+ просадки
        if unrealized_pnl > abs(current_dd) * 0.3:
            logger.info(f"   {asset}: Не закрываем - прибыль покрывает 30% просадки")
            return False
        
        # 3. Мы не достигли критического уровня
        if analysis['dd_percentage'] < 95:
            logger.info(f"   {asset}: Не закрываем - просадка {analysis['dd_percentage']:.1f}% < 95%")
            return False
        
        # Иначе - закрываем для защиты капитала
        logger.warning(f"   {asset}: ЗАКРЫВАЕМ позицию - критический уровень!")
        return analysis.get('kill_switch', False)
    
    def check_progressive_grid_limits(self, asset: str, current_positions: int, 
                                     total_exposure: float, available_capital: float,
                                     current_dd: float, truth_verdict: str = 'Consolidation_Range',
                                     max_positions: int = 10, max_exposure_pct: float = 0.3) -> Dict:
        """
        OPUS 4.1: Проверка лимитов для прогрессивной сетки
        
        Комплексная проверка перед добавлением нового уровня в сетку:
        - Количество позиций
        - Общая экспозиция
        - Просадка
        - Корреляция с другими активами (опционально)
        
        Args:
            asset: Торговый актив
            current_positions: Текущее количество открытых позиций
            total_exposure: Общая экспозиция в USD
            available_capital: Доступный капитал
            current_dd: Текущая просадка (0.0-1.0)
            truth_verdict: Вердикт TRUTH ENGINE
            max_positions: Максимальное количество позиций (default 10)
            max_exposure_pct: Максимальная экспозиция в % от капитала (default 30%)
        
        Returns:
            Dict с результатами проверки и рекомендациями
        """
        try:
            clean_asset = asset.replace('/USDT', '').replace('-USDT', '').upper()
            limit = self.drawdown_limits.get(clean_asset, self.drawdown_limits['DEFAULT'])
            accumulated = self.accumulated_profit.get(clean_asset, 0.0)
            
            effective_dd = current_dd - (accumulated / 100 if accumulated > 0 else 0)
            effective_dd = max(0, effective_dd)
            
            dd_percentage = abs(effective_dd) / limit * 100 if limit > 0 else 0
            
            checks = {}
            
            checks['max_positions_ok'] = current_positions < max_positions
            if not checks['max_positions_ok']:
                logger.warning(f"⚠️ {asset}: Max positions reached: {current_positions}/{max_positions}")
            
            max_exposure_allowed = available_capital * max_exposure_pct
            exposure_pct = (total_exposure / available_capital * 100) if available_capital > 0 else 0
            checks['max_exposure_ok'] = total_exposure <= max_exposure_allowed
            if not checks['max_exposure_ok']:
                logger.warning(f"⚠️ {asset}: Max exposure reached: ${total_exposure:.2f} "
                              f"({exposure_pct:.1f}%) > ${max_exposure_allowed:.2f} ({max_exposure_pct*100:.0f}%)")
            
            if truth_verdict == 'Manipulation_Squeeze':
                drawdown_threshold = 80
            elif truth_verdict == 'Trend_Impulse':
                drawdown_threshold = 60
            else:
                drawdown_threshold = 70
            
            checks['drawdown_ok'] = dd_percentage < drawdown_threshold
            if not checks['drawdown_ok']:
                logger.warning(f"⚠️ {asset}: Drawdown too high: {dd_percentage:.1f}% > {drawdown_threshold}%")
            
            checks['correlation_ok'] = True
            
            all_passed = all(checks.values())
            
            if all_passed:
                recommendation = 'PROCEED'
                risk_level = 'LOW' if dd_percentage < 40 else 'MEDIUM' if dd_percentage < 60 else 'HIGH'
            else:
                recommendation = 'HOLD' if sum(checks.values()) >= 2 else 'REDUCE_EXPOSURE'
                risk_level = 'HIGH'
            
            result = {
                'asset': asset,
                'checks': checks,
                'all_checks_passed': all_passed,
                'recommendation': recommendation,
                'risk_level': risk_level,
                'details': {
                    'current_positions': current_positions,
                    'max_positions': max_positions,
                    'total_exposure': total_exposure,
                    'exposure_pct': exposure_pct,
                    'max_exposure_allowed': max_exposure_allowed,
                    'current_dd': current_dd,
                    'effective_dd': effective_dd,
                    'dd_percentage': dd_percentage,
                    'drawdown_threshold': drawdown_threshold,
                    'truth_verdict': truth_verdict
                }
            }
            
            if all_passed:
                logger.info(f"✅ {asset}: Progressive grid limits check PASSED ({risk_level} risk)")
            else:
                failed = [k for k, v in checks.items() if not v]
                logger.warning(f"❌ {asset}: Progressive grid limits check FAILED: {', '.join(failed)}")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Error checking progressive grid limits: {e}")
            return {
                'asset': asset,
                'checks': {
                    'max_positions_ok': False,
                    'max_exposure_ok': False,
                    'drawdown_ok': False,
                    'correlation_ok': False
                },
                'all_checks_passed': False,
                'recommendation': 'ERROR',
                'risk_level': 'UNKNOWN',
                'error': str(e)
            }
    
    def get_stats(self) -> Dict:
        """Статистика работы менеджера просадок"""
        return {
            'current_mode': self.current_mode.value,
            'drawdown_limits': self.drawdown_limits,
            'accumulated_profit': self.accumulated_profit,
            'total_accumulated': sum(self.accumulated_profit.values())
        }

if __name__ == "__main__":
    print("✅ Smart Drawdown Manager v2.0 создан")
