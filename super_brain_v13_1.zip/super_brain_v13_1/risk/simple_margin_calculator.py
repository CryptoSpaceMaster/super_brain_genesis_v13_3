#!/usr/bin/env python3
"""
SimpleMarginCalculator - OPUS 4.1
Максимально простой расчет маржи БЕЗ усложнений (50 строк логики)
"""
import logging
from typing import Dict

logger = logging.getLogger(__name__)

class SimpleMarginCalculator:
    """
    УЛЬТРА-ПРОСТОЕ решение для расчета маржи
    Никаких сложностей, мгновенный расчет
    """
    
    def __init__(self):
        self.allocation_table = {
            'BTC': 0.13,
            'ETH': 0.067,
            'SOL': 0.033,
            'DEFAULT': 0.013
        }
        
        self.leverage_table = {
            'BTC': 10,
            'ETH': 7,
            'SOL': 7,
            'DEFAULT': 5
        }
        
        logger.info("SimpleMarginCalculator initialized")
        logger.info(f"  Allocation: BTC 13%, ETH 6.7%, SOL 3.3%, Others 1.3%")
        logger.info(f"  Leverage: BTC 10x, ETH 7x, SOL 7x, Others 5x")
    
    def calculate(self, deposit: float, asset: str, daf: float = 0.5) -> Dict:
        """
        ГЛАВНАЯ ФУНКЦИЯ - расчет маржи и плеча
        
        Args:
            deposit: Размер депозита в USD
            asset: Актив (BTC, ETH, SOL, etc.)
            daf: Dynamic Aggression Factor от Truth Engine (0-1)
        
        Returns:
            Dict с margin, leverage, position_size
        """
        
        asset_symbol = asset.replace('USDT', '').replace('BUSD', '')
        
        base_pct = self.allocation_table.get(asset_symbol, self.allocation_table['DEFAULT'])
        
        if deposit < 5000:
            base_pct *= 0.7
        elif deposit > 20000:
            base_pct *= 1.1
        
        margin_adjustment = 1 + (daf - 0.5) * 0.3
        
        margin = deposit * base_pct * margin_adjustment
        
        margin = max(10, min(margin, deposit * 0.2))
        
        leverage = self.leverage_table.get(asset_symbol, self.leverage_table['DEFAULT'])
        
        position_size = margin * leverage
        
        result = {
            'margin': round(margin, 2),
            'leverage': leverage,
            'position_size': round(position_size, 2),
            'base_allocation_pct': base_pct,
            'daf_adjustment': margin_adjustment,
            'asset': asset
        }
        
        logger.debug(f"Margin calc for {asset}: ${margin:.2f} @ {leverage}x = ${position_size:.2f} position")
        
        return result
    
    def get_allocation_info(self, asset: str) -> Dict:
        """Получить информацию о выделении для актива"""
        asset_symbol = asset.replace('USDT', '').replace('BUSD', '')
        
        return {
            'asset': asset,
            'allocation_pct': self.allocation_table.get(asset_symbol, self.allocation_table['DEFAULT']),
            'leverage': self.leverage_table.get(asset_symbol, self.leverage_table['DEFAULT']),
            'is_default': asset_symbol not in self.allocation_table
        }

if __name__ == "__main__":
    calc = SimpleMarginCalculator()
    
    examples = [
        (15000, 'BTCUSDT', 0.5),
        (15000, 'ETHUSDT', 0.7),
        (4000, 'BTCUSDT', 0.5),
        (21000, 'SOLUSDT', 0.3),
    ]
    
    print("\n" + "="*80)
    print("SIMPLE MARGIN CALCULATOR - EXAMPLES")
    print("="*80)
    
    for deposit, asset, daf in examples:
        result = calc.calculate(deposit, asset, daf)
        print(f"\nDeposit: ${deposit:,} | Asset: {asset} | DAF: {daf}")
        print(f"  → Margin: ${result['margin']:,.2f}")
        print(f"  → Leverage: {result['leverage']}x")
        print(f"  → Position Size: ${result['position_size']:,.2f}")
