#!/usr/bin/env python3
"""
Production-Ready Logging System
Структурированное логирование для СУПЕР МОЗГ v13.1
"""
import logging
from logging.handlers import TimedRotatingFileHandler
import json
from datetime import datetime
from typing import Dict, Optional, Any
from pathlib import Path

class ProductionLogger:
    """
    Production-Ready Logger с структурированным форматом
    
    Features:
    - JSON структурированное логирование
    - Разделение по уровням (debug, info, warning, error, critical)
    - Ротация файлов по дням (TimedRotatingFileHandler)
    - Контекстуальная информация (strategy, symbol, action)
    - Performance metrics
    - Защита от дублирования handlers (Singleton pattern)
    """
    
    _instances = {}
    
    def __new__(cls, log_dir: str = "super_brain_v13_1/logs", app_name: str = "superbrain"):
        """Singleton pattern для предотвращения дублирования handlers"""
        key = f"{log_dir}_{app_name}"
        if key not in cls._instances:
            cls._instances[key] = super().__new__(cls)
        return cls._instances[key]
    
    def __init__(self, log_dir: str = "super_brain_v13_1/logs", app_name: str = "superbrain"):
        # Проверка инициализации (для singleton)
        if hasattr(self, '_initialized'):
            return
        
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.app_name = app_name
        
        # Основной logger
        self.logger = logging.getLogger(app_name)
        self.logger.setLevel(logging.DEBUG)
        
        # Очистка существующих handlers для предотвращения дублирования
        self.logger.handlers.clear()
        
        # Создание handlers для разных уровней
        self._setup_handlers()
        
        self._initialized = True
    
    def _setup_handlers(self):
        """Настройка handlers для различных уровней логирования с ротацией"""
        
        # Формат для structured logging
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Handler для INFO и выше с ротацией по дням (хранение 30 дней)
        info_handler = TimedRotatingFileHandler(
            self.log_dir / f"{self.app_name}_info.log",
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        )
        info_handler.setLevel(logging.INFO)
        info_handler.setFormatter(formatter)
        info_handler.suffix = "%Y-%m-%d"
        
        # Handler для WARNING и выше с ротацией (хранение 30 дней)
        warning_handler = TimedRotatingFileHandler(
            self.log_dir / f"{self.app_name}_warnings.log",
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        )
        warning_handler.setLevel(logging.WARNING)
        warning_handler.setFormatter(formatter)
        warning_handler.suffix = "%Y-%m-%d"
        
        # Handler для ERROR и CRITICAL с ротацией (хранение 90 дней)
        error_handler = TimedRotatingFileHandler(
            self.log_dir / f"{self.app_name}_errors.log",
            when='midnight',
            interval=1,
            backupCount=90,
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(formatter)
        error_handler.suffix = "%Y-%m-%d"
        
        # Console handler для real-time мониторинга
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        
        # Добавление handlers
        self.logger.addHandler(info_handler)
        self.logger.addHandler(warning_handler)
        self.logger.addHandler(error_handler)
        self.logger.addHandler(console_handler)
    
    def log_strategy_action(self, strategy: str, action: str, 
                          symbol: str, data: Optional[Dict] = None,
                          level: str = "info"):
        """
        Логирование действия стратегии
        
        Args:
            strategy: Название стратегии (GRID-ORACLE, V-REVERSAL, SCALPING)
            action: Действие (ENTRY, EXIT, GRID_UPDATE, etc.)
            symbol: Торговая пара
            data: Дополнительные данные
            level: Уровень логирования
        """
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'strategy': strategy,
            'action': action,
            'symbol': symbol,
            'data': data or {}
        }
        
        message = f"[{strategy}] {action} on {symbol}"
        
        if level == "debug":
            self.logger.debug(f"{message} | {json.dumps(log_entry)}")
        elif level == "info":
            self.logger.info(f"{message} | {json.dumps(log_entry)}")
        elif level == "warning":
            self.logger.warning(f"{message} | {json.dumps(log_entry)}")
        elif level == "error":
            self.logger.error(f"{message} | {json.dumps(log_entry)}")
        elif level == "critical":
            self.logger.critical(f"{message} | {json.dumps(log_entry)}")
    
    def log_fsm_state_change(self, previous_state: str, new_state: str, 
                            reason: Optional[str] = None):
        """Логирование изменения FSM состояния"""
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'module': 'FSM',
            'event': 'STATE_CHANGE',
            'previous_state': previous_state,
            'new_state': new_state,
            'reason': reason
        }
        
        self.logger.info(f"[FSM] State Change: {previous_state} → {new_state} | {json.dumps(log_entry)}")
    
    def log_truth_verdict(self, verdict: str, confidence: float, 
                         symbol: str, factors: Optional[Dict] = None):
        """Логирование TRUTH ENGINE вердикта"""
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'module': 'TRUTH_ENGINE',
            'event': 'VERDICT',
            'verdict': verdict,
            'confidence': confidence,
            'symbol': symbol,
            'factors': factors or {}
        }
        
        self.logger.info(f"[TRUTH ENGINE] Verdict: {verdict} ({confidence:.2f}) on {symbol} | {json.dumps(log_entry)}")
    
    def log_kill_switch_event(self, strategy: str, is_active: bool, 
                             reason: Optional[str] = None, metrics: Optional[Dict] = None):
        """Логирование событий Kill Switch"""
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'module': 'KILL_SWITCH',
            'strategy': strategy,
            'is_active': is_active,
            'reason': reason,
            'metrics': metrics or {}
        }
        
        level = "critical" if is_active else "info"
        action = "ACTIVATED" if is_active else "DEACTIVATED"
        
        message = f"[KILL SWITCH] {action} for {strategy}"
        
        if level == "critical":
            self.logger.critical(f"{message} | {json.dumps(log_entry)}")
        else:
            self.logger.info(f"{message} | {json.dumps(log_entry)}")
    
    def log_performance_metric(self, metric_name: str, value: Any, 
                              context: Optional[Dict] = None):
        """Логирование метрики производительности"""
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'module': 'PERFORMANCE',
            'metric_name': metric_name,
            'value': value,
            'context': context or {}
        }
        
        self.logger.debug(f"[PERFORMANCE] {metric_name}: {value} | {json.dumps(log_entry)}")
    
    def log_error_with_context(self, error: Exception, context: Dict):
        """Логирование ошибки с контекстом"""
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'module': 'ERROR',
            'error_type': type(error).__name__,
            'error_message': str(error),
            'context': context
        }
        
        self.logger.error(f"[ERROR] {type(error).__name__}: {str(error)} | {json.dumps(log_entry)}")

if __name__ == "__main__":
    print("✅ Production Logger готов")
