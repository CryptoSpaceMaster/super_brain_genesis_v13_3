"""
Universal DB Connector - Верификация Потоков Данных
Документ: Методология Полной Отладки (Раздел 1)

Этот модуль выполняет проверку наличия и доступности всех ключевых
таблиц данных, необходимых для работы экосистемы СУПЕР МОЗГ.

Согласно принципу «Доказуемой Истинности», запуск этого коннектора
должен стать обязательным первым шагом в любом протоколе системной диагностики.
"""

import logging
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


class DataQualityStatus(Enum):
    """Статус качества данных"""
    EXCELLENT = "EXCELLENT"  # Данные актуальные и полные
    GOOD = "GOOD"            # Данные доступны, но есть небольшие пробелы
    DEGRADED = "DEGRADED"    # Данные устаревшие или неполные
    CRITICAL = "CRITICAL"    # Данные недоступны или критически повреждены
    UNKNOWN = "UNKNOWN"      # Статус не определен


class UniversalDBConnector:
    """
    Universal DB Connector - центральный инструмент верификации данных
    
    Проверяет доступность и целостность:
    - ohlcv (Klines)
    - trades (для CVD расчета)
    - orderbook (для OBI расчета)
    - tickers (ценовые данные)
    - funding (ставки финансирования)
    - cryptoquant (15 ончейн-метрик)
    """
    
    def __init__(self, simulation_mode: bool = True):
        """
        Args:
            simulation_mode: Режим симуляции (без реальной БД)
        """
        self.simulation_mode = simulation_mode
        self.last_verification = None
        self.verification_cache = {}
        
        # Критичные таблицы согласно документу
        self.critical_tables = [
            'ohlcv',      # Klines для индикаторов
            'trades',     # Для CVD (Cumulative Volume Delta)
            'orderbook',  # Для OBI (Order Book Imbalance)
            'tickers',    # Ценовые данные
            'funding',    # Ставки финансирования
            'cryptoquant' # 15 ончейн-метрик
        ]
        
        logger.info("🔌 Universal DB Connector initialized")
        logger.info(f"   Mode: {'SIMULATION' if simulation_mode else 'PRODUCTION'}")
        logger.info(f"   Critical tables: {len(self.critical_tables)}")
    
    def verify_all_data_sources(self) -> Dict:
        """
        Полная верификация всех источников данных
        
        Это обязательный первый шаг любой системной диагностики
        согласно методологии документа.
        
        Returns:
            Dict с результатами проверки всех источников
        """
        logger.info("="*80)
        logger.info("🔍 UNIVERSAL DB CONNECTOR - FULL DATA VERIFICATION")
        logger.info("="*80)
        
        results = {
            'timestamp': datetime.now().isoformat(),
            'simulation_mode': self.simulation_mode,
            'tables': {},
            'overall_status': DataQualityStatus.UNKNOWN.value,
            'critical_issues': [],
            'warnings': [],
            'chain_integrity': {}
        }
        
        # Проверяем каждую таблицу
        for table in self.critical_tables:
            table_status = self._verify_table(table)
            results['tables'][table] = table_status
            
            if table_status['status'] == DataQualityStatus.CRITICAL.value:
                results['critical_issues'].append(
                    f"{table}: {table_status.get('error', 'Unknown error')}"
                )
            elif table_status['status'] == DataQualityStatus.DEGRADED.value:
                results['warnings'].append(
                    f"{table}: {table_status.get('warning', 'Data quality degraded')}"
                )
        
        # Определяем общий статус
        statuses = [t['status'] for t in results['tables'].values()]
        if DataQualityStatus.CRITICAL.value in statuses:
            results['overall_status'] = DataQualityStatus.CRITICAL.value
        elif DataQualityStatus.DEGRADED.value in statuses:
            results['overall_status'] = DataQualityStatus.DEGRADED.value
        elif DataQualityStatus.GOOD.value in statuses:
            results['overall_status'] = DataQualityStatus.GOOD.value
        else:
            results['overall_status'] = DataQualityStatus.EXCELLENT.value
        
        # Проверяем целостность цепочки зависимостей
        results['chain_integrity'] = self._verify_chain_integrity(results['tables'])
        
        # Сохраняем в кэш
        self.last_verification = datetime.now()
        self.verification_cache = results
        
        self._print_verification_report(results)
        
        return results
    
    def _verify_table(self, table_name: str) -> Dict:
        """
        Проверка доступности и качества данных конкретной таблицы
        
        Args:
            table_name: Имя таблицы для проверки
            
        Returns:
            Dict с результатами проверки
        """
        if self.simulation_mode:
            return self._simulate_table_check(table_name)
        
        # В production режиме здесь будет реальная проверка TimescaleDB
        try:
            # TODO: Implement real DB connection and queries
            return {
                'table': table_name,
                'status': DataQualityStatus.EXCELLENT.value,
                'available': True,
                'last_update': datetime.now().isoformat(),
                'row_count': 100000,
                'freshness_minutes': 1
            }
        except Exception as e:
            return {
                'table': table_name,
                'status': DataQualityStatus.CRITICAL.value,
                'available': False,
                'error': str(e)
            }
    
    def _simulate_table_check(self, table_name: str) -> Dict:
        """Симуляция проверки таблицы для режима SIMULATION"""
        
        # Имитируем разное качество данных для демонстрации
        import random
        
        statuses = [
            DataQualityStatus.EXCELLENT,
            DataQualityStatus.GOOD,
            DataQualityStatus.GOOD
        ]
        
        status = random.choice(statuses)
        
        result = {
            'table': table_name,
            'status': status.value,
            'available': True,
            'last_update': (datetime.now() - timedelta(minutes=random.randint(1, 5))).isoformat(),
            'row_count': random.randint(50000, 200000),
            'freshness_minutes': random.randint(1, 5),
            'simulation': True
        }
        
        if status == DataQualityStatus.GOOD:
            result['warning'] = "Minor data gaps detected"
        
        return result
    
    def _verify_chain_integrity(self, tables: Dict) -> Dict:
        """
        Проверка целостности цепочки зависимостей данных
        
        Согласно документу: ohlcv → indicators → LPI → UMSI → FSM → Strategies
        
        Args:
            tables: Результаты проверки таблиц
            
        Returns:
            Dict с результатами проверки цепочки
        """
        chain = {
            'data_foundation': {
                'components': ['ohlcv', 'trades', 'orderbook'],
                'status': 'OK',
                'issues': []
            },
            'market_intelligence': {
                'components': ['funding', 'cryptoquant'],
                'status': 'OK',
                'issues': []
            },
            'price_discovery': {
                'components': ['tickers'],
                'status': 'OK',
                'issues': []
            }
        }
        
        # Проверяем каждый уровень цепочки
        for level, info in chain.items():
            for component in info['components']:
                if component in tables:
                    comp_status = tables[component]['status']
                    if comp_status in [DataQualityStatus.CRITICAL.value, DataQualityStatus.DEGRADED.value]:
                        chain[level]['status'] = 'DEGRADED'
                        chain[level]['issues'].append(
                            f"{component}: {comp_status}"
                        )
        
        return chain
    
    def _print_verification_report(self, results: Dict):
        """Вывод отчета о верификации"""
        logger.info("\n" + "="*80)
        logger.info("📊 VERIFICATION REPORT")
        logger.info("="*80)
        
        # Общий статус
        status_emoji = {
            DataQualityStatus.EXCELLENT.value: "✅",
            DataQualityStatus.GOOD.value: "🟡",
            DataQualityStatus.DEGRADED.value: "⚠️",
            DataQualityStatus.CRITICAL.value: "❌"
        }
        
        emoji = status_emoji.get(results['overall_status'], "❓")
        logger.info(f"\n{emoji} Overall Status: {results['overall_status']}")
        
        # Таблицы
        logger.info(f"\n📋 Data Sources ({len(results['tables'])} tables):")
        for table_name, table_info in results['tables'].items():
            status = table_info['status']
            emoji = status_emoji.get(status, "❓")
            logger.info(f"   {emoji} {table_name}: {status}")
            
            if 'freshness_minutes' in table_info:
                logger.info(f"      Freshness: {table_info['freshness_minutes']} min")
            if 'row_count' in table_info:
                logger.info(f"      Records: {table_info['row_count']:,}")
        
        # Цепочка зависимостей
        logger.info(f"\n🔗 Chain Integrity:")
        for level, info in results['chain_integrity'].items():
            emoji = "✅" if info['status'] == 'OK' else "⚠️"
            logger.info(f"   {emoji} {level}: {info['status']}")
            if info['issues']:
                for issue in info['issues']:
                    logger.info(f"      - {issue}")
        
        # Критичные проблемы
        if results['critical_issues']:
            logger.warning(f"\n❌ CRITICAL ISSUES ({len(results['critical_issues'])}):")
            for issue in results['critical_issues']:
                logger.warning(f"   - {issue}")
        
        # Предупреждения
        if results['warnings']:
            logger.info(f"\n⚠️ WARNINGS ({len(results['warnings'])}):")
            for warning in results['warnings']:
                logger.info(f"   - {warning}")
        
        logger.info("\n" + "="*80)
    
    def get_data_health_score(self) -> float:
        """
        Расчет общего показателя здоровья данных (0.0 - 1.0)
        
        Returns:
            float: Оценка от 0.0 (критично) до 1.0 (отлично)
        """
        if not self.verification_cache:
            self.verify_all_data_sources()
        
        status_scores = {
            DataQualityStatus.EXCELLENT.value: 1.0,
            DataQualityStatus.GOOD.value: 0.8,
            DataQualityStatus.DEGRADED.value: 0.5,
            DataQualityStatus.CRITICAL.value: 0.0
        }
        
        tables = self.verification_cache.get('tables', {})
        if not tables:
            return 0.0
        
        scores = [status_scores.get(t['status'], 0.5) for t in tables.values()]
        return sum(scores) / len(scores)
    
    def is_ready_for_trading(self) -> bool:
        """
        Проверка готовности системы к торговле
        
        Система готова, если все критичные источники данных доступны
        и имеют статус как минимум GOOD.
        
        Returns:
            bool: True если система готова к торговле
        """
        if not self.verification_cache:
            self.verify_all_data_sources()
        
        # Критичные таблицы для торговли
        critical_for_trading = ['ohlcv', 'tickers', 'trades']
        
        tables = self.verification_cache.get('tables', {})
        
        for table in critical_for_trading:
            if table not in tables:
                return False
            
            status = tables[table]['status']
            if status in [DataQualityStatus.CRITICAL.value, DataQualityStatus.DEGRADED.value]:
                return False
        
        return True
