#!/usr/bin/env python3
"""
Monte Carlo Simulator - Симуляции для оценки устойчивости результатов
Реализация из документа "Backtesting & Optimization Suite как Абсолютный Системный Отладчик"
"""
import logging
from typing import Dict, List, Callable, Optional
from datetime import datetime
import pandas as pd
import numpy as np
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

@dataclass
class MonteCarloResults:
    """Результаты Монте-Карло симуляции"""
    strategy_name: str
    n_simulations: int
    
    # Метрики по всем симуляциям
    mean_pnl: float
    median_pnl: float
    std_pnl: float
    min_pnl: float
    max_pnl: float
    
    # Доверительные интервалы
    pnl_ci_95_lower: float
    pnl_ci_95_upper: float
    
    # Распределение результатов
    win_rate_mean: float
    win_rate_std: float
    
    sharpe_ratio_mean: float
    sharpe_ratio_std: float
    
    max_drawdown_mean: float
    max_drawdown_worst: float
    
    # Робастность
    probability_of_profit: float  # % симуляций с положительным PnL
    risk_of_ruin: float  # % симуляций с потерей >50% капитала
    
    # Все результаты
    all_results: List[Dict] = field(default_factory=list)
    
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class MonteCarloSimulator:
    """
    Симулятор Монте-Карло для оценки устойчивости результатов бэктестирования
    
    Методы:
    - Параметрическая вариация (изменение параметров стратегии)
    - Bootstrap resampling (пересэмплирование исторических данных)
    - Path randomization (рандомизация последовательности сделок)
    - Market regime shuffling (перемешивание рыночных режимов)
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config if config is not None else {}
        self.simulations_run = []
        
        logger.info("Monte Carlo Simulator initialized")
    
    def run_monte_carlo_backtest(self, 
                                 backtest_func: Callable,
                                 strategy_name: str,
                                 base_params: Dict,
                                 historical_data: pd.DataFrame,
                                 n_simulations: int = 1000,
                                 param_variations: Dict = None,
                                 initial_capital: float = 10000) -> MonteCarloResults:
        """
        Запуск Монте-Карло симуляций бэктеста
        
        Args:
            backtest_func: Функция бэктестирования (из BacktestingSuite)
            strategy_name: Название стратегии
            base_params: Базовые параметры стратегии
            historical_data: Исторические данные
            n_simulations: Количество симуляций
            param_variations: Диапазоны вариации параметров
            initial_capital: Начальный капитал
        
        Returns:
            MonteCarloResults с статистикой по всем симуляциям
        """
        
        logger.info(f"🎲 Starting Monte Carlo simulation: {n_simulations} runs for {strategy_name}")
        
        if param_variations is None:
            param_variations = {}
        
        results = []
        
        for i in range(n_simulations):
            # Вариация параметров
            varied_params = self._vary_parameters(base_params, param_variations)
            
            # Bootstrap resampling данных (опционально)
            if self.config.get('use_bootstrap', True):
                sampled_data = self._bootstrap_resample(historical_data)
            else:
                sampled_data = historical_data
            
            # Добавляем случайный шум к ценам (микро-вариации)
            if self.config.get('add_price_noise', True):
                sampled_data = self._add_price_noise(sampled_data, noise_level=0.001)
            
            # Запуск бэктеста
            try:
                backtest_result = backtest_func(
                    strategy_name=strategy_name,
                    historical_data=sampled_data,
                    strategy_params=varied_params,
                    initial_capital=initial_capital
                )
                
                results.append(backtest_result)
                
                if (i + 1) % 100 == 0:
                    logger.info(f"   Progress: {i + 1}/{n_simulations} simulations completed")
                
            except Exception as e:
                logger.error(f"   Simulation {i + 1} failed: {e}")
                continue
        
        # Анализ результатов
        mc_results = self._analyze_monte_carlo_results(strategy_name, n_simulations, results)
        
        self.simulations_run.append(mc_results)
        
        logger.info(f"✅ Monte Carlo completed: {len(results)}/{n_simulations} successful runs")
        logger.info(f"   Mean PnL: ${mc_results.mean_pnl:.2f} ± ${mc_results.std_pnl:.2f}")
        logger.info(f"   95% CI: [${mc_results.pnl_ci_95_lower:.2f}, ${mc_results.pnl_ci_95_upper:.2f}]")
        logger.info(f"   Probability of Profit: {mc_results.probability_of_profit:.1%}")
        logger.info(f"   Risk of Ruin: {mc_results.risk_of_ruin:.1%}")
        
        return mc_results
    
    def _vary_parameters(self, base_params: Dict, param_variations: Dict) -> Dict:
        """
        Вариация параметров стратегии
        
        Args:
            base_params: Базовые параметры
            param_variations: Диапазоны вариации {'param_name': (min, max)}
        
        Returns:
            Варьированные параметры
        """
        
        varied = base_params.copy()
        
        for param_name, (min_val, max_val) in param_variations.items():
            if param_name in base_params:
                # Равномерное распределение в диапазоне
                varied[param_name] = np.random.uniform(min_val, max_val)
        
        return varied
    
    def _bootstrap_resample(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Bootstrap resampling исторических данных
        
        Создает новую последовательность путем случайного выбора
        блоков данных с возвратом
        
        Args:
            data: Исходные данные
        
        Returns:
            Пересэмплированные данные
        """
        
        n = len(data)
        block_size = self.config.get('bootstrap_block_size', 20)  # Блоки по 20 свечей
        
        # Количество блоков
        n_blocks = n // block_size
        
        # Случайный выбор индексов блоков с возвратом
        block_indices = np.random.choice(n_blocks, size=n_blocks, replace=True)
        
        # Собираем данные из выбранных блоков
        resampled_blocks = []
        for block_idx in block_indices:
            start_idx = block_idx * block_size
            end_idx = min(start_idx + block_size, n)
            resampled_blocks.append(data.iloc[start_idx:end_idx])
        
        resampled_data = pd.concat(resampled_blocks, ignore_index=True)
        
        return resampled_data.head(n)  # Обрезаем до исходной длины
    
    def _add_price_noise(self, data: pd.DataFrame, noise_level: float = 0.001) -> pd.DataFrame:
        """
        Добавление случайного шума к ценам
        
        Args:
            data: Исходные данные
            noise_level: Уровень шума (0.001 = 0.1%)
        
        Returns:
            Данные с шумом
        """
        
        noisy_data = data.copy()
        
        # Генерируем мультипликативный шум (1 ± noise_level)
        noise = 1 + np.random.normal(0, noise_level, size=len(data))
        
        # Применяем к OHLC
        for col in ['open', 'high', 'low', 'close']:
            if col in noisy_data.columns:
                noisy_data[col] = noisy_data[col] * noise
        
        return noisy_data
    
    def _analyze_monte_carlo_results(self, strategy_name: str, 
                                     n_simulations: int, 
                                     results: List[Dict]) -> MonteCarloResults:
        """
        Анализ результатов Монте-Карло симуляций
        
        Args:
            strategy_name: Название стратегии
            n_simulations: Количество симуляций
            results: Список результатов бэктестов
        
        Returns:
            MonteCarloResults с агрегированной статистикой
        """
        
        if not results:
            logger.warning("No results to analyze")
            return MonteCarloResults(
                strategy_name=strategy_name,
                n_simulations=0,
                mean_pnl=0, median_pnl=0, std_pnl=0, min_pnl=0, max_pnl=0,
                pnl_ci_95_lower=0, pnl_ci_95_upper=0,
                win_rate_mean=0, win_rate_std=0,
                sharpe_ratio_mean=0, sharpe_ratio_std=0,
                max_drawdown_mean=0, max_drawdown_worst=0,
                probability_of_profit=0, risk_of_ruin=0,
                all_results=[]
            )
        
        # Извлекаем метрики
        pnls = np.array([r.get('total_pnl', 0) for r in results])
        win_rates = np.array([r.get('win_rate', 0) for r in results])
        sharpe_ratios = np.array([r.get('sharpe_ratio', 0) for r in results])
        max_drawdowns = np.array([r.get('max_drawdown', 0) for r in results])
        final_capitals = np.array([r.get('final_capital', 10000) for r in results])
        
        # Статистика PnL
        mean_pnl = np.mean(pnls)
        median_pnl = np.median(pnls)
        std_pnl = np.std(pnls)
        min_pnl = np.min(pnls)
        max_pnl = np.max(pnls)
        
        # 95% доверительный интервал
        pnl_ci_95_lower = np.percentile(pnls, 2.5)
        pnl_ci_95_upper = np.percentile(pnls, 97.5)
        
        # Win rate
        win_rate_mean = np.mean(win_rates)
        win_rate_std = np.std(win_rates)
        
        # Sharpe ratio
        sharpe_ratio_mean = np.mean(sharpe_ratios)
        sharpe_ratio_std = np.std(sharpe_ratios)
        
        # Max drawdown
        max_drawdown_mean = np.mean(max_drawdowns)
        max_drawdown_worst = np.max(max_drawdowns)
        
        # Probability of profit
        probability_of_profit = np.sum(pnls > 0) / len(pnls)
        
        # Risk of ruin (потеря >50% капитала)
        initial_capital = results[0].get('initial_capital', 10000)
        risk_of_ruin = np.sum(final_capitals < initial_capital * 0.5) / len(final_capitals)
        
        return MonteCarloResults(
            strategy_name=strategy_name,
            n_simulations=n_simulations,
            mean_pnl=mean_pnl,
            median_pnl=median_pnl,
            std_pnl=std_pnl,
            min_pnl=min_pnl,
            max_pnl=max_pnl,
            pnl_ci_95_lower=pnl_ci_95_lower,
            pnl_ci_95_upper=pnl_ci_95_upper,
            win_rate_mean=win_rate_mean,
            win_rate_std=win_rate_std,
            sharpe_ratio_mean=sharpe_ratio_mean,
            sharpe_ratio_std=sharpe_ratio_std,
            max_drawdown_mean=max_drawdown_mean,
            max_drawdown_worst=max_drawdown_worst,
            probability_of_profit=probability_of_profit,
            risk_of_ruin=risk_of_ruin,
            all_results=results
        )
    
    def sensitivity_analysis(self, 
                            backtest_func: Callable,
                            strategy_name: str,
                            base_params: Dict,
                            historical_data: pd.DataFrame,
                            param_name: str,
                            param_range: List[float],
                            initial_capital: float = 10000) -> Dict:
        """
        Анализ чувствительности к изменению одного параметра
        
        Args:
            backtest_func: Функция бэктестирования
            strategy_name: Название стратегии
            base_params: Базовые параметры
            historical_data: Исторические данные
            param_name: Название параметра для анализа
            param_range: Диапазон значений параметра
            initial_capital: Начальный капитал
        
        Returns:
            Dict с результатами для каждого значения параметра
        """
        
        logger.info(f"📊 Sensitivity Analysis: {param_name} across {len(param_range)} values")
        
        sensitivity_results = {
            'param_name': param_name,
            'param_values': param_range,
            'pnls': [],
            'win_rates': [],
            'sharpe_ratios': [],
            'max_drawdowns': []
        }
        
        for param_value in param_range:
            # Обновляем параметр
            test_params = base_params.copy()
            test_params[param_name] = param_value
            
            # Запускаем бэктест
            try:
                result = backtest_func(
                    strategy_name=strategy_name,
                    historical_data=historical_data,
                    strategy_params=test_params,
                    initial_capital=initial_capital
                )
                
                sensitivity_results['pnls'].append(result.get('total_pnl', 0))
                sensitivity_results['win_rates'].append(result.get('win_rate', 0))
                sensitivity_results['sharpe_ratios'].append(result.get('sharpe_ratio', 0))
                sensitivity_results['max_drawdowns'].append(result.get('max_drawdown', 0))
                
            except Exception as e:
                logger.error(f"   Failed for {param_name}={param_value}: {e}")
                sensitivity_results['pnls'].append(0)
                sensitivity_results['win_rates'].append(0)
                sensitivity_results['sharpe_ratios'].append(0)
                sensitivity_results['max_drawdowns'].append(0)
        
        # Находим оптимальное значение
        best_idx = np.argmax(sensitivity_results['pnls'])
        sensitivity_results['optimal_value'] = param_range[best_idx]
        sensitivity_results['optimal_pnl'] = sensitivity_results['pnls'][best_idx]
        
        logger.info(f"✅ Optimal {param_name}: {sensitivity_results['optimal_value']} "
                   f"(PnL: ${sensitivity_results['optimal_pnl']:.2f})")
        
        return sensitivity_results
    
    def get_simulations_summary(self) -> Dict:
        """Получение сводки по всем симуляциям"""
        
        return {
            'total_simulations': len(self.simulations_run),
            'strategies_tested': [s.strategy_name for s in self.simulations_run],
            'simulations': [
                {
                    'strategy': s.strategy_name,
                    'n_runs': s.n_simulations,
                    'mean_pnl': s.mean_pnl,
                    'probability_of_profit': s.probability_of_profit,
                    'risk_of_ruin': s.risk_of_ruin
                }
                for s in self.simulations_run
            ]
        }
