#!/usr/bin/env python3
"""
Integration Test Library - Библиотека комплексных интеграционных сценариев
Реализация из документа "Backtesting & Optimization Suite как Абсолютный Системный Отладчик"

Этот модуль реализует ключевую идею документа: тестирование полной причинно-следственной цепи
от сбора данных до исполнения сделки через все 22 модуля системы.
"""
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import pandas as pd
import numpy as np
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

@dataclass
class IntegrationTestResult:
    """Результат интеграционного теста"""
    scenario_name: str
    success: bool
    
    # Проверенные этапы
    stages_passed: List[str] = field(default_factory=list)
    stages_failed: List[str] = field(default_factory=list)
    
    # Детали выполнения
    execution_log: List[str] = field(default_factory=list)
    
    # Ожидаемые vs фактические значения
    expected_outcomes: Dict = field(default_factory=dict)
    actual_outcomes: Dict = field(default_factory=dict)
    
    # Метрики производительности
    execution_time_seconds: float = 0.0
    
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


class IntegrationTestLibrary:
    """
    Библиотека комплексных интеграционных тестов
    
    Каждый тест симулирует полную цепочку взаимодействий модулей:
    GENESIS → LPI → TRUTH ENGINE → FSM → AEGIS → Strategy → Executor
    
    Сценарии:
    1. test_liquidation_cascade_to_v_reversal - Каскад ликвидаций → V-REVERSAL вход
    2. test_flash_crash_protection - Flash crash → защитные механизмы AEGIS
    3. test_manipulation_squeeze_accumulate - Манипуляция → режим ACCUMULATE
    4. test_trend_impulse_grid_oracle - Тренд → GRID Oracle адаптация
    5. test_chaos_regime_detection - Высокий LPI → FSM CHAOS режим
    """
    
    def __init__(self, monolith):
        """
        Args:
            monolith: SuperBrainMonolith instance с всеми 22 модулями
        """
        self.monolith = monolith
        self.test_results = []
        
        logger.info("Integration Test Library initialized")
    
    async def test_liquidation_cascade_to_v_reversal(self, 
                                                     historical_data: pd.DataFrame,
                                                     inject_cascade: bool = True) -> IntegrationTestResult:
        """
        СЦЕНАРИЙ 1: Каскад ликвидаций → V-REVERSAL
        
        Полная цепочка:
        1. Инжектим резкое падение цены -15% за 5 минут (симуляция каскада ликвидаций)
        2. GENESIS рассчитывает индикаторы → высокий LPI (>0.9)
        3. LPI v2.0 детектирует давление ликвидности (C3 whale pressure высокий)
        4. TRUTH ENGINE выносит вердикт MANIPULATION_SQUEEZE
        5. FSM переходит в режим CHAOS (LPI > 0.8)
        6. AEGIS отслеживает просадку
        7. SmartDrawdownManager → режим ACCUMULATE
        8. V-REVERSAL ищет точку входа (6 этапов Kill Chain)
        9. JARVIS верифицирует сигнал
        10. Executor создает ордер
        
        Args:
            historical_data: Исторические данные
            inject_cascade: Инжектировать каскад или использовать реальные данные
        
        Returns:
            IntegrationTestResult с детальным логом
        """
        
        start_time = datetime.now()
        result = IntegrationTestResult(
            scenario_name="liquidation_cascade_to_v_reversal",
            success=False
        )
        
        logger.info("=" * 80)
        logger.info("🧪 INTEGRATION TEST: Liquidation Cascade → V-REVERSAL")
        logger.info("=" * 80)
        
        try:
            # ЭТАП 1: Инжекция каскада ликвидаций
            if inject_cascade:
                from utils.stress_test_scenarios import StressTestScenarios
                stress_tester = StressTestScenarios()
                
                # Падение -15% за 5 минут (симуляция каскада)
                test_data = stress_tester.inject_flash_crash_50pct(
                    historical_data,
                    duration_minutes=5
                )
                result.execution_log.append("✅ Stage 1: Cascade injected (-15% in 5 min)")
                result.stages_passed.append("cascade_injection")
            else:
                test_data = historical_data
                result.execution_log.append("⚠️ Stage 1: Using real data (no injection)")
            
            # ЭТАП 2: GENESIS расчет индикаторов
            logger.info("\n📊 Stage 2: GENESIS indicators calculation...")
            
            # Берем последние N свечей для анализа
            recent_data = test_data.tail(100)
            
            indicators = await self.monolith.genesis.calculate_all_indicators(recent_data)
            
            result.execution_log.append(f"✅ Stage 2: GENESIS calculated {len(indicators)} indicators")
            result.stages_passed.append("genesis_calculation")
            result.actual_outcomes['rsi'] = indicators.get('RSI_14', 0)
            result.actual_outcomes['atr'] = indicators.get('ATR_14', 0)
            result.actual_outcomes['adx'] = indicators.get('ADX_14', 0)
            
            # ЭТАП 3: LPI v2.0 расчет давления ликвидности
            logger.info("\n💧 Stage 3: LPI v2.0 liquidity pressure calculation...")
            
            snapshot = {
                'current_price': recent_data.iloc[-1]['close'],
                'volume': recent_data.iloc[-1]['volume'],
                'high': recent_data.iloc[-1]['high'],
                'low': recent_data.iloc[-1]['low']
            }
            
            lpi_data = self.monolith.lpi.calculate_lpi('BTC/USDT', snapshot, indicators)
            lpi_total = lpi_data.get('lpi_total', 0)
            
            result.execution_log.append(f"✅ Stage 3: LPI calculated = {lpi_total:.3f}")
            result.stages_passed.append("lpi_calculation")
            result.actual_outcomes['lpi_total'] = lpi_total
            result.actual_outcomes['lpi_c1'] = lpi_data.get('c1_structural', 0)
            result.actual_outcomes['lpi_c2'] = lpi_data.get('c2_risk', 0)
            result.actual_outcomes['lpi_c3'] = lpi_data.get('c3_whale', 0)
            result.actual_outcomes['lpi_c4'] = lpi_data.get('c4_microstructure', 0)
            
            # Проверка: LPI должен быть высоким при каскаде
            result.expected_outcomes['lpi_total'] = ">0.7"
            if lpi_total > 0.7:
                result.execution_log.append(f"✅ LPI check passed: {lpi_total:.3f} > 0.7")
            else:
                result.execution_log.append(f"⚠️ LPI lower than expected: {lpi_total:.3f}")
            
            # ЭТАП 4: TRUTH ENGINE вердикт
            logger.info("\n⚖️ Stage 4: TRUTH ENGINE verdict...")
            
            truth_result = self.monolith.truth_engine.analyze_market(indicators, lpi_data)
            verdict = truth_result.get('verdict', 'UNKNOWN')
            confidence = truth_result.get('confidence', 0)
            
            result.execution_log.append(f"✅ Stage 4: TRUTH ENGINE verdict = {verdict} ({confidence:.2f})")
            result.stages_passed.append("truth_engine_verdict")
            result.actual_outcomes['truth_verdict'] = verdict
            result.actual_outcomes['truth_confidence'] = confidence
            
            # Проверка: Ожидаем Manipulation_Squeeze при каскаде
            result.expected_outcomes['truth_verdict'] = "Manipulation_Squeeze"
            if verdict == "Manipulation_Squeeze":
                result.execution_log.append("✅ TRUTH ENGINE correctly identified manipulation")
            else:
                result.execution_log.append(f"⚠️ Unexpected verdict: {verdict}")
            
            # ЭТАП 5: FSM определение режима
            logger.info("\n🔄 Stage 5: FSM regime detection...")
            
            fsm_result = self.monolith.fsm.determine_regime(indicators, lpi_total)
            regime = fsm_result.get('regime', 'UNKNOWN')
            
            result.execution_log.append(f"✅ Stage 5: FSM regime = {regime}")
            result.stages_passed.append("fsm_regime")
            result.actual_outcomes['fsm_regime'] = regime
            
            # Проверка: При LPI > 0.8 ожидаем CHAOS
            result.expected_outcomes['fsm_regime'] = "CHAOS (if LPI > 0.8)"
            if lpi_total > 0.8 and regime == "CHAOS":
                result.execution_log.append("✅ FSM correctly switched to CHAOS")
            elif lpi_total <= 0.8:
                result.execution_log.append(f"ℹ️ LPI {lpi_total:.3f} <= 0.8, CHAOS not expected")
            else:
                result.execution_log.append(f"⚠️ LPI {lpi_total:.3f} > 0.8 but regime is {regime}")
            
            # ЭТАП 6: AEGIS проверка лимитов
            logger.info("\n🛡️ Stage 6: AEGIS risk limits check...")
            
            aegis_check = self.monolith.aegis.check_progressive_grid_limits(
                symbol='BTC',
                current_levels=5,
                total_exposure_usd=5000,
                step_multiplier=1.0
            )
            
            result.execution_log.append(f"✅ Stage 6: AEGIS check = {aegis_check.get('approved', False)}")
            result.stages_passed.append("aegis_check")
            result.actual_outcomes['aegis_approved'] = aegis_check.get('approved', False)
            
            # ЭТАП 7: SmartDrawdownManager режим
            logger.info("\n📉 Stage 7: SmartDrawdownManager mode determination...")
            
            dd_result = self.monolith.drawdown_manager.analyze_drawdown(
                current_dd=0.05,  # 5% просадка
                truth_verdict=verdict,
                confidence=confidence,
                asset='BTC',
                accumulated_profit=0.0
            )
            
            dd_mode = dd_result.get('mode', 'UNKNOWN')
            dd_action = dd_result.get('action', 'UNKNOWN')
            
            result.execution_log.append(f"✅ Stage 7: SmartDrawdown mode = {dd_mode}, action = {dd_action}")
            result.stages_passed.append("smartdrawdown_mode")
            result.actual_outcomes['drawdown_mode'] = dd_mode
            result.actual_outcomes['drawdown_action'] = dd_action
            
            # Проверка: При Manipulation_Squeeze ожидаем ACCUMULATE
            result.expected_outcomes['drawdown_mode'] = "ACCUMULATE (if Manipulation_Squeeze)"
            if verdict == "Manipulation_Squeeze" and dd_mode == "ACCUMULATE":
                result.execution_log.append("✅ SmartDrawdown correctly switched to ACCUMULATE")
            elif verdict != "Manipulation_Squeeze":
                result.execution_log.append(f"ℹ️ Verdict is {verdict}, ACCUMULATE not expected")
            else:
                result.execution_log.append(f"⚠️ Expected ACCUMULATE but got {dd_mode}")
            
            # ЭТАП 8: V-REVERSAL детекция сигнала
            logger.info("\n🔄 Stage 8: V-REVERSAL signal detection...")
            
            # AUTO_FIB для Fibonacci уровней
            fib_data = self.monolith.auto_fib.calculate_fibonacci_levels(recent_data)
            
            # V-REVERSAL детекция
            v_reversal_signal = self.monolith.v_reversal.detect_reversal(
                indicators,
                verdict,
                fib_data,
                lpi_data
            )
            
            if v_reversal_signal:
                result.execution_log.append(f"✅ Stage 8: V-REVERSAL signal detected! Type: {v_reversal_signal.reversal_type.value}")
                result.stages_passed.append("v_reversal_signal")
                result.actual_outcomes['v_reversal_detected'] = True
                result.actual_outcomes['v_reversal_type'] = v_reversal_signal.reversal_type.value
                result.actual_outcomes['v_reversal_confidence'] = v_reversal_signal.confidence
            else:
                result.execution_log.append("⚠️ Stage 8: V-REVERSAL did not generate signal")
                result.stages_failed.append("v_reversal_signal")
                result.actual_outcomes['v_reversal_detected'] = False
            
            # ЭТАП 9: JARVIS верификация
            if v_reversal_signal:
                logger.info("\n🧠 Stage 9: JARVIS cognitive verification...")
                
                market_context = {
                    'fsm_regime': regime,
                    'RSI': indicators.get('RSI_14', 50),
                    'ADX': indicators.get('ADX_14', 25),
                    'volatility': 'HIGH'
                }
                
                # Конвертируем dataclass в dict
                signal_dict = {
                    'type': v_reversal_signal.reversal_type.value,
                    'confidence': v_reversal_signal.confidence,
                    'entry_zone': v_reversal_signal.entry_zone,
                    'lpi_score': v_reversal_signal.lpi_score,
                    'rci_score': v_reversal_signal.rci_score
                }
                
                jarvis_decision = self.monolith.jarvis.analyze_signal_with_llm(
                    signal_dict,
                    verdict,
                    market_context
                )
                
                jarvis_approved = jarvis_decision.get('approved', False)
                result.execution_log.append(f"✅ Stage 9: JARVIS {'approved' if jarvis_approved else 'vetoed'} signal")
                result.stages_passed.append("jarvis_verification")
                result.actual_outcomes['jarvis_approved'] = jarvis_approved
                result.actual_outcomes['jarvis_reasoning'] = jarvis_decision.get('reasoning', '')
                
                # ЭТАП 10: Executor создание ордера
                if jarvis_approved:
                    logger.info("\n⚡ Stage 10: Executor order creation...")
                    
                    test_order = await self.monolith.executor.create_order(
                        'BTC',
                        'BUY',
                        'MARKET',
                        0.01,
                        price=snapshot['current_price']
                    )
                    
                    result.execution_log.append(f"✅ Stage 10: Order created: {test_order.get('order_id', 'N/A')}")
                    result.stages_passed.append("executor_order")
                    result.actual_outcomes['order_created'] = True
                    result.actual_outcomes['order_id'] = test_order.get('order_id', '')
                    
                    # ВСЕ ЭТАПЫ ПРОЙДЕНЫ!
                    result.success = True
                    result.execution_log.append("\n🎉 ALL STAGES PASSED! Full chain verified.")
                else:
                    result.execution_log.append("⚠️ JARVIS vetoed signal, order not created")
                    result.stages_failed.append("executor_order")
            else:
                result.execution_log.append("⚠️ No V-REVERSAL signal, skipping JARVIS and Executor")
                result.stages_failed.append("jarvis_verification")
                result.stages_failed.append("executor_order")
            
        except Exception as e:
            logger.error(f"❌ Integration test failed: {e}", exc_info=True)
            result.execution_log.append(f"❌ ERROR: {str(e)}")
            result.success = False
        
        # Финализация
        end_time = datetime.now()
        result.execution_time_seconds = (end_time - start_time).total_seconds()
        
        self.test_results.append(result)
        
        logger.info("\n" + "=" * 80)
        logger.info(f"TEST RESULT: {'✅ SUCCESS' if result.success else '❌ FAILED'}")
        logger.info(f"Stages passed: {len(result.stages_passed)}/{len(result.stages_passed) + len(result.stages_failed)}")
        logger.info(f"Execution time: {result.execution_time_seconds:.2f}s")
        logger.info("=" * 80)
        
        return result
    
    async def test_flash_crash_protection(self, historical_data: pd.DataFrame) -> IntegrationTestResult:
        """
        СЦЕНАРИЙ 2: Flash Crash → Защитные механизмы AEGIS
        
        Цепочка:
        1. Инжектим flash crash -50% за 1 минуту
        2. GENESIS → экстремальные индикаторы (RSI<10, ATR 5x)
        3. AEGIS должен заблокировать новые сделки
        4. SmartDrawdownManager → режим PROTECT
        5. Все стратегии должны быть приостановлены
        """
        
        start_time = datetime.now()
        result = IntegrationTestResult(
            scenario_name="flash_crash_protection",
            success=False
        )
        
        logger.info("🧪 INTEGRATION TEST: Flash Crash Protection")
        
        try:
            # Инжектим flash crash
            from utils.stress_test_scenarios import StressTestScenarios
            stress_tester = StressTestScenarios()
            
            test_data = stress_tester.inject_flash_crash_50pct(
                historical_data,
                duration_minutes=1
            )
            result.execution_log.append("✅ Flash crash injected (-50%)")
            result.stages_passed.append("flash_crash_injection")
            
            # GENESIS индикаторы
            recent_data = test_data.tail(100)
            indicators = await self.monolith.genesis.calculate_all_indicators(recent_data)
            
            rsi = indicators.get('RSI_14', 50)
            result.execution_log.append(f"✅ RSI during crash: {rsi:.1f}")
            result.stages_passed.append("genesis_extreme_indicators")
            result.actual_outcomes['rsi_crash'] = rsi
            
            # Проверка: RSI должен быть экстремально низким
            result.expected_outcomes['rsi_crash'] = "<20"
            if rsi < 20:
                result.execution_log.append("✅ RSI correctly shows extreme oversold")
            
            # AEGIS блокировка
            aegis_check = self.monolith.aegis.check_progressive_grid_limits(
                symbol='BTC',
                current_levels=10,
                total_exposure_usd=15000,  # Высокая экспозиция
                step_multiplier=2.0  # Агрессивный множитель
            )
            
            aegis_approved = aegis_check.get('approved', True)
            result.execution_log.append(f"✅ AEGIS decision: {'BLOCKED' if not aegis_approved else 'ALLOWED'}")
            result.stages_passed.append("aegis_protection")
            result.actual_outcomes['aegis_blocked'] = not aegis_approved
            
            # Проверка: AEGIS должен заблокировать
            result.expected_outcomes['aegis_blocked'] = True
            if not aegis_approved:
                result.execution_log.append("✅ AEGIS correctly blocked excessive exposure")
                result.success = True
            else:
                result.execution_log.append("⚠️ AEGIS did not block (may be within limits)")
            
        except Exception as e:
            logger.error(f"❌ Test failed: {e}")
            result.execution_log.append(f"❌ ERROR: {str(e)}")
        
        end_time = datetime.now()
        result.execution_time_seconds = (end_time - start_time).total_seconds()
        self.test_results.append(result)
        
        return result
    
    async def test_manipulation_squeeze_accumulate(self, historical_data: pd.DataFrame) -> IntegrationTestResult:
        """
        СЦЕНАРИЙ 3: Манипуляция Squeeze → Режим ACCUMULATE
        
        Цепочка:
        1. Симулируем манипуляцию (высокий LPI, низкий объем)
        2. TRUTH ENGINE → MANIPULATION_SQUEEZE
        3. SmartDrawdownManager → ACCUMULATE
        4. Проверяем multipliers: grid_density_mult > 1.0
        """
        
        start_time = datetime.now()
        result = IntegrationTestResult(
            scenario_name="manipulation_squeeze_accumulate",
            success=False
        )
        
        logger.info("🧪 INTEGRATION TEST: Manipulation Squeeze → ACCUMULATE")
        
        try:
            # Симулируем манипуляцию через высокий LPI
            recent_data = historical_data.tail(100)
            indicators = await self.monolith.genesis.calculate_all_indicators(recent_data)
            
            # Искусственно повышаем LPI для теста
            lpi_data = {
                'lpi_total': 0.92,  # Очень высокий
                'c1_structural': 0.85,
                'c2_risk': 0.90,
                'c3_whale': 0.95,  # Высокое давление китов
                'c4_microstructure': 0.88
            }
            
            result.execution_log.append(f"✅ Simulated high LPI: {lpi_data['lpi_total']:.2f}")
            result.stages_passed.append("lpi_simulation")
            
            # TRUTH ENGINE
            truth_result = self.monolith.truth_engine.analyze_market(indicators, lpi_data)
            verdict = truth_result.get('verdict', '')
            
            result.execution_log.append(f"✅ TRUTH ENGINE verdict: {verdict}")
            result.stages_passed.append("truth_manipulation_detection")
            result.actual_outcomes['truth_verdict'] = verdict
            
            # SmartDrawdownManager
            dd_result = self.monolith.drawdown_manager.analyze_drawdown(
                current_dd=0.08,
                truth_verdict=verdict,
                confidence=0.85,
                asset='BTC',
                accumulated_profit=0.0
            )
            
            dd_mode = dd_result.get('mode', '')
            grid_density_mult = dd_result.get('grid_density_mult', 1.0)
            
            result.execution_log.append(f"✅ SmartDrawdown mode: {dd_mode}")
            result.execution_log.append(f"✅ Grid density multiplier: {grid_density_mult:.2f}x")
            result.stages_passed.append("accumulate_mode")
            result.actual_outcomes['drawdown_mode'] = dd_mode
            result.actual_outcomes['grid_density_mult'] = grid_density_mult
            
            # Проверка: При Manipulation_Squeeze ожидаем ACCUMULATE
            if verdict == "Manipulation_Squeeze" and dd_mode == "ACCUMULATE":
                result.execution_log.append("✅ System correctly switched to ACCUMULATE mode")
                result.success = True
            else:
                result.execution_log.append(f"⚠️ Expected ACCUMULATE, got {dd_mode}")
            
        except Exception as e:
            logger.error(f"❌ Test failed: {e}")
            result.execution_log.append(f"❌ ERROR: {str(e)}")
        
        end_time = datetime.now()
        result.execution_time_seconds = (end_time - start_time).total_seconds()
        self.test_results.append(result)
        
        return result
    
    def get_test_summary(self) -> Dict:
        """Получение сводки по всем тестам"""
        
        total_tests = len(self.test_results)
        passed_tests = sum(1 for t in self.test_results if t.success)
        
        return {
            'total_tests': total_tests,
            'passed': passed_tests,
            'failed': total_tests - passed_tests,
            'success_rate': (passed_tests / total_tests * 100) if total_tests > 0 else 0,
            'tests': [
                {
                    'scenario': t.scenario_name,
                    'success': t.success,
                    'stages_passed': len(t.stages_passed),
                    'stages_failed': len(t.stages_failed),
                    'execution_time': t.execution_time_seconds
                }
                for t in self.test_results
            ]
        }
