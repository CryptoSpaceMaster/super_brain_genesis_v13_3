#!/usr/bin/env python3
"""
Stress Test Scenarios - Модуль симуляции экстремальных рыночных событий
Реализация из документа "Backtesting & Optimization Suite как Абсолютный Системный Отладчик"
"""
import logging
from typing import Dict, List, Tuple
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

class StressTestScenarios:
    """
    Модуль для симуляции экстремальных рыночных событий
    
    Сценарии:
    - flash_crash_50pct: Резкое падение на 50% за 1-5 минут
    - prolonged_bear_market: Длительный медвежий рынок -60% за 3 месяца
    - exchange_outage: Симуляция недоступности биржи
    - volatility_spike: Резкий всплеск волатильности
    - liquidity_crisis: Кризис ликвидности
    """
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.scenarios_run = []
        
        logger.info("Stress Test Scenarios initialized")
    
    def inject_flash_crash_50pct(self, data: pd.DataFrame, 
                                 crash_start_idx: int = None,
                                 duration_minutes: int = 5) -> pd.DataFrame:
        """
        Симуляция Flash Crash -50% за N минут
        
        Args:
            data: Исторические OHLCV данные
            crash_start_idx: Индекс начала краха (None = случайный)
            duration_minutes: Длительность падения в минутах
        
        Returns:
            Модифицированные данные с flash crash
        """
        
        if len(data) < duration_minutes + 10:
            logger.warning("Insufficient data for flash crash injection")
            return data
        
        modified_data = data.copy()
        
        # Случайный индекс начала краха (в середине датасета)
        if crash_start_idx is None:
            crash_start_idx = np.random.randint(len(data) // 4, 3 * len(data) // 4)
        
        # Параметры краха
        crash_depth = 0.50  # -50%
        recovery_percent = 0.30  # Восстановление +30% от минимума
        
        # Цена до краха
        pre_crash_price = modified_data.iloc[crash_start_idx]['close']
        crash_low = pre_crash_price * (1 - crash_depth)
        recovery_price = crash_low * (1 + recovery_percent)
        
        logger.info(f"💥 Injecting Flash Crash: -{crash_depth:.0%} from ${pre_crash_price:.2f} to ${crash_low:.2f}")
        
        # Падение (crash_start_idx -> crash_start_idx + duration_minutes)
        for i in range(duration_minutes):
            idx = crash_start_idx + i
            if idx >= len(modified_data):
                break
            
            # Прогрессивное падение
            progress = (i + 1) / duration_minutes
            current_price = pre_crash_price - (pre_crash_price - crash_low) * progress
            
            # Модифицируем OHLCV
            modified_data.at[modified_data.index[idx], 'open'] = pre_crash_price - (pre_crash_price - crash_low) * (i / duration_minutes)
            modified_data.at[modified_data.index[idx], 'high'] = modified_data.iloc[idx]['open'] * 1.005
            modified_data.at[modified_data.index[idx], 'low'] = current_price * 0.98
            modified_data.at[modified_data.index[idx], 'close'] = current_price
            modified_data.at[modified_data.index[idx], 'volume'] = modified_data.iloc[idx]['volume'] * (3 + progress * 5)  # Огромный объем
        
        # Восстановление (duration_minutes -> duration_minutes + 10)
        recovery_duration = 10
        for i in range(recovery_duration):
            idx = crash_start_idx + duration_minutes + i
            if idx >= len(modified_data):
                break
            
            progress = (i + 1) / recovery_duration
            current_price = crash_low + (recovery_price - crash_low) * progress
            
            modified_data.at[modified_data.index[idx], 'open'] = modified_data.iloc[idx - 1]['close']
            modified_data.at[modified_data.index[idx], 'high'] = current_price * 1.01
            modified_data.at[modified_data.index[idx], 'low'] = current_price * 0.99
            modified_data.at[modified_data.index[idx], 'close'] = current_price
            modified_data.at[modified_data.index[idx], 'volume'] = modified_data.iloc[idx]['volume'] * (2 - progress)
        
        self.scenarios_run.append({
            'type': 'flash_crash_50pct',
            'crash_start_idx': crash_start_idx,
            'duration_minutes': duration_minutes,
            'pre_crash_price': pre_crash_price,
            'crash_low': crash_low,
            'recovery_price': recovery_price,
            'timestamp': datetime.now().isoformat()
        })
        
        logger.info(f"✅ Flash Crash injected: indices {crash_start_idx} to {crash_start_idx + duration_minutes + recovery_duration}")
        
        return modified_data
    
    def inject_prolonged_bear_market(self, data: pd.DataFrame,
                                     bear_start_idx: int = None,
                                     duration_days: int = 90,
                                     total_drawdown: float = 0.60) -> pd.DataFrame:
        """
        Симуляция длительного медвежьего рынка -60% за 3 месяца
        
        Args:
            data: Исторические OHLCV данные
            bear_start_idx: Индекс начала падения (None = начало датасета)
            duration_days: Длительность медвежьего рынка (дней)
            total_drawdown: Общая просадка (0.60 = -60%)
        
        Returns:
            Модифицированные данные с prolonged bear market
        """
        
        if len(data) < duration_days:
            logger.warning("Insufficient data for prolonged bear market injection")
            return data
        
        modified_data = data.copy()
        
        if bear_start_idx is None:
            bear_start_idx = 0
        
        # Цена до начала медвежьего рынка
        start_price = modified_data.iloc[bear_start_idx]['close']
        end_price = start_price * (1 - total_drawdown)
        
        logger.info(f"🐻 Injecting Prolonged Bear Market: -{total_drawdown:.0%} over {duration_days} days")
        logger.info(f"   From ${start_price:.2f} to ${end_price:.2f}")
        
        # Постепенное падение с откатами
        for i in range(duration_days):
            idx = bear_start_idx + i
            if idx >= len(modified_data):
                break
            
            # Прогресс падения с волнами
            base_progress = i / duration_days
            
            # Добавляем волны (откаты) через синусоиду
            wave = np.sin(base_progress * 4 * np.pi) * 0.1  # ±10% откаты
            effective_progress = base_progress + wave * (1 - base_progress)
            effective_progress = np.clip(effective_progress, 0, 1)
            
            current_price = start_price - (start_price - end_price) * effective_progress
            
            # Модифицируем OHLCV
            prev_close = modified_data.iloc[idx - 1]['close'] if idx > 0 else start_price
            
            # Дневная волатильность увеличивается с прогрессом
            daily_volatility = 0.02 + (0.05 * effective_progress)
            
            modified_data.at[modified_data.index[idx], 'open'] = prev_close
            modified_data.at[modified_data.index[idx], 'high'] = current_price * (1 + daily_volatility)
            modified_data.at[modified_data.index[idx], 'low'] = current_price * (1 - daily_volatility * 1.5)
            modified_data.at[modified_data.index[idx], 'close'] = current_price
            modified_data.at[modified_data.index[idx], 'volume'] = modified_data.iloc[idx]['volume'] * (0.7 + effective_progress * 0.6)
        
        self.scenarios_run.append({
            'type': 'prolonged_bear_market',
            'bear_start_idx': bear_start_idx,
            'duration_days': duration_days,
            'total_drawdown': total_drawdown,
            'start_price': start_price,
            'end_price': end_price,
            'timestamp': datetime.now().isoformat()
        })
        
        logger.info(f"✅ Prolonged Bear Market injected: indices {bear_start_idx} to {bear_start_idx + duration_days}")
        
        return modified_data
    
    def inject_exchange_outage(self, data: pd.DataFrame,
                               outage_start_idx: int = None,
                               duration_minutes: int = 30) -> Tuple[pd.DataFrame, List[int]]:
        """
        Симуляция недоступности биржи
        
        Args:
            data: Исторические OHLCV данные
            outage_start_idx: Индекс начала сбоя (None = случайный)
            duration_minutes: Длительность сбоя в минутах
        
        Returns:
            Tuple: (модифицированные данные, список индексов с outage)
        """
        
        if len(data) < duration_minutes + 10:
            logger.warning("Insufficient data for exchange outage injection")
            return data, []
        
        modified_data = data.copy()
        
        if outage_start_idx is None:
            outage_start_idx = np.random.randint(len(data) // 3, 2 * len(data) // 3)
        
        outage_indices = list(range(outage_start_idx, min(outage_start_idx + duration_minutes, len(data))))
        
        logger.info(f"🔌 Injecting Exchange Outage: {duration_minutes} minutes starting at index {outage_start_idx}")
        
        # Во время outage:
        # - Цены "замораживаются" (последняя доступная)
        # - Объем = 0 (невозможность торговать)
        # - Или резкое расхождение цены после восстановления
        
        freeze_price = modified_data.iloc[outage_start_idx - 1]['close'] if outage_start_idx > 0 else modified_data.iloc[0]['close']
        
        for idx in outage_indices:
            # Замораживаем цену
            modified_data.at[modified_data.index[idx], 'open'] = freeze_price
            modified_data.at[modified_data.index[idx], 'high'] = freeze_price
            modified_data.at[modified_data.index[idx], 'low'] = freeze_price
            modified_data.at[modified_data.index[idx], 'close'] = freeze_price
            modified_data.at[modified_data.index[idx], 'volume'] = 0  # Нет торгов
        
        # После восстановления - gap (расхождение цены)
        recovery_idx = outage_start_idx + duration_minutes
        if recovery_idx < len(modified_data):
            gap_percent = np.random.uniform(-0.05, 0.05)  # ±5% gap
            recovery_price = freeze_price * (1 + gap_percent)
            
            modified_data.at[modified_data.index[recovery_idx], 'open'] = recovery_price
            modified_data.at[modified_data.index[recovery_idx], 'close'] = recovery_price * (1 - gap_percent * 0.5)
            modified_data.at[modified_data.index[recovery_idx], 'volume'] = modified_data.iloc[recovery_idx]['volume'] * 3  # Всплеск объема
            
            logger.info(f"   Gap after recovery: {gap_percent:+.1%}")
        
        self.scenarios_run.append({
            'type': 'exchange_outage',
            'outage_start_idx': outage_start_idx,
            'duration_minutes': duration_minutes,
            'freeze_price': freeze_price,
            'outage_indices': outage_indices,
            'timestamp': datetime.now().isoformat()
        })
        
        logger.info(f"✅ Exchange Outage injected: {len(outage_indices)} indices affected")
        
        return modified_data, outage_indices
    
    def inject_volatility_spike(self, data: pd.DataFrame,
                               spike_start_idx: int = None,
                               duration_hours: int = 4,
                               volatility_multiplier: float = 5.0) -> pd.DataFrame:
        """
        Симуляция резкого всплеска волатильности
        
        Args:
            data: Исторические OHLCV данные
            spike_start_idx: Индекс начала всплеска (None = случайный)
            duration_hours: Длительность всплеска в часах
            volatility_multiplier: Множитель волатильности (5.0 = в 5 раз выше)
        
        Returns:
            Модифицированные данные с volatility spike
        """
        
        if len(data) < duration_hours + 10:
            logger.warning("Insufficient data for volatility spike injection")
            return data
        
        modified_data = data.copy()
        
        if spike_start_idx is None:
            spike_start_idx = np.random.randint(len(data) // 4, 3 * len(data) // 4)
        
        logger.info(f"📈 Injecting Volatility Spike: {volatility_multiplier}x for {duration_hours} hours")
        
        for i in range(duration_hours):
            idx = spike_start_idx + i
            if idx >= len(modified_data):
                break
            
            # Базовая волатильность
            base_range = (modified_data.iloc[idx]['high'] - modified_data.iloc[idx]['low']) / modified_data.iloc[idx]['close']
            enhanced_range = base_range * volatility_multiplier
            
            current_close = modified_data.iloc[idx]['close']
            
            # Расширяем диапазон
            new_high = current_close * (1 + enhanced_range / 2)
            new_low = current_close * (1 - enhanced_range / 2)
            
            modified_data.at[modified_data.index[idx], 'high'] = new_high
            modified_data.at[modified_data.index[idx], 'low'] = new_low
            modified_data.at[modified_data.index[idx], 'volume'] = modified_data.iloc[idx]['volume'] * (1 + volatility_multiplier * 0.3)
        
        self.scenarios_run.append({
            'type': 'volatility_spike',
            'spike_start_idx': spike_start_idx,
            'duration_hours': duration_hours,
            'volatility_multiplier': volatility_multiplier,
            'timestamp': datetime.now().isoformat()
        })
        
        logger.info(f"✅ Volatility Spike injected: indices {spike_start_idx} to {spike_start_idx + duration_hours}")
        
        return modified_data
    
    def inject_liquidity_crisis(self, data: pd.DataFrame,
                               crisis_start_idx: int = None,
                               duration_days: int = 7) -> pd.DataFrame:
        """
        Симуляция кризиса ликвидности
        
        Args:
            data: Исторические OHLCV данные
            crisis_start_idx: Индекс начала кризиса (None = случайный)
            duration_days: Длительность кризиса в днях
        
        Returns:
            Модифицированные данные с liquidity crisis
        """
        
        if len(data) < duration_days:
            logger.warning("Insufficient data for liquidity crisis injection")
            return data
        
        modified_data = data.copy()
        
        if crisis_start_idx is None:
            crisis_start_idx = np.random.randint(len(data) // 4, 3 * len(data) // 4)
        
        logger.info(f"💧 Injecting Liquidity Crisis: {duration_days} days")
        
        for i in range(duration_days):
            idx = crisis_start_idx + i
            if idx >= len(modified_data):
                break
            
            # Резкое снижение объема (ликвидности)
            liquidity_factor = 0.2 - (i / duration_days) * 0.1  # 20% -> 10% от нормального объема
            
            # Увеличение спреда bid-ask
            spread_multiplier = 2 + (i / duration_days) * 3  # 2x -> 5x обычного спреда
            
            current_close = modified_data.iloc[idx]['close']
            normal_spread = (modified_data.iloc[idx]['high'] - modified_data.iloc[idx]['low']) / current_close
            enhanced_spread = normal_spread * spread_multiplier
            
            modified_data.at[modified_data.index[idx], 'volume'] = modified_data.iloc[idx]['volume'] * liquidity_factor
            modified_data.at[modified_data.index[idx], 'high'] = current_close * (1 + enhanced_spread / 2)
            modified_data.at[modified_data.index[idx], 'low'] = current_close * (1 - enhanced_spread / 2)
        
        self.scenarios_run.append({
            'type': 'liquidity_crisis',
            'crisis_start_idx': crisis_start_idx,
            'duration_days': duration_days,
            'timestamp': datetime.now().isoformat()
        })
        
        logger.info(f"✅ Liquidity Crisis injected: indices {crisis_start_idx} to {crisis_start_idx + duration_days}")
        
        return modified_data
    
    def get_scenarios_summary(self) -> Dict:
        """Получение сводки по запущенным сценариям"""
        
        return {
            'total_scenarios_run': len(self.scenarios_run),
            'scenarios': self.scenarios_run,
            'types': {
                'flash_crash': sum(1 for s in self.scenarios_run if s['type'] == 'flash_crash_50pct'),
                'bear_market': sum(1 for s in self.scenarios_run if s['type'] == 'prolonged_bear_market'),
                'exchange_outage': sum(1 for s in self.scenarios_run if s['type'] == 'exchange_outage'),
                'volatility_spike': sum(1 for s in self.scenarios_run if s['type'] == 'volatility_spike'),
                'liquidity_crisis': sum(1 for s in self.scenarios_run if s['type'] == 'liquidity_crisis')
            }
        }
