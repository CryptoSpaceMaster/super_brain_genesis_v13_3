#!/usr/bin/env python3
"""
Unified Backtest Scheduler - ТОЧНО ПО СПЕЦИФИКАЦИИ
Автоматический планировщик бэктестирования (hourly/daily/weekly/monthly)
"""
import asyncio
import logging
from typing import Dict, Optional
from datetime import datetime, timedelta
import time

logger = logging.getLogger(__name__)

class UnifiedBacktestScheduler:
    """
    ЕДИНЫЙ планировщик для всех типов бэктестирования
    ТОЧНО ПО СПЕЦИФИКАЦИИ
    """
    
    def __init__(self, monolith):
        """
        Args:
            monolith: SuperBrainMonolith instance
        """
        self.monolith = monolith
        self.running = False
        
        # Интервалы (в секундах)
        self.intervals = {
            'hourly': 3600,      # 1 час
            'daily': 86400,      # 24 часа
            'weekly': 604800,    # 7 дней
            'monthly': 2592000   # 30 дней
        }
        
        # Счетчики для отслеживания
        self.last_run = {
            'hourly': None,
            'daily': None,
            'weekly': None,
            'monthly': None
        }
        
        logger.info("Unified Backtest Scheduler initialized")
    
    async def start(self):
        """Запуск всех запланированных задач"""
        
        logger.info("=" * 80)
        logger.info("🔄 UNIFIED BACKTEST SCHEDULER: ЗАПУСК")
        logger.info("=" * 80)
        
        self.running = True
        
        # Запуск всех циклов параллельно
        tasks = [
            self._hourly_loop(),
            self._daily_loop(),
            self._weekly_loop(),
            self._monthly_loop()
        ]
        
        await asyncio.gather(*tasks, return_exceptions=True)
    
    async def stop(self):
        """Остановка планировщика"""
        self.running = False
        logger.info("Unified Backtest Scheduler stopped")
    
    async def _hourly_loop(self):
        """Каждый час - быстрая валидация (существующий метод)"""
        
        while self.running:
            try:
                logger.info("⏰ Hourly: Quick Validation")
                
                # Вызов существующего метода из BacktestingSuite
                if hasattr(self.monolith, 'backtesting'):
                    results = self.monolith.backtesting.run_backtest(
                        strategy_name='quick_validation',
                        historical_data=self._get_recent_data(hours=1),
                        strategy_params={},
                        initial_capital=1000
                    )
                    
                    # Проверка деградации
                    if results.get('win_rate', 100) < 40:
                        logger.warning(f"⚠️ Performance degradation detected: WR={results['win_rate']:.1f}%")
                
                self.last_run['hourly'] = datetime.now()
                
            except Exception as e:
                logger.error(f"❌ Hourly loop error: {e}")
            
            await asyncio.sleep(self.intervals['hourly'])
    
    async def _daily_loop(self):
        """Каждый день - бэктест с SMC"""
        
        while self.running:
            try:
                logger.info("📅 Daily: SMC-Enhanced Backtest")
                
                # Получение SMC Integrated Engine
                if hasattr(self.monolith, 'smc_integrated_backtest'):
                    smc_engine = self.monolith.smc_integrated_backtest
                    
                    # Бэктест топ-стратегий с SMC
                    for strategy_name in ['grid_oracle', 'v_reversal', 'scalping']:
                        results = smc_engine.run_smc_enhanced_backtest(
                            strategy_name=strategy_name,
                            historical_data=self._get_recent_data(days=7),
                            strategy_params={},
                            initial_capital=10000
                        )
                        
                        logger.info(f"   {strategy_name}: Sharpe improvement {results['improvement']['sharpe_improvement_pct']:.1f}%")
                
                self.last_run['daily'] = datetime.now()
                
            except Exception as e:
                logger.error(f"❌ Daily loop error: {e}")
            
            await asyncio.sleep(self.intervals['daily'])
    
    async def _weekly_loop(self):
        """Каждую неделю - оптимизация параметров"""
        
        while self.running:
            try:
                logger.info("📊 Weekly: Parameter Optimization")
                
                # Walk-Forward оптимизация
                if hasattr(self.monolith, 'backtesting'):
                    optimization_results = self.monolith.backtesting.optimize_parameters(
                        strategy_name='grid_oracle',
                        historical_data=self._get_recent_data(days=30),
                        param_space={
                            'grid_levels': [3, 5, 7, 10],
                            'spacing_pct': [0.003, 0.005, 0.01]
                        }
                    )
                    
                    # Автоматическое применение лучших параметров
                    await self._apply_optimization_results(optimization_results)
                
                self.last_run['weekly'] = datetime.now()
                
            except Exception as e:
                logger.error(f"❌ Weekly loop error: {e}")
            
            await asyncio.sleep(self.intervals['weekly'])
    
    async def _monthly_loop(self):
        """Каждый месяц - полный comprehensive backtest"""
        
        while self.running:
            try:
                logger.info("🗓️ Monthly: Full Comprehensive Backtest")
                
                # Полный бэктест всех стратегий
                if hasattr(self.monolith, 'backtesting'):
                    all_results = {}
                    
                    strategies = ['grid_oracle', 'v_reversal', 'scalping']
                    
                    for strategy in strategies:
                        results = self.monolith.backtesting.run_backtest(
                            strategy_name=strategy,
                            historical_data=self._get_recent_data(days=90),
                            strategy_params={},
                            initial_capital=10000
                        )
                        all_results[strategy] = results
                    
                    # Сравнение стратегий
                    comparison = self.monolith.backtesting.compare_strategies(all_results)
                    
                    logger.info(f"   Best strategy: {comparison.get('best_strategy', 'N/A')}")
                    logger.info(f"   Best Sharpe: {comparison.get('best_sharpe', 0):.2f}")
                
                self.last_run['monthly'] = datetime.now()
                
            except Exception as e:
                logger.error(f"❌ Monthly loop error: {e}")
            
            await asyncio.sleep(self.intervals['monthly'])
    
    def _get_recent_data(self, hours: int = 0, days: int = 0) -> 'pd.DataFrame':
        """Получение недавних данных для бэктеста"""
        
        import pandas as pd
        import numpy as np
        
        # Определение периода
        if hours > 0:
            periods = hours * 12  # 5-минутные свечи
            freq = '5min'
        else:
            periods = days * 288  # 5-минутные свечи за N дней
            freq = '5min'
        
        # Симуляция данных
        dates = pd.date_range(end=datetime.now(), periods=periods, freq=freq)
        
        data = pd.DataFrame({
            'timestamp': dates,
            'open': np.random.uniform(60000, 65000, periods),
            'high': np.random.uniform(61000, 66000, periods),
            'low': np.random.uniform(59000, 64000, periods),
            'close': np.random.uniform(60000, 65000, periods),
            'volume': np.random.uniform(100, 1000, periods),
            'lpi_total': np.random.uniform(0.3, 0.8, periods),
            'confluence_score': np.random.uniform(0.4, 0.9, periods),
            'regime': np.random.choice(['TREND', 'FLAT', 'CHAOS'], periods),
            'truth_verdict': np.random.choice(['Trend_Impulse', 'Consolidation_Range', 'Manipulation_Squeeze'], periods),
            'umsi_score': np.random.uniform(0.2, 0.8, periods)
        })
        
        return data
    
    async def _apply_optimization_results(self, results: Dict):
        """Автоматическое применение результатов оптимизации"""
        
        if not results or 'optimal_params' not in results:
            return
        
        optimal = results['optimal_params']
        strategy_name = results.get('strategy_name', 'unknown')
        
        logger.info(f"✅ Applying optimal params to {strategy_name}: {optimal}")
        
        # Применение к стратегии
        if strategy_name == 'grid_oracle' and hasattr(self.monolith, 'grid_oracle'):
            for param, value in optimal.items():
                if hasattr(self.monolith.grid_oracle, param):
                    setattr(self.monolith.grid_oracle, param, value)
    
    def get_status(self) -> Dict:
        """Получение статуса планировщика"""
        
        return {
            'running': self.running,
            'last_runs': {
                task: run.isoformat() if run else 'Never'
                for task, run in self.last_run.items()
            },
            'intervals_sec': self.intervals
        }

if __name__ == "__main__":
    print("✅ Unified Backtest Scheduler создан")
