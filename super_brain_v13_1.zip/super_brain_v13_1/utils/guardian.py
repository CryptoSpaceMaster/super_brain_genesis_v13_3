#!/usr/bin/env python3
"""
СТРАЖ (Guardian) - Система мониторинга и защиты
ТОЧНО ПО ЭНЦИКЛОПЕДИИ + УЛУЧШЕНИЯ ДЛЯ PRODUCTION
"""
import logging
from typing import Dict, List, Optional
from datetime import datetime
from enum import Enum
from collections import deque

logger = logging.getLogger(__name__)

class AlertLevel(Enum):
    """Уровни алертов"""
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    EMERGENCY = "EMERGENCY"

class Guardian:
    """
    СТРАЖ (Guardian) - Система мониторинга
    
    Функции:
    - Мониторинг всех модулей системы
    - Обнаружение аномалий
    - Генерация алертов
    - Защита капитала
    - Аварийное отключение
    
    УЛУЧШЕНИЯ v2.0:
    - Мониторинг FSM режимов
    - Мониторинг TRUTH ENGINE verdicts
    - Мониторинг Kill Switch состояния
    - Трекинг метрик в реальном времени
    - История изменений состояний
    """
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.alerts = []
        self.system_status = "OPERATIONAL"
        
        # Пороги для алертов
        self.max_drawdown_threshold = 0.15  # 15%
        self.critical_drawdown_threshold = 0.25  # 25%
        
        # История состояний (последние 100 записей)
        self.fsm_history = deque(maxlen=100)
        self.truth_verdict_history = deque(maxlen=100)
        self.kill_switch_history = deque(maxlen=100)
        
        # Счетчики метрик
        self.metrics = {
            'total_alerts': 0,
            'fsm_changes': 0,
            'truth_verdicts': {},
            'kill_switch_activations': 0,
            'emergency_shutdowns': 0
        }
        
        logger.info("🛡️ СТРАЖ (Guardian) v2.0 initialized with enhanced monitoring")
    
    def monitor_system_health(self, modules_status: Dict) -> Dict:
        """
        Мониторинг здоровья системы
        
        Args:
            modules_status: Статус всех модулей
        """
        
        health_report = {
            'timestamp': datetime.now().isoformat(),
            'overall_status': 'HEALTHY',
            'modules_checked': len(modules_status),
            'warnings': [],
            'errors': []
        }
        
        # Проверка каждого модуля
        for module_name, status in modules_status.items():
            if isinstance(status, dict) and 'error' in status:
                health_report['errors'].append(f"{module_name}: {status['error']}")
                health_report['overall_status'] = 'DEGRADED'
        
        if health_report['errors']:
            self._create_alert(
                AlertLevel.WARNING,
                f"System degraded: {len(health_report['errors'])} module errors",
                health_report
            )
        
        return health_report
    
    def monitor_risk_limits(self, aegis_stats: Dict, guaranteed_assets: Dict) -> Dict:
        """
        Мониторинг рисков и лимитов
        
        Args:
            aegis_stats: Статистика AEGIS
            guaranteed_assets: Статус гарантированных активов
        """
        
        risk_report = {
            'timestamp': datetime.now().isoformat(),
            'risk_level': 'NORMAL',
            'alerts': []
        }
        
        # Проверка общего PnL
        total_pnl = aegis_stats.get('total_pnl', 0)
        initial_capital = aegis_stats.get('initial_capital', 5000)
        
        if initial_capital > 0:
            drawdown = abs(min(0, total_pnl)) / initial_capital
            
            if drawdown > self.critical_drawdown_threshold:
                risk_report['risk_level'] = 'CRITICAL'
                risk_report['alerts'].append({
                    'type': 'CRITICAL_DRAWDOWN',
                    'drawdown': drawdown,
                    'action': 'EMERGENCY_STOP'
                })
                
                self._create_alert(
                    AlertLevel.CRITICAL,
                    f"Critical drawdown: {drawdown*100:.1f}%",
                    {'drawdown': drawdown, 'total_pnl': total_pnl}
                )
                
            elif drawdown > self.max_drawdown_threshold:
                risk_report['risk_level'] = 'WARNING'
                risk_report['alerts'].append({
                    'type': 'HIGH_DRAWDOWN',
                    'drawdown': drawdown,
                    'action': 'REDUCE_POSITIONS'
                })
                
                self._create_alert(
                    AlertLevel.WARNING,
                    f"High drawdown: {drawdown*100:.1f}%",
                    {'drawdown': drawdown, 'total_pnl': total_pnl}
                )
        
        return risk_report
    
    def monitor_performance(self, executor_stats: Dict) -> Dict:
        """
        Мониторинг производительности торговли
        
        Args:
            executor_stats: Статистика исполнения
        """
        
        performance_report = {
            'timestamp': datetime.now().isoformat(),
            'total_positions': executor_stats.get('open_positions', 0) + executor_stats.get('closed_positions', 0),
            'open_positions': executor_stats.get('open_positions', 0),
            'total_pnl': executor_stats.get('total_pnl', 0),
            'status': 'NORMAL'
        }
        
        # Проверка количества открытых позиций
        if performance_report['open_positions'] > 20:
            performance_report['status'] = 'WARNING'
            self._create_alert(
                AlertLevel.WARNING,
                f"Too many open positions: {performance_report['open_positions']}",
                performance_report
            )
        
        return performance_report
    
    def _create_alert(self, level: AlertLevel, message: str, data: Dict):
        """Создание алерта"""
        
        alert = {
            'alert_id': f"ALERT_{len(self.alerts) + 1}",
            'level': level.value,
            'message': message,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        self.alerts.append(alert)
        
        # Логирование в зависимости от уровня
        if level == AlertLevel.CRITICAL or level == AlertLevel.EMERGENCY:
            logger.critical(f"🚨 {level.value}: {message}")
        elif level == AlertLevel.WARNING:
            logger.warning(f"⚠️ {level.value}: {message}")
        else:
            logger.info(f"ℹ️ {level.value}: {message}")
    
    def emergency_shutdown(self, reason: str) -> Dict:
        """
        Аварийное отключение системы
        
        Args:
            reason: Причина отключения
        """
        
        self.system_status = "EMERGENCY_SHUTDOWN"
        
        shutdown_report = {
            'status': 'SHUTDOWN',
            'reason': reason,
            'timestamp': datetime.now().isoformat(),
            'total_alerts': len(self.alerts)
        }
        
        self._create_alert(
            AlertLevel.EMERGENCY,
            f"Emergency shutdown initiated: {reason}",
            shutdown_report
        )
        
        logger.critical(f"🛑 EMERGENCY SHUTDOWN: {reason}")
        
        return shutdown_report
    
    def get_recent_alerts(self, count: int = 10) -> List[Dict]:
        """Получение последних алертов"""
        return self.alerts[-count:]
    
    def get_system_status(self) -> Dict:
        """Получение статуса системы"""
        return {
            'status': self.system_status,
            'total_alerts': len(self.alerts),
            'critical_alerts': len([a for a in self.alerts if a['level'] == AlertLevel.CRITICAL.value]),
            'warning_alerts': len([a for a in self.alerts if a['level'] == AlertLevel.WARNING.value]),
            'metrics': self.metrics
        }
    
    def monitor_fsm_state(self, current_state: str, previous_state: Optional[str] = None) -> Dict:
        """
        Мониторинг FSM режимов (TREND/FLAT/CHAOS)
        
        Args:
            current_state: Текущий режим FSM
            previous_state: Предыдущий режим FSM (опционально)
        
        Returns:
            Отчет о состоянии FSM
        """
        
        fsm_report = {
            'timestamp': datetime.now().isoformat(),
            'current_state': current_state,
            'previous_state': previous_state,
            'state_changed': False
        }
        
        # Запись в историю
        self.fsm_history.append({
            'state': current_state,
            'timestamp': datetime.now().isoformat()
        })
        
        # Детекция изменения состояния
        if previous_state and previous_state != current_state:
            fsm_report['state_changed'] = True
            self.metrics['fsm_changes'] += 1
            
            self._create_alert(
                AlertLevel.INFO,
                f"FSM state changed: {previous_state} → {current_state}",
                fsm_report
            )
            
            logger.info(f"📊 FSM State Change: {previous_state} → {current_state}")
        
        # Алерт при длительном CHAOS режиме
        if current_state == 'CHAOS':
            recent_chaos = sum(1 for entry in list(self.fsm_history)[-10:] 
                             if entry.get('state') == 'CHAOS')
            
            if recent_chaos >= 8:
                self._create_alert(
                    AlertLevel.WARNING,
                    f"Prolonged CHAOS state detected: {recent_chaos}/10 recent states",
                    {'current_state': current_state, 'chaos_count': recent_chaos}
                )
        
        return fsm_report
    
    def monitor_truth_verdict(self, verdict: str, confidence: float, symbol: str = "UNKNOWN") -> Dict:
        """
        Мониторинг TRUTH ENGINE вердиктов
        
        Args:
            verdict: Вердикт (Manipulation_Squeeze, Trend_Impulse, Consolidation_Range)
            confidence: Уверенность (0-1)
            symbol: Торговая пара
        
        Returns:
            Отчет о вердикте
        """
        
        verdict_report = {
            'timestamp': datetime.now().isoformat(),
            'verdict': verdict,
            'confidence': confidence,
            'symbol': symbol
        }
        
        # Запись в историю
        self.truth_verdict_history.append(verdict_report)
        
        # Обновление счетчиков
        if verdict not in self.metrics['truth_verdicts']:
            self.metrics['truth_verdicts'][verdict] = 0
        self.metrics['truth_verdicts'][verdict] += 1
        
        # Алерт при детекции манипуляции
        if verdict == "Manipulation_Squeeze" and confidence > 0.8:
            self._create_alert(
                AlertLevel.WARNING,
                f"MANIPULATION detected on {symbol} (confidence: {confidence:.2f})",
                verdict_report
            )
            
            logger.warning(f"🎯 MANIPULATION SQUEEZE detected: {symbol} (conf: {confidence:.2f})")
        
        # Алерт при низкой уверенности
        if confidence < 0.3:
            self._create_alert(
                AlertLevel.INFO,
                f"Low confidence verdict: {verdict} ({confidence:.2f}) on {symbol}",
                verdict_report
            )
        
        return verdict_report
    
    def monitor_kill_switch(self, is_active: bool, reason: Optional[str] = None, 
                          strategy: str = "SCALPING") -> Dict:
        """
        Мониторинг Kill Switch состояния (для SCALPING v4.1)
        
        Args:
            is_active: Активен ли Kill Switch
            reason: Причина активации (если активен)
            strategy: Название стратегии
        
        Returns:
            Отчет о Kill Switch
        """
        
        kill_switch_report = {
            'timestamp': datetime.now().isoformat(),
            'is_active': is_active,
            'reason': reason,
            'strategy': strategy
        }
        
        # Запись в историю
        self.kill_switch_history.append(kill_switch_report)
        
        # Алерт при активации Kill Switch
        if is_active:
            self.metrics['kill_switch_activations'] += 1
            
            self._create_alert(
                AlertLevel.CRITICAL,
                f"Kill Switch ACTIVATED for {strategy}: {reason}",
                kill_switch_report
            )
            
            logger.critical(f"🛑 Kill Switch ACTIVATED: {strategy} - {reason}")
        else:
            # Деактивация
            logger.info(f"✅ Kill Switch deactivated for {strategy}")
        
        return kill_switch_report
    
    def get_monitoring_summary(self) -> Dict:
        """
        Получение сводки мониторинга за сессию
        
        Returns:
            Полная сводка всех метрик
        """
        
        # Анализ FSM истории
        fsm_states_count = {}
        for entry in self.fsm_history:
            state = entry.get('state', 'UNKNOWN')
            fsm_states_count[state] = fsm_states_count.get(state, 0) + 1
        
        # Анализ Truth Engine истории
        recent_verdicts = list(self.truth_verdict_history)[-20:]
        avg_confidence = (sum(v.get('confidence', 0) for v in recent_verdicts) / len(recent_verdicts)) if recent_verdicts else 0
        
        # Анализ Kill Switch истории
        kill_switch_activations_count = sum(1 for entry in self.kill_switch_history if entry.get('is_active'))
        
        return {
            'timestamp': datetime.now().isoformat(),
            'system_status': self.system_status,
            'total_alerts': len(self.alerts),
            'metrics': self.metrics,
            'fsm_analysis': {
                'total_states_tracked': len(self.fsm_history),
                'state_distribution': fsm_states_count,
                'total_changes': self.metrics['fsm_changes']
            },
            'truth_engine_analysis': {
                'total_verdicts': len(self.truth_verdict_history),
                'verdict_distribution': self.metrics['truth_verdicts'],
                'avg_confidence_recent_20': round(avg_confidence, 3)
            },
            'kill_switch_analysis': {
                'total_events': len(self.kill_switch_history),
                'activations': kill_switch_activations_count,
                'total_activations': self.metrics['kill_switch_activations']
            },
            'alert_summary': {
                'total': len(self.alerts),
                'critical': len([a for a in self.alerts if a['level'] == 'CRITICAL']),
                'warning': len([a for a in self.alerts if a['level'] == 'WARNING']),
                'info': len([a for a in self.alerts if a['level'] == 'INFO'])
            }
        }

if __name__ == "__main__":
    print("✅ СТРАЖ (Guardian) v2.0 создан с улучшенным мониторингом")
