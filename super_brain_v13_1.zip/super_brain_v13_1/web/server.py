"""
HTTP Server для СУПЕР МОЗГ GENESIS v13.1
Обслуживает:
- index.html: Главный визуальный симулятор (22 модуля)
- visual_simulator.html: Детальный визуальный симулятор
- client_management.html: Client Management Dashboard (Module #23)
- API endpoints: /api/* для данных в реальном времени
"""
import logging
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import mimetypes

logger = logging.getLogger(__name__)


class ClientManagementHTTPHandler(BaseHTTPRequestHandler):
    """HTTP Request Handler для Client Management Dashboard"""
    
    client_manager = None
    api_handler = None
    
    def do_GET(self):
        """Обработка GET запросов"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        if path == '/' or path == '/index.html':
            self._serve_file('index.html', 'text/html')
        
        elif path == '/visual_simulator.html':
            self._serve_file('visual_simulator.html', 'text/html')
        
        elif path == '/client_management' or path == '/client_management.html':
            self._serve_file('web/client_management.html', 'text/html')
        
        elif path.startswith('/api/'):
            self._handle_api_request('GET', path, None)
        
        elif path.startswith('/static/'):
            self._serve_static(path)
        
        else:
            self.send_error(404, "Not Found")
    
    def do_POST(self):
        """Обработка POST запросов"""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else b'{}'
        
        try:
            data = json.loads(body.decode('utf-8')) if body else None
        except:
            data = None
        
        if path.startswith('/api/'):
            self._handle_api_request('POST', path, data)
        else:
            self.send_error(404, "Not Found")
    
    def _handle_api_request(self, method, path, data):
        """Обработка API запросов через ClientAPIHandler"""
        if not self.api_handler:
            self._send_json_response({'error': 'API not available'}, 503)
            return
        
        try:
            response = self.api_handler.handle_request(path, method, data)
            status = response.get('status', 200)
            self._send_json_response(response, status)
        except Exception as e:
            logger.error(f"API error: {e}")
            self._send_json_response({'error': str(e)}, 500)
    
    def _serve_file(self, file_path, content_type):
        """Отправка файла клиенту"""
        try:
            full_path = Path(__file__).parent.parent / file_path
            
            if not full_path.exists():
                self.send_error(404, f"File not found: {file_path}")
                return
            
            with open(full_path, 'rb') as f:
                content = f.read()
            
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', len(content))
            self.end_headers()
            self.wfile.write(content)
        
        except Exception as e:
            logger.error(f"Error serving file {file_path}: {e}")
            self.send_error(500, str(e))
    
    def _serve_static(self, path):
        """Отправка статических файлов"""
        file_path = path.replace('/static/', '')
        full_path = Path(__file__).parent / 'static' / file_path
        
        if not full_path.exists():
            self.send_error(404)
            return
        
        content_type, _ = mimetypes.guess_type(str(full_path))
        if not content_type:
            content_type = 'application/octet-stream'
        
        self._serve_file(f'web/static/{file_path}', content_type)
    
    def _send_json_response(self, data, status=200):
        """Отправка JSON ответа"""
        response_body = json.dumps(data).encode('utf-8')
        
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', len(response_body))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(response_body)
    
    def log_message(self, format, *args):
        """Логирование запросов"""
        logger.debug(f"{self.address_string()} - {format % args}")


def run_server(client_manager=None, api_handler=None, port=5000):
    """
    Запуск HTTP сервера
    
    Args:
        client_manager: ClientManager instance (optional)
        api_handler: ClientAPIHandler instance (optional)
        port: Порт сервера
    """
    ClientManagementHTTPHandler.client_manager = client_manager
    ClientManagementHTTPHandler.api_handler = api_handler
    
    server = HTTPServer(('0.0.0.0', port), ClientManagementHTTPHandler)
    
    logger.info("🌐 СУПЕР МОЗГ GENESIS v13.1 Web Server")
    logger.info(f"   Main Dashboard: http://localhost:{port}")
    logger.info(f"   Visual Simulator: http://localhost:{port}/visual_simulator.html")
    if client_manager:
        logger.info(f"   Client Management: http://localhost:{port}/client_management")
        logger.info(f"   API: http://localhost:{port}/api/clients")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("🛑 Server stopped")
        server.shutdown()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Server needs ClientManager to run. Use monolith.py instead.")
